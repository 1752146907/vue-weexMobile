import Vue from 'vue';
import Router from 'vue-router';
import weex from 'weex-vue-render';

weex.init(Vue);

const router = require('@/router');
const App = require('../../../src/view/dynamic/detail.vue');
new Vue(Vue.util.extend({el: '#root', router}, App));
