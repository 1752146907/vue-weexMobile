import Vue from 'vue';
import Router from 'vue-router';
import weex from 'weex-vue-render';

const router = require('@/router');

weex.init(Vue);
const App = require('../../../src/view/order/done.vue');
new Vue(Vue.util.extend({el: '#root', router}, App));
