import Vue from 'vue';
import Router from 'vue-router';
import weex from 'weex-vue-render';

weex.init(Vue);

const router = require('@/router');
const App = require('../../../../src/view/my/bill/index.vue');
new Vue(Vue.util.extend({el: '#root', router}, App));
