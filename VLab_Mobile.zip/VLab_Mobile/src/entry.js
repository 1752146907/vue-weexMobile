import Vue from 'vue';
import Router from 'vue-router';
import weex from 'weex-vue-render';

weex.init(Vue);

const router = require('@/router');