<template>
	<scroller class="container"
			  @scroll="windowScrool"
			  @touchend="windowScrool"
			  offset-accuracy="10"
			  :style="{height: pageHeight + 'px'}">
		<slider class="slider" interval="5000" auto-play="true" :index="0">
			<div class="slider-frame" v-for="(img, index) in productInfo.productImageList">
				<image class="slider-image" resize="cover" :src="imageHost + img.imagePath"></image>
				<text class="slider-index">{{index + 1}}/{{productInfo.productImageList.length}}</text>
			</div>
		</slider>

		<text class="home-title">-- 薇嘉动态 --</text>
		<div class="dynamic">
			<div class="item-cell"
				 v-for="(item, index) in articleList"
				 v-if="index < 6"
				 :key="index">
				<div @click="handleToDetail(item.articleId, item.articleIsOuterLink, item.articleOuterLink)">
					<div class="item-panel">
						<image class="item-panel-img"
							   resize="cover"
							   :src="imageHost + item.articleImagePath"></image>
					</div>
					<text class="item-panel-txt" lines="2">{{item.articleTitle}}</text>
				</div>
			</div>
		</div>

		<div class="community-box">
			<text class="home-title">-- 圈子动态 --</text>
			<div class="community-main">
				<div v-for="(topic, index) in topicList.list"
					 v-if="index < 6">
					<div class="community-main-item"
						 v-if="topic.topicImageList.length == 0">
						<image class="community-main-item-author"
							   resize="cover"
							   @click="handleToHomePage(topic.memberId, topic.topicId)"
							   :src='imageHost + topic.memberAvatarPath'></image>
						<div class="community-main-item-content">
							<text class="community-main-item-content-author-name" @click="handleToHomePage(topic.memberId, topic.topicId)">{{topic.memberNickName}}</text>
							<text class="community-main-item-content-moment-content"
								  lines="3"
								  @click="handleToCircleDetail(topic.topicId)">{{topic.topicContent}}</text>
							<text class="location">{{topic.topicLocation}}</text>
							<div class="community-main-item-content-card-moment-info">
								<text class="community-main-item-content-card-moment-info-time">{{topic.systemCreateTime}}</text>
								<text class="community-main-item-content-card-moment-info-delete"
									  v-if="getMemberId == topic.memberId"
									  @click="haneleDeleteTopic(topic.topicId)">删除</text>
								<div class="community-main-item-content-card-moment-info-feedbac">
									<div class="community-main-item-content-card-moment-info-feedbac-item"
										 v-if="showTopicEvaluate == topic.topicId">
										<div class="community-main-item-content-card-moment-info-feedbac-item-box">
											<image class="community-main-item-content-card-moment-info-feedbac-item-xin"
												   v-if="topic.memberIsLike"
												   @click="handleDelGood(topic.topicId)"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
											<image class="community-main-item-content-card-moment-info-feedbac-item-xin"
												   v-if="!topic.memberIsLike"
												   @click="handleGood(topic.topicId)"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
											<text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
												  v-if="topic.memberIsLike"
												  @click="handleDelGood(topic.topicId)">取消</text>
											<text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
												  v-if="!topic.memberIsLike"
												  @click="handleGood(topic.topicId)">点赞</text>
										</div>
										<text class="community-main-item-content-card-moment-info-feedbac-item-line">|</text>
										<div class="community-main-item-content-card-moment-info-feedbac-item-box"
											 @click="handleEvaluate(topic.topicId)">
											<image class="community-main-item-content-card-moment-info-feedbac-item-pinjia"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/pinjia.png"></image>
											<text class="community-main-item-content-card-moment-info-feedbac-item-evaluate">评价</text>
										</div>
									</div>
									<image class="community-main-item-content-card-moment-info-feedbac-image"
										   @click="handleDotDotDot(topic.topicId)"
										   src='https://gw.alicdn.com/tfs/TB1_POLc3MPMeJjy1XcXXXpppXa-66-46.png'></image>
								</div>
							</div>
							<image class="community-main-item-content-moment-arrow"
								   v-if="topic.topicLikeList.length > 0 || topic.topicCommentList.length > 0"
								   src="https://gw.alicdn.com/tfs/TB1F0OLc3oQMeJjy0FnXXb8gFXa-30-12.png"></image>
							<div class="community-main-item-content-moment-likes"
								 :class="[topic.topicCommentList.length > 0 ? 'community-main-item-content-moment-likes-bottom-line' : '']"
								 v-if="topic.topicLikeList.length > 0">
								<text class="community-main-item-content-moment-likes-good">♡</text>
								<text class="community-main-item-content-moment-likes-list link-text"
									  v-for="(like, index) in topic.topicLikeList"
									  :key="like.memberId"
									  @click="handleOrterPage(like.memberId)">{{like.memberNickName}} <text class="community-main-item-content-moment-likes-list-line"
																											v-if="index != topic.topicLikeList.length-1">，</text></text>
							</div>
							<text class="community-main-item-content-comment-list"
								  @click="handleReply(comment.memberId, comment.topicCommentId, topic.topicId, comment.memberNickName)"
								  v-for="(comment, index) in topic.topicCommentList"
								  :key="index"
								  :class="[index == '0' ? 'community-main-item-content-comment-list-one' : '']"
								  v-if="topic.topicCommentList.length > 0">{{comment.memberNickName}}{{comment.replyMemberNickName ? ' 回复 ' + comment.replyMemberNickName : ''}}：{{comment.topicCommentContent}}</text>
						</div>
					</div>
					<div class="community-main-item"
						 v-if="topic.topicImageList.length == 1">
						<image class="community-main-item-author"
							   resize="cover"
							   @click="handleToHomePage(topic.memberId, topic.topicId)"
							   :src='imageHost + topic.memberAvatarPath'></image>
						<div class="community-main-item-content">
							<text class="community-main-item-content-author-name"
								  @click="handleToHomePage(topic.memberId, topic.topicId)">{{topic.memberNickName}}</text>
							<text class="community-main-item-content-moment-content"
								  lines="3"
								  @click="handleToCircleDetail(topic.topicId)">{{topic.topicContent}}</text>
							<image class="community-main-item-content-card-picture"
								   resize="cover"
								   v-for="(imageList, index) in topic.topicImageList"
								   :key="imageList.imageId"
								   @click="handleOpenImageLigh(topic.topicImageList, index)"
								   :src='imageHost + imageList.imagePath'></image>
							<text class="location margin-top-10">{{topic.topicLocation}}</text>
							<div class="community-main-item-content-card-moment-info">
								<text class="community-main-item-content-card-moment-info-time">{{topic.systemCreateTime}}</text>
								<text class="community-main-item-content-card-moment-info-delete"
									  v-if="getMemberId == topic.memberId"
									  @click="haneleDeleteTopic(topic.topicId)">删除</text>
								<div class="community-main-item-content-card-moment-info-feedbac">
									<div class="community-main-item-content-card-moment-info-feedbac-item"
										 v-if="showTopicEvaluate == topic.topicId">
										<div class="community-main-item-content-card-moment-info-feedbac-item-box">
											<image class="community-main-item-content-card-moment-info-feedbac-item-xin"
												   v-if="topic.memberIsLike"
												   @click="handleDelGood(topic.topicId)"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
											<image class="community-main-item-content-card-moment-info-feedbac-item-xin"
												   v-if="!topic.memberIsLike"
												   @click="handleGood(topic.topicId)"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
											<text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
												  v-if="topic.memberIsLike"
												  @click="handleDelGood(topic.topicId)">取消</text>
											<text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
												  v-if="!topic.memberIsLike"
												  @click="handleGood(topic.topicId)">点赞</text>
										</div>
										<text class="community-main-item-content-card-moment-info-feedbac-item-line">|</text>
										<div class="community-main-item-content-card-moment-info-feedbac-item-box"
											 @click="handleEvaluate(topic.topicId)">
											<image class="community-main-item-content-card-moment-info-feedbac-item-pinjia"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/pinjia.png"></image>
											<text class="community-main-item-content-card-moment-info-feedbac-item-evaluate">评价</text>
										</div>
									</div>
									<image class="community-main-item-content-card-moment-info-feedbac-image"
										   @click="handleDotDotDot(topic.topicId)"
										   src='https://gw.alicdn.com/tfs/TB1_POLc3MPMeJjy1XcXXXpppXa-66-46.png'></image>
								</div>
							</div>
							<image class="community-main-item-content-moment-arrow"
								   src="https://gw.alicdn.com/tfs/TB1F0OLc3oQMeJjy0FnXXb8gFXa-30-12.png"
								   v-if="topic.topicLikeList.length > 0 || topic.topicCommentList.length > 0"></image>
							<div class="community-main-item-content-moment-likes"
								 :class="[topic.topicCommentList.length > 0 ? 'community-main-item-content-moment-likes-bottom-line' : '']"
								 v-if="topic.topicLikeList.length > 0">
								<text class="community-main-item-content-moment-likes-good">♡</text>
								<text class="community-main-item-content-moment-likes-list link-text"
									  v-for="(like, index) in topic.topicLikeList"
									  :key="like.memberId"
									  @click="handleOrterPage(like.memberId)">{{like.memberNickName}} <text class="community-main-item-content-moment-likes-list-line"
																											v-if="index != topic.topicLikeList.length-1">，</text></text>
							</div>
							<text class="community-main-item-content-comment-list"
								  v-for="(comment, index) in topic.topicCommentList"
								  :key="index"
								  :class="[index == '0' ? 'community-main-item-content-comment-list-one' : '']"
								  @click="handleReply(comment.memberId, comment.topicCommentId, topic.topicId, comment.memberNickName)"
								  v-if="topic.topicCommentList.length > 0">{{comment.memberNickName}}{{comment.replyMemberNickName ? ' 回复 ' + comment.replyMemberNickName : ''}}：{{comment.topicCommentContent}}</text>
						</div>
					</div>
					<div class="community-main-item"
						 v-if="topic.topicImageList.length > 1">
						<image class="community-main-item-author"
							   resize="cover"
							   @click="handleToHomePage(topic.memberId, topic.topicId)"
							   :src='imageHost + topic.memberAvatarPath'></image>
						<div class="community-main-item-content">
							<text class="community-main-item-content-author-name"
								  @click="handleToHomePage(topic.memberId, topic.topicId)">{{topic.memberNickName}}</text>
							<text class="community-main-item-content-moment-content"
								  lines="3"
								  @click="handleToCircleDetail(topic.topicId)">{{topic.topicContent}}</text>
							<div class="community-main-item-content-moment-many-pictures">
								<image resize="cover"
									   class="community-main-item-content-moment-many-pictures-image"
									   v-for="(imageList, index) in topic.topicImageList"
									   :key="imageList.imageId"
									   @click="handleOpenImageLigh(topic.topicImageList, index)"
									   :src='imageHost + imageList.imagePath'>
								</image>
							</div>
							<text class="location margin-top-10">{{topic.topicLocation}}</text>
							<div class="community-main-item-content-card-moment-info">
								<text class="community-main-item-content-card-moment-info-time">{{topic.systemCreateTime}}</text>
								<text class="community-main-item-content-card-moment-info-delete"
									  v-if="getMemberId == topic.memberId"
									  @click="haneleDeleteTopic(topic.topicId)">删除</text>
								<div class="community-main-item-content-card-moment-info-feedbac">
									<div class="community-main-item-content-card-moment-info-feedbac-item"
										 v-if="showTopicEvaluate == topic.topicId">
										<div class="community-main-item-content-card-moment-info-feedbac-item-box">
											<image class="community-main-item-content-card-moment-info-feedbac-item-xin"
												   v-if="topic.memberIsLike"
												   @click="handleDelGood(topic.topicId)"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
											<image class="community-main-item-content-card-moment-info-feedbac-item-xin"
												   v-if="!topic.memberIsLike"
												   @click="handleGood(topic.topicId)"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
											<text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
												  v-if="topic.memberIsLike"
												  @click="handleDelGood(topic.topicId)">取消</text>
											<text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
												  v-if="!topic.memberIsLike"
												  @click="handleGood(topic.topicId)">点赞</text>
										</div>
										<text class="community-main-item-content-card-moment-info-feedbac-item-line">|</text>
										<div class="community-main-item-content-card-moment-info-feedbac-item-box"
											 @click="handleEvaluate(topic.topicId)">
											<image class="community-main-item-content-card-moment-info-feedbac-item-pinjia"
												   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/pinjia.png"></image>
											<text class="community-main-item-content-card-moment-info-feedbac-item-evaluate">评价</text>
										</div>
									</div>
									<image class="community-main-item-content-card-moment-info-feedbac-image"
										   @click="handleDotDotDot(topic.topicId)"
										   src='https://gw.alicdn.com/tfs/TB1_POLc3MPMeJjy1XcXXXpppXa-66-46.png'></image>
								</div>
							</div>
							<image class="community-main-item-content-moment-arrow"
								   src="https://gw.alicdn.com/tfs/TB1F0OLc3oQMeJjy0FnXXb8gFXa-30-12.png"
								   v-if="topic.topicLikeList.length > 0 || topic.topicCommentList.length > 0"></image>
							<div class="community-main-item-content-moment-likes"
								 :class="[topic.topicCommentList.length > 0 ? 'community-main-item-content-moment-likes-bottom-line' : '']"
								 v-if="topic.topicLikeList.length > 0">
								<text class="community-main-item-content-moment-likes-good">♡</text>
								<text class="community-main-item-content-moment-likes-list link-text"
									  v-for="(like, index) in topic.topicLikeList"
									  :key="like.memberId"
									  @click="handleOrterPage(like.memberId)">{{like.memberNickName}} <text class="community-main-item-content-moment-likes-list-line"
																											v-if="index != topic.topicLikeList.length-1">，</text></text>
							</div>
							<text class="community-main-item-content-comment-list"
								  v-if="topic.topicCommentList.length > 0"
								  v-for="(comment, index) in topic.topicCommentList"
								  :key="index"
								  :class="[index == '0' ? 'community-main-item-content-comment-list-one' : '']"
								  @click="handleReply(comment.memberId, comment.topicCommentId, topic.topicId, comment.memberNickName)">{{comment.memberNickName}}{{comment.replyMemberNickName ? ' 回复 ' + comment.replyMemberNickName : ''}}：{{comment.topicCommentContent}}</text>
						</div>
					</div>
				</div>
			</div>
			<div class="input-bar"
				 v-if="showInputBar">
				<input class="input"
					   type="text"
					   :autofocus="true"
					   @blur="handeleInputBarBlur"
					   v-model="topicCommentContent"
					   :placeholder="replyMemberName ? '回复：' + replyMemberName : '输入你想说的...'" />
				<div class="btn-send" @click="handleUserInput">
					<text class="btn-send-text">发送</text>
				</div>
			</div>
		</div>
		<text class="the-end">-- 没有更多了 --</text>
		<wxc-dialog title="确定删除"
					content="本操作不可恢复，您确定删除本条动态吗？"
					:show="wxcDialogConfirmShow"
					main-btn-color="#e994a9"
					@wxcDialogCancelBtnClicked="dialogConfirmBtnNo"
					@wxcDialogConfirmBtnClicked="dialogConfirmBtnClick">
		</wxc-dialog>
		<wxc-loading :show="isLoad" type="default"></wxc-loading>
	</scroller>
</template>

<script>
	import {WxcStepper, WxcLoading, WxcDialog} from 'weex-ui';

	import mixin from '../../common/mixin';

	export default {
		components: {
			WxcStepper,
			WxcLoading,
            WxcDialog
		},
		mixins: [mixin],
		data: () => ({
			productInfo: '',
			isLoad: false,
            wxcDialogConfirmShow: false,
            showImageList:[],
		    showTopicEvaluate: '',
		    showInputBar: false,
		    topicList: '',
		    pageIndex: 1,
		    pageSize: 6,
		    topicId: '',
            delTopicId: '',
		    getMemberId: '',
		    replyCommentId: '',
		    replyMemberId: '',
		    topicCommentContent: '',
            replyMemberName: '',
            articleList: [],
            showEvaluate: false
		}),
		props: {
			activeIndex: {
				type: String,
				required: true
			}
		},
		mounted () {
            this.storage.getItem(this.setMemberId, (res) => {
                if (res.result === 'success') {
                    this.getMemberId = res.data
                }
            });

            this.globalEvent.addEventListener('circleDeleteSuccess', (data) => {
                this.showImageList = [];
                this.haneleCircle();
			})

            this.globalEvent.addEventListener('publishSuccess', (data) => {    //事件监听
                this.showImageList = [];
                this.haneleCircle();
            });

            this.changeTitle('动态');
            this.haneleLoad();
            this.haneleCircle();
            this.hanldeLoadArticle();
		},
		methods: {
            handleToCircleDetail(id) {
                this.push('/circle/detail?topicId=' + id);
            },
            handleOpenImageLigh(imagePath, index) {
                this.showImageList = [];
                for (var a = 0; a < imagePath.length; a++){
                    var showImageList = {};
                    showImageList = this.imageHost + imagePath[a].imagePath
                    this.showImageList.push(showImageList);
                }

                if (this.platform != 'web') {
                    this.chuangshi.openImageBrowser({
                        list: this.showImageList,
                        pageIndex: index
                    });
                }

            },
            wxcLightboxOverlayClicked() {
                this.isShowImageLigh = false;
            },

            windowScrool(event) {
                this.showInputBar = false;
                this.showTopicEvaluate = '';
                return;
            },
            haneleLoad() {
                this.request({
                    url: '/xingxiao/product/mobile/v1/view',
                    data: {
                        productId: "1002483230350774273"
					},
                    success: (data) => {
                        this.productInfo = data
                    }
                });
            },

            handleOrterPage(id) {
                if(id == this.getMemberId) {
                    this.push('/circle/homePage');
                } else{
                    this.push('/circle/otherPage?memberId=' + id);
                }
                // this.toast(id);
            },
            handleDotDotDot(id) {
                this.replyMemberName = '';

                if(this.showTopicEvaluate == ''){
                    this.showTopicEvaluate = id;
                    return;
                } else {
                    this.showTopicEvaluate = '';
                    return;
                }
            },
            handleDelGood(id) {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/like/mobile/v1/delete',
                    data: {
                        topicId: id
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.toast('取消点赞');
                        this.handleGoddList(id);
                        this.showTopicEvaluate = '';
                        for(var i = 0; i <= this.topicList.list.length; i++){
                            if(this.topicList.list[i].topicId == id) {
                                this.topicList.list[i].memberIsLike = false;
                            }
                        }
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleGood(id) {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/like/mobile/v1/save',
                    data: {
                        topicId: id
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.toast('点赞成功');
                        this.handleGoddList(id);
                        this.showTopicEvaluate = '';
                        for(var i = 0; i <= this.topicList.list.length; i++){
                            if(this.topicList.list[i].topicId == id) {
                                this.topicList.list[i].memberIsLike = true;
                            }
                        }
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleGoddList(id) {
                this.request({
                    url: '/xingxiao/topic/like/mobile/v1/list',
                    data: {
                        topicId: id
                    },
                    success: (data) => {
                        for(var i = 0; i <= this.topicList.list.length; i++){
                            if(this.topicList.list[i].topicId == id) {
                                this.topicList.list[i].topicLikeList = data;
                            }
                        }

                        this.isLoad = false;
                        this.showTopicEvaluate = ''
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handeleInputBarBlur() {
                this.showTopicEvaluate = false;
                this.showInputBar = false;
                this.topicCommentContent = ''
            },
            handleReply(memberId, topicCommentId, topicId, memberNickName) {
                this.showTopicEvaluate = true;
                this.showInputBar = true;
                this.topicCommentContent = '';

                this.topicId = topicId;
                this.replyMemberId = memberId;
                this.replyCommentId = topicCommentId;
                this.replyMemberName = memberNickName;
            },
            handleUserInput() {
                if(this.topicCommentContent == '' || this.topicCommentContent.trim() == ''){
                    this.toast("评价内容不能为空");
                    this.topicCommentContent = '';
                    this.showTopicEvaluate = false;
                    this.showInputBar = false;
					return;
				}
                this.isLoad = true;
                this.showTopicEvaluate = false;
                this.showInputBar = false;
                this.request({
                    url: '/xingxiao/topic/comment/mobile/v1/save',
                    data: {
                        topicId: this.topicId,
                        replyCommentId: this.replyCommentId,
                        replyMemberId: this.replyMemberId,
                        topicCommentContent: this.topicCommentContent
                    },
                    success: (data) => {
                        this.topicCommentContent = '';
                        this.handleGetCommentList();
                    }
                })
            },
            handleGetCommentList() {
                this.request({
                    url: '/xingxiao/topic/comment/mobile/v1/list',
                    data: {
                        topicId: this.topicId
                    },
                    success: (data) => {
                        this.toast("评论成功");
                        this.isLoad = false;
                        for (var i = 0 ; i <= this.topicList.list.length; i++) {
                            if (this.topicList.list[i].topicId == this.topicId) {
                                this.topicList.list[i].topicCommentList = data;
                            }
                        }
                        this.topicCommentContent = ''
                    }
                })
            },
            handleEvaluate(id) {
                this.topicId = id;
                this.showTopicEvaluate = '';
                this.showTopicEvaluate = '',
                    this.showInputBar = !this.showInputBar
            },
            haneleCircle() {
                this.request({
                    url: '/xingxiao/topic/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        topicId: this.topicId
                    },
                    success: (data) => {
                        for (var i in data.list) {
                            data.list[i].systemCreateTime = this.timeToDateStr(data.list[i].systemCreateTime)
                        }
                        this.topicList = data;
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleToHomePage(memberId, topicId) {
                if(memberId == this.getMemberId) {
                    this.push('/circle/homePage');
                } else{
                    this.push('/circle/otherPage?memberId=' + memberId + '&topicId=' + topicId);
                }
            },
            timeToDateStr(time) {
                var differTime = parseInt((new Date().getTime() - time) / 1000);
                if (differTime <= 0) {
                    return "刚刚";
                } else if (differTime < 60) {
                    return differTime + "秒前";
                } else if (differTime < 3600) {
                    return parseInt(differTime / 60) + "分钟前";
                } else if (differTime < 86400) {
                    return parseInt(differTime / 3600) + "小时前";
                } else if (differTime < 2592000) {
                    return parseInt(differTime / 86400) + "天前";
                } else if (differTime < 31104000) {
                    return parseInt(differTime / 2592000) + "月前";
                } else {
                    return parseInt(differTime / 31104000) + "年前";
                }
            },
            dialogConfirmBtnNo () {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            dialogConfirmBtnClick () {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/mobile/v1/delete',
                    data: {
                        topicId: this.delTopicId,
                    },
                    success: (data) => {
                        this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
                        this.isLoad = false;

                        this.chuangshi.sendEventListener({
                            name: 'circleDeleteSuccess',
                            data: {    }
                        });

                        for (var a = 0; a <= this.topicList.length; a++) {
                            if(this.delTopicId == this.topicList[a].topicId){
                                this.topicList.splice(a, 1);
                            }
                        }
                    },
                    error: (data) => {
                        this.isLoad = false;
                    }
                });
            },
            haneleDeleteTopic(topicId) {
                this.delTopicId = topicId;
                this.wxcDialogConfirmShow = true;
            },

            hanldeLoadArticle: function () {
                this.request({
                    url: '/xingxiao/article/desktop/v1/storyList',
                    data: {
                        year: this.year,
                        month: this.month
                    },
                    success: (data) => {
                        if (data && data.length > 0) {
                            this.articleList = data;
                        }
                    },
                    error: () => {

                    }
                })
            },
            handleToDetail: function (articleId, articleIsOuterLink, articleOuterLink) {
                if (articleIsOuterLink == 1) {
                    this.push('/dynamic/detail?articleOuterLink=' + encodeURIComponent(articleOuterLink) + '&isArticleOuterLink=' + true)
                } else {
                    this.push('/dynamic/detail?articleId=' + articleId);
                }
            }
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		padding-bottom: 48px;
	}

	.margin-top-10 {
		margin-top: 20px;
	}

	.home-title{
		width: 750px;
		padding-top: 30px;
		text-align: center;
	}

	.slider {
		width: 750px;
		height: 450px;
	}
	.slider-image {
		width: 750px;
		height: 450px;
	}
	.slider-frame {
		width: 750px;
		height: 450px;
		position: relative;
	}
	.slider-index {
		right: 20px;
		bottom: 20px;
		color: #e994a9;
		position: absolute
	}
	.dynamic {
		width: 750px;
		flex-direction: row;
		flex-wrap: wrap;
		padding: 4px 18px 18px 18px;
	}
	.item-cell {
		flex-direction: row;
		padding: 16px;
	}
	.item-panel {
		width: 324px;
		height: 324px;
		flex-direction: column;
		justify-content: center;
		padding: 12px;
		background-color: #ffffff;
	}

	.item-panel-img {
		width: 300px;
		height: 300px;
		background-size: cover;
		background-position: 50%;
		background-repeat: no-repeat;
		overflow: hidden;
	}

	.item-panel-txt {
		width: 300px;
		font-size: 28px;
		color: #010101;
		line-height: 40px;
		padding-top: 16px;
		lines: 2;
	}

	.community-box {
		background-color: #ffffff;
		margin-bottom: 70px;
	}

	.community-main {
		margin-top: 10px;
	}

	.community-main-item {
		display: flex;
		border-bottom-width: 1px;
		border-bottom-color: #dddddd;
		padding: 20px;
		flex-direction: row;
	}

	.community-main-item-author {
		width: 95px;
		height: 95px;
		margin-right: 20px;
	}

	.community-main-item-content {
		flex: 1;
		padding-bottom: 15px;
	}

	.community-main-item-content-author-name {
		font-size: 30px;
		padding-top: -4px;
		padding-bottom: 8px;
		color: #5E7EC2;
		font-weight: bold;
	}

	.community-main-item-content-moment-content {
		lines: 3;
		width: 600px;
		font-size: 26px;
		line-height: 40px;
		padding-top: 5px;
		margin-bottom: 18px;
		color: #353535;
	}

	.community-main-item-content-card-picture {
		width: 450px;
		height: 300px;
	}

	.community-main-item-content-moment-many-pictures {
		width: 600px;
		flex-direction: row;
		flex-wrap: wrap;
		margin-bottom: -10px;
	}

	.community-main-item-content-moment-many-pictures-image {
		width: 190px;
		height: 190px;
		margin-right: 10px;
		margin-bottom: 10px;
	}

	.community-main-item-content-card-moment-info {
		display: flex;
		position: relative;
		padding-top: 20px;
		height: 50px;
		width: 600px;
		flex-direction: row;
	}

	.community-main-item-content-card-moment-info-time {
		margin-right: 20px;
		color: #999999;
		font-size: 24px;
	}

	.community-main-item-content-card-moment-info-delete{
		color: #576B95;
		font-size: 24px;
	}

	.community-main-item-content-card-moment-info-feedbac {
		flex: 1;
	}

	.community-main-item-content-card-moment-info-feedbac-item {
		position: absolute;
		right: 54px;
		top: 10px;
		width: 240px;
		height: 58px;
		border-radius: 6px;
		background-color: #313131;
		box-sizing: border-box;
		flex-direction: row;
	}

	.community-main-item-content-card-moment-info-feedbac-item-box{
		width: 99px;
		position: relative;
	}

	.community-main-item-content-card-moment-info-feedbac-item-xin{
		width: 28px;
		height: 28px;
		position: absolute;
		top: 14px;
		left: 14px;
	}

	.community-main-item-content-card-moment-info-feedbac-item-pinjia{
		width: 32px;
		height: 32px;
		position: absolute;
		top: 12px;
		left: 16px;
	}

	.community-main-item-content-card-moment-info-feedbac-item-fabulous {
		width: 69px;
		font-size: 24px;
		text-align: center;
		color: #ffffff;
		position: absolute;
		top: 10px;
		left: 40px;
	}

	.community-main-item-content-card-moment-info-feedbac-item-line {
		width: 14px;
		height: 54px;
		color: #ffffff;
		padding-top: 8px;
		padding-left: 9px;
	}

	.community-main-item-content-card-moment-info-feedbac-item-evaluate {
		width: 69px;
		font-size: 24px;
		line-height: 52px;
		color: #ffffff;
		position: absolute;
		top: 3px;
		left: 56px;
	}

	.community-main-item-content-card-moment-info-feedbac-image {
		position: absolute;
		right: 0px;
		top: 20px;
		width: 45px;
		height: 32px;
	}

	.community-main-item-content-moment-arrow {
		width: 30px;
		height: 12px;
		margin-top: 28px;
		margin-left: 30px;
		display: block;
	}

	.community-main-item-content-moment-likes {
		width: 600px;
		background-color: #F2F2F2;
		padding-left: 56px;
		padding-right: 10px;
		padding-top: 10px;
		padding-bottom: 10px;
		display: flex;
		flex-direction: row;
		flex-wrap: wrap-reverse;
		justify-content: end
	}

	.community-main-item-content-moment-likes-bottom-line {
		border-bottom-width: 1px;
		border-bottom-color: #dddddd;
	}


	.community-main-item-content-moment-likes-good{
		width: 36px;
		color: #576B95;
		font-size: 26px;
		position: absolute;
		top: 10px;
		left: 20px;
	}

	.community-main-item-content-moment-likes-list {
		color: #576B95;
		font-size: 24px;
		line-height: 28px;
		position: relative;
		padding-right: 14px;
	}
	.community-main-item-content-moment-likes-list-line{
		width: 20px;
		height: 22px;
		right: 0px;
		line-height: 6px;
		position: absolute;
		top: 6px;
		color: #576B95;
	}

	.community-main-item-content-comment-list {
		width: 600px;
		font-size: 24px;
		color: #454545;
		border-top-width: 1px;
		border-top-color: #dddddd;
		background-color: #F2F2F2;
		padding-left: 20px;
		padding-right: 10px;
		padding-top: 10px;
		padding-bottom: 15px;
	}
	.community-main-item-content-comment-list-one{
		border-top-width: 1px;
		border-top-color: #F2F2F2;
	}

	.input-bar {
		position: fixed;
		left: 0px;
		bottom: 0px;
		right: 0px;
		height: 90px;
		border-top-width: 2px;
		border-top-color: #DDD;
		background-color: #FFFFFF;
		flex-direction: row;
		justify-content: space-between;
	}
	.input {
		width: 610px;
		height: 90px;
		padding-left: 30px;
		color: #606060;
		background-color: #FFFFFF;
		font-size: 28px;
	}
	.btn-send {
		width: 140px;
		justify-content: center;
		border-left-width: 2px;
		border-left-color: #DDD;
		background-color: #e994a9;
	}
	.btn-send:active {
		background-color: #E0E0E0;
	}
	.btn-send-text {
		text-align: center;
		color: #ffffff;
		font-size: 28px;
	}
	.location {
		font-size: 24px;
		color: #576B95;
	}
	.the-end{
		width: 750px;
		text-align: center;
		color: #999999;
	}
</style>