<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">

        <div class="no-data"
             v-if="teamList.length == 0 && notData">
            <image class="no-data-img"
                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
            <text class="no-data-text">当前没有数据</text>
        </div>

        <div v-for="oneItem in teamList"
             :key="oneItem.memberId">
            <wxc-cell class="team-cell"
                      :has-top-border="true">
                <div class="team-cell-content"
                     slot="label">
                    <image class="team-cell-content-avatar"
                           :src="imageHost + oneItem.memberAvatarPath"></image>
                    <div class="team-one-cell-content-label">
                        <text class="team-cell-content-title" lines="1">{{oneItem.memberNickName}}({{oneItem.systemCreateTime}})</text>
                        <text class="team-cell-content-desc">{{oneItem.memberLevelName}}</text>
                    </div>
                </div>
                <div class="addChildren" v-if="oneItem.CHILDREN" @click="handleButton(oneItem.memberId)">
                        <image class="addChildren-img"
                               v-if="!oneItem.memberIsShowChildren"
                               src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                        <image class="addChildren-img"
                               v-if="oneItem.memberIsShowChildren"
                               src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                        <text class="addChildren-img-badge">{{oneItem.CHILDREN.length}}</text>
                </div>
            </wxc-cell>
            <div class="children-cell background-ffffff"
                 v-for="twoItem in oneItem.CHILDREN"
                 v-if="oneItem.memberIsShowChildren"
                 :key="twoItem.memberId">
                <wxc-cell class="team-children-cell"
                          :has-top-border="false"
                          :has-bottom-border="true">
                    <div class="team-cell-content"
                         slot="label">
                        <image class="team-cell-content-avatar"
                               :src="imageHost + twoItem.memberAvatarPath"></image>
                        <div class="team-two-cell-content-label">
                            <text class="team-cell-content-title" lines="1">{{twoItem.memberNickName}}({{twoItem.systemCreateTime}})</text>
                            <text class="team-cell-content-desc">{{twoItem.memberLevelName ? twoItem.memberLevelName : '待审核'}}</text>
                        </div>
                    </div>
                    <div class="addChildren" v-if="twoItem.CHILDREN" @click="handleButton(twoItem.memberId)">
                        <image class="addChildren-img"
                               v-if="!twoItem.memberIsShowChildren"
                               src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                        <image class="addChildren-img"
                               v-if="twoItem.memberIsShowChildren"
                               src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                        <text class="addChildren-img-badge">{{twoItem.CHILDREN.length}}</text>
                    </div>
                </wxc-cell>
                <div class="children-cell background-ffffff"
                     v-for="threeItem in twoItem.CHILDREN"
                     v-if="twoItem.memberIsShowChildren"
                     :key="threeItem.memberId">
                    <wxc-cell class="team-three-children-cell"
                              cell-style="padding-left: 80px"
                              :has-top-border="false"
                              :has-bottom-border="true">
                        <div class="team-cell-content"
                             slot="label">
                            <image class="team-cell-content-avatar"
                                   :src="imageHost + threeItem.memberAvatarPath"></image>
                            <div class="team-three-cell-content-label">
                                <text class="team-cell-content-title" lines="1">{{threeItem.memberNickName}}({{threeItem.systemCreateTime}})</text>
                                <text class="team-cell-content-desc">{{threeItem.memberLevelName ? threeItem.memberLevelName : '待审核'}}</text>
                            </div>
                        </div>
                        <div class="addChildren" v-if="threeItem.CHILDREN" @click="handleButton(threeItem.memberId)">
                            <image class="addChildren-img"
                                   v-if="!threeItem.memberIsShowChildren"
                                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                            <image class="addChildren-img"
                                   v-if="threeItem.memberIsShowChildren"
                                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                            <text class="addChildren-img-badge">{{threeItem.CHILDREN.length}}</text>
                        </div>
                    </wxc-cell>
                    <div class="children-cell background-ffffff"
                         v-for="fourItem in threeItem.CHILDREN"
                         v-if="threeItem.memberIsShowChildren"
                         :key="fourItem.memberId">
                        <wxc-cell class="team-four-children-cell"
                                  :has-top-border="false"
                                  :has-bottom-border="true">
                            <div class="team-cell-content"
                                 slot="label">
                                <image class="team-cell-content-avatar"
                                       :src="imageHost + fourItem.memberAvatarPath"></image>
                                <div class="team-four-cell-content-label">
                                    <text class="team-cell-content-title" lines="1">{{fourItem.memberNickName}}({{fourItem.systemCreateTime}})</text>
                                    <text class="team-cell-content-desc">{{fourItem.memberLevelName ? fourItem.memberLevelName : '待审核'}}</text>
                                </div>
                            </div>
                            <div class="addChildren" v-if="fourItem.CHILDREN" @click="handleButton(fourItem.memberId)">
                                <image class="addChildren-img"
                                       v-if="!fourItem.memberIsShowChildren"
                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                                <image class="addChildren-img"
                                       v-if="fourItem.memberIsShowChildren"
                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                                <text class="addChildren-img-badge">{{fourItem.CHILDREN.length}}</text>
                            </div>
                        </wxc-cell>
                        <div class="children-cell background-ffffff"
                             v-for="fiveItem in fourItem.CHILDREN"
                             v-if="fourItem.memberIsShowChildren"
                             :key="fiveItem.memberId">
                            <wxc-cell class="team-five-children-cell"
                                      :has-top-border="false"
                                      :has-bottom-border="true">
                                <div class="team-cell-content"
                                     slot="label">
                                    <image class="team-cell-content-avatar"
                                           :src="imageHost + fiveItem.memberAvatarPath"></image>
                                    <div class="team-five-cell-content-label">
                                        <text class="team-cell-content-title" lines="1">{{fiveItem.memberNickName}}({{fiveItem.systemCreateTime}})</text>
                                        <text class="team-cell-content-desc">{{fiveItem.memberLevelName ? fiveItem.memberLevelName : '待审核'}}</text>
                                    </div>
                                </div>
                                <div class="addChildren" v-if="fiveItem.CHILDREN" @click="handleButton(fiveItem.memberId)">
                                    <image class="addChildren-img"
                                           v-if="!fiveItem.memberIsShowChildren"
                                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                                    <image class="addChildren-img"
                                           v-if="fiveItem.memberIsShowChildren"
                                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                                    <text class="addChildren-img-badge">{{fiveItem.CHILDREN.length}}</text>
                                </div>
                            </wxc-cell>
                            <div class="children-cell background-ffffff"
                                 v-for="sixItem in fiveItem.CHILDREN"
                                 v-if="fiveItem.memberIsShowChildren"
                                 :key="sixItem.memberId">
                                <wxc-cell class="team-six-children-cell"
                                          :has-top-border="false"
                                          :has-bottom-border="true">
                                    <div class="team-cell-content"
                                         slot="label">
                                        <image class="team-cell-content-avatar"
                                               :src="imageHost + sixItem.memberAvatarPath"></image>
                                        <div class="team-six-cell-content-label">
                                            <text class="team-cell-content-title" lines="1">{{sixItem.memberNickName}}({{sixItem.systemCreateTime}})</text>
                                            <text class="team-cell-content-desc">{{sixItem.memberLevelName ? sixItem.memberLevelName : '待审核'}}</text>
                                        </div>
                                    </div>
                                    <div class="addChildren" v-if="sixItem.CHILDREN" @click="handleButton(sixItem.memberId)">
                                        <image class="addChildren-img"
                                               v-if="!sixItem.memberIsShowChildren"
                                               src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                                        <image class="addChildren-img"
                                               v-if="sixItem.memberIsShowChildren"
                                               src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                                        <text class="addChildren-img-badge">{{sixItem.CHILDREN.length}}</text>
                                    </div>
                                </wxc-cell>
                                <div class="children-cell background-ffffff"
                                     v-for="sevenItem in sixItem.CHILDREN"
                                     v-if="sixItem.memberIsShowChildren"
                                     :key="sevenItem.memberId">
                                    <wxc-cell class="team-seven-children-cell"
                                              :has-top-border="false"
                                              :has-bottom-border="false">
                                        <div class="team-cell-content"
                                             slot="label">
                                            <image class="team-cell-content-avatar"
                                                   :src="imageHost + sevenItem.memberAvatarPath"></image>
                                            <div class="team-seven-cell-content-label">
                                                <text class="team-cell-content-title" lines="1">{{sevenItem.memberNickName}}({{sevenItem.systemCreateTime}})</text>
                                                <text class="team-cell-content-desc">{{sevenItem.memberLevelName ? sevenItem.memberLevelName : '待审核'}}</text>
                                            </div>
                                        </div>
                                    </wxc-cell>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';

    import mixin from '../../../common/mixin';

    export default {
        components: {
            WxcCell
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isSelectMemberId: '',
            teamList: [],
            notData: false,
            memberIsShowChildren: '',
            isShowChildren: true
        }),
        created () {

        },
        mounted () {
            this.changeTitle('我的代理');
            this.handleLoad();
        },
        methods: {
            handleButton: function (id) {
                var teamList = this.teamList;

                this.handleCheck(teamList, id);

                this.teamList = teamList;
            },
            handleCheck: function (teamList, id) {
                for (let i = 0; i < teamList.length; i++) {
                    if (teamList[i].memberId === id) {
                        teamList[i].memberIsShowChildren = !teamList[i].memberIsShowChildren;
                    }

                    if (typeof (teamList[i].CHILDREN) !== 'undefined') {
                        this.handleCheck(teamList[i].CHILDREN, id);
                    }
                }
            },
            handleLoad() {
                this.request({
                    url: '/xingxiao/member/mobile/v1/my/team',
                    data: {},
                    success: (teamList) => {
                        // for(var i = 0; i < data.length; i++) {
                        //     var member = data[i];
                        //     member.memberIsShowChildren = false;
                        //     member.systemCreateTime = this.timestampToTime(data[i].systemCreateTime)
                        //     if (member.CHILDREN && member.CHILDREN.length > 0) {
                        //         for (var j = 0; j < member.CHILDREN.length; j++) {
                        //             member.CHILDREN[j].memberIsShowChildren = false;
                        //             member.CHILDREN[j].systemCreateTime = this.timestampToTime(member.CHILDREN[j].systemCreateTime);
                        //             if (member.CHILDREN[j].CHILDREN && member.CHILDREN[j].CHILDREN.length > 0) {
                        //                 for (var b = 0; b < member.CHILDREN[j].CHILDREN.length; b++) {
                        //                     member.CHILDREN[j].CHILDREN[b].memberIsShowChildren = false;
                        //                     member.CHILDREN[j].CHILDREN[b].systemCreateTime = this.timestampToTime(member.CHILDREN[j].CHILDREN[b].systemCreateTime);
                        //                     if (member.CHILDREN[j].CHILDREN[b].CHILDREN && member.CHILDREN[j].CHILDREN[b].CHILDREN.length > 0) {
                        //                         for (var d = 0; d < member.CHILDREN[j].CHILDREN[b].CHILDREN.length; d++) {
                        //                             member.CHILDREN[j].CHILDREN[b].CHILDREN[d].memberIsShowChildren = false;
                        //                             member.CHILDREN[j].CHILDREN[b].CHILDREN[d].systemCreateTime = this.timestampToTime(member.CHILDREN[j].CHILDREN[b].CHILDREN[d].systemCreateTime);
                        //                             if (member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN && member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN.length > 0) {
                        //                                 for (var e = 0; e < member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN.length; e++) {
                        //                                     member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].memberIsShowChildren = false;
                        //                                     member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].systemCreateTime = this.timestampToTime(member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].systemCreateTime);
                        //                                     if (member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN && member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN.length > 0) {
                        //                                         for (var f = 0; f < member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN.length; f++) {
                        //                                             member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].memberIsShowChildren = false;
                        //                                             member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].systemCreateTime = this.timestampToTime(member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].systemCreateTime);
                        //
                        //                                             if (member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].CHILDREN && member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].CHILDREN.length > 0) {
                        //                                                 for (var g = 0; g < member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].CHILDREN.length; g++) {
                        //                                                     member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].CHILDREN[g].memberIsShowChildren = false;
                        //                                                     member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].CHILDREN[g].systemCreateTime = this.timestampToTime(member.CHILDREN[j].CHILDREN[b].CHILDREN[d].CHILDREN[e].CHILDREN[f].CHILDREN[g].systemCreateTime);
                        //                                                 }
                        //                                             }
                        //                                         }
                        //                                     }
                        //                                 }
                        //                             }
                        //                         }
                        //                     }
                        //                 }
                        //             }
                        //         }
                        //     }
                        // }
                        if (teamList.length > 0) {
                            this.handleTeam(teamList);
                        }

                        this.teamList = teamList;
                        this.notData = true;
                    }
                });
            },
            handleTeam(teamList) {
                if(teamList) {
                    for (let i = 0; i < teamList.length; i++) {
                        teamList[i].memberIsShowChildren = false;
                        teamList[i].systemCreateTime = this.timestampToTime(teamList[i].systemCreateTime);
                        this.handleTeam(teamList[i].CHILDREN);
                    }
                }
            },
            timestampToTime(timestamp) {
                var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                var Y = date.getFullYear() + '-';
                var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
                var D = date.getDate() + ' ';
                return Y + M + D;
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        position: relative;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
        /*padding-top: 20px;*/
    }

    .background-ffffff{
        background-color: #ffffff;
    }

    .padding-left-20{
        padding-left: 20px;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

    .team-cell {
        width: 750px;
        margin-top: 20px;
    }
    .team-cell-content {
        flex-direction: row;
        overflow: hidden;
    }
    .team-cell-content-avatar {
        width: 100px;
        height: 100px;
    }
    .team-cell-content-title{
        lines: 1;
    }
    .team-one-cell-content-label {
        width: 498px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-two-cell-content-label {
        width: 468px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-three-cell-content-label {
        width: 438px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-four-cell-content-label {
        width: 408px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-five-cell-content-label {
        width: 370px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-six-cell-content-label {
        width: 340px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-seven-cell-content-label {
        width: 330px;
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-cell-content-desc {
        color: #e994a9;
        font-size: 30px;
        margin-top: 8px;
    }
    .addChildren {
        position: relative;
    }
    .addChildren-img {
        width: 80px;
        height: 80px;
    }
    .addChildren-img-badge {
        display:inline-block;
        padding: 4px 10px;
        min-width: 16px;
        border-radius: 28px;
        background-color: #e994a9;
        color: #FFFFFF;
        line-height: 20px;
        text-align: center;
        font-size: 24px;
        position: absolute;
        top: 0px;
        right: 0px;
    }
    .children-cell {
        border: none;
    }
    .team-children-cell {
        width: 720px;
        margin-left: 30px;
    }

    .team-three-children-cell {
        width: 690px;
        margin-left: 60px;
    }
    .team-four-children-cell {
        width: 660px;
        margin-left: 90px;
    }
    .team-five-children-cell {
        width: 630px;
        margin-left: 120px;
    }
    .team-six-children-cell {
        width: 600px;
        margin-left: 150px;
    }
    .team-seven-children-cell {
        width: 570px;
        margin-left: 180px;
    }

</style>
