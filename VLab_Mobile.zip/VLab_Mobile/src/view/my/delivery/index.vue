<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <wxc-cell class="balance-cell"
                  :has-top-border="true"
                  :has-bottom-border="true"
                  :has-arrow="true"
                  v-for="address in addressList"
                  :key="address.memberAddressId"
                  @wxcCellClicked="handleAddress(address.memberAddressId)">
            <div class="balance-cell-content"
                 slot="label">
                <div class="balance-cell-title">
                    <text>{{address.memberAddressName}} {{address.memberAddressMobile}}</text>
                    <div class="balance-cell-title-address">
                        <text class="balance-cell-title-address-text">{{address.memberAddressProvince}}{{address.memberAddressCity}}{{address.memberAddressArea}}{{address.memberAddressDetail}}</text>
                    </div>
                </div>
            </div>
            <text slot="value" class="default" v-if="address.memberAddressIsDefault">默认</text>
        </wxc-cell>

        <text class="add-card" @click="handleAddAddress">新增收货地址</text>
        <!--<div class="no-data">-->
        <!--<image class="no-data-img"-->
        <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>-->
        <!--<div class="no-data-text">当前没有数据</div>-->
        <!--</div>-->
    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';

    import mixin from '../../../common/mixin';

    export default {
        components: {
            WxcCell
        },
        mixins: [mixin],
        props: {},
        data: () => ({
            addressList: '',
            memberAddressName: '',
            memberAddressId: '',
            selectAddress: ''
        }),
        mounted() {
            this.handleUserAddressList();
            this.changeTitle('我的地址');
            this.selectAddress = decodeURI(decodeURI(this.getParameter('selectAddress')));

            this.globalEvent.addEventListener('handleRefresh', (data) => {
                this.handleUserAddressList();
            });
        },
        methods: {
            handleAddAddress() {
                this.push('/my/delivery/addDelivery');
            },
            handleAddress(memberAddressId) {
                if (this.selectAddress == "true") {
                    for (var i = 0; i <= this.addressList.length; i++) {
                        if (memberAddressId == this.addressList[i].memberAddressId) {
                            this.chuangshi.sendEventListener({
                                name: 'selectAddress',
                                data: {
                                    memberAddressId: this.addressList[i].memberAddressId,
                                    memberAddressProvince: this.addressList[i].memberAddressProvince,
                                    memberAddressName: this.addressList[i].memberAddressName,
                                    memberAddressCity: this.addressList[i].memberAddressCity,
                                    memberAddressArea: this.addressList[i].memberAddressArea,
                                    memberAddressDetail: this.addressList[i].memberAddressDetail
                                }
                            });
                            this.pop();
                        }
                    }
                }
                else {
                    this.push('/my/delivery/detail?memberAddressId=' + memberAddressId);
                }
            },
            handleUserAddressList() {
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/list',
                    data: {},
                    success: (data) => {
                        this.addressList = data.list;
                        for (var i = 0; i < this.addressList.length; i++) {
                            this.memberAddressId = this.addressList[i].memberAddressId
                        }
                    },
                    error: () => {

                    }
                });
            }

        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        padding-bottom: 160px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .balance-cell {
        width: 750px;
        height: 150px;
        margin-top: 20px;
    }

    .balance-cell-content {
        flex-direction: row;
    }

    .balance-cell-title {
        padding-top: 8px;
        margin-left: 20px;
        font-size: 34px;
    }

    .balance-cell-title-address {
        width: 590px;
        overflow : hidden;
    }

    .balance-cell-title-address-text{
        color: #999999;
        font-size: 30px;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    .default {
        color: #999999;
        font-size: 30px;
    }

    .add-card {
        background-color: #e994a9;
        width: 750px;
        height: 100px;
        line-height: 100px;
        color: #ffffff;
        font-size: 34px;
        text-align: center;
        position: fixed;
        bottom: 0px;
    }

    .no-data {
        position: absolute;
        top: 500px;
        left: 315px;
        width: 120px;
        height: 120px;
    }

    .no-data-img {
        width: 120px;
        height: 120px;
    }

    .no-data-text {
        margin-left: -28px;
        width: 180px;
        height: 30px;
        color: #888;
        font-size: 14px;
        text-size: 14px;
        text-align: center;
    }
</style>
