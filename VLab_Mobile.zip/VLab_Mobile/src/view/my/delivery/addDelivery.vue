<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="page-box">
            <div class="balance">
                <div class="balance-label" name="label">收货人：</div>
                <div class="balance-title" name="title">
                    <input class="balance-title-input" placeholder="请输入收货人" v-model="memberAddressName">
                </div>
            </div>
            <div class="balance">
                <div class="balance-label" name="label">手机号码：</div>
                <div class="balance-title" name="title">
                    <input type="number" class="balance-title-input" placeholder="请输入手机号码" v-model="memberAddressMobile">
                </div>
            </div>

            <Picker :memberAddressProvince="memberAddressProvince"
                    :memberAddressCity="memberAddressCity"
                    :memberAddressArea="memberAddressArea"></Picker>

            <div class="balance">
                <textarea class="textarea" placeholder="请输入详细地址" v-model="memberAddressDetail"></textarea>
            </div>
            <wxc-cell :has-top-border="true"
                      class="margin-top-20">
                <div slot="label">设为默认地址</div>
                <switch slot="value"
                        :checked="memberAddressIsDefault"
                        @change="handleIsDefault"></switch>
            </wxc-cell>
            <text class="sublime" @click="handleAddAddress">添加</text>
        </div>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading} from 'weex-ui';
    import Picker from '../../../common/picker-3';

    import mixin from '../../../common/mixin';

    export default {
        components: {
            WxcCell,
            Picker,
            WxcLoading
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            memberAddressId: '',
            memberAddressName: '',
            memberAddressMobile: '',
            memberAddressProvince: '',
            memberAddressCity: '',
            memberAddressArea: '',
            memberAddressDetail: '',
            memberAddressIsDefault: true,
            memberAddressAreaId: '',
            memberAddressCityId: '',
            memberAddressProvinceId: '',
            wxcDialogConfirmShow: false,
            visible: false
        }),
        created () {
        },
        mounted () {
            this.changeTitle('添加地址');

            this.globalEvent.addEventListener('handleSelectAddress', (data) => {
                this.memberAddressProvince = data.memberAddressProvince,
                    this.memberAddressCity = data.memberAddressCity,
                    this.memberAddressArea = data.memberAddressArea
            });
        },
        methods: {
            dialogConfirmBtnNo () {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            handleAddAddress() {
                if(this.memberAddressName == '' || typeof (this.memberAddressName) == 'undefind'){
                    this.toast("收货人不能为空");
                    return;
                }
                if(this.memberAddressMobile == '' || typeof (this.memberAddressMobile) == 'undefind' || !this.isPhone(this.memberAddressMobile)){
                    this.toast("手机号码不合法");
                    return;
                }
                if(this.memberAddressProvince == '' || typeof (this.memberAddressProvince) == 'undefind'){
                    this.toast("省市区不能为空");
                    return;
                }
                if(this.memberAddressDetail == '' || typeof (this.memberAddressDetail) == 'undefind'){
                    this.toast("详细地址不能为空");
                    return;
                }
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/save',
                    data: {
                        memberAddressAreaId: this.memberAddressAreaId,
                        memberAddressCityId: this.memberAddressCityId,
                        memberAddressProvinceId: this.memberAddressProvinceId,
                        memberAddressId: this.memberAddressId,
                        memberAddressName: this.memberAddressName,
                        memberAddressMobile: this.memberAddressMobile,
                        memberAddressProvince: this.memberAddressProvince,
                        memberAddressCity: this.memberAddressCity,
                        memberAddressArea: this.memberAddressArea,
                        memberAddressDetail: this.memberAddressDetail,
                        memberAddressIsDefault: this.memberAddressIsDefault,
                    },
                    success: () => {
                        this.isLoad = false;
                        this.chuangshi.sendEventListener({
                            name: 'handleRefresh',
                            data: {    }
                        });

                        this.toast('修改成功');
                        this.pop();
                    },
                    error: () => {

                    }
                });
            },
            handleDelete() {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            handleReviseCity() {
                this.visible = true;
            },
            handleIsDefault() {
                this.memberAddressIsDefault = !this.memberAddressIsDefault
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .textarea{
        width: 710px;
        height: 150px;
    }

    .margin-top-20{
        margin-top: 20px;
    }

    .page-box{
        margin-top: 20px;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        border-top-style: solid;
    }

    .balance{
        width: 750px;
        flex-direction: row;
        flex-wrap: wrap;
        background-color: #ffffff;
        padding: 24px;
        border-bottom-color: #e2e2e2;
        border-bottom-width: 1px;
        border-bottom-style: solid;
    }
    .balance-label{
        width: 190px;
    }
    .balance-title{
        flex: 1;
    }
    .balance-title-input{
        flex: 1;
    }
    .balance-cell {
        flex-direction: row;
    }
    .balance-cell-title {
        width: 190px;
    }
    .sublime{
        height:100px;
        line-height:100px;
        border-radius: 12px;
        position:fixed;
        left:0px;
        right:0px;
        bottom:0px;
        font-size:34px;
        margin-top:80px;
        text-align:center;
        color:#ffffff;
        background-color:#e994a9;
    }
</style>
