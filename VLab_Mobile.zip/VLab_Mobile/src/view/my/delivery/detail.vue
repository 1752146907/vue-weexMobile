<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="page-box"
             v-if="memberAddressId != ''">
            <div class="balance">
                <div class="balance-label" name="label">收货人：</div>
                <div class="balance-title" name="title">
                    <input class="balance-title-input" placeholder="请输入收货人" v-model="memberAddressName">
                </div>
            </div>
            <div class="balance border-buttom-none">
                <div class="balance-label" name="label">手机号码：</div>
                <div class="balance-title" name="title">
                    <input type="number" class="balance-title-input" placeholder="请输入手机号码" v-model="memberAddressMobile">
                </div>
            </div>

            <Picker :memberAddressProvince="memberAddressProvince"
                    :memberAddressCity="memberAddressCity"
                    :memberAddressArea="memberAddressArea"></Picker>

            <div class="balance">
                <textarea class="textarea" placeholder="请输入详细地址" v-model="memberAddressDetail"></textarea>
            </div>
            <wxc-cell :has-top-border="true"
                      class="margin-top-20"
                      v-if="memberAddressAreaId">
                <div slot="label">设为默认地址</div>
                <switch slot="value"
                        :checked="memberAddressIsDefault"
                        @change="handleIsDefault"></switch>
            </wxc-cell>
            <text class="sublime" @click="handleRevise">保存</text>
            <text class="delete" @click="handleDelete">删除</text>
        </div>

        <wxc-dialog title="确定删除"
                    content="本操作不可恢复，您确定删除本条地址信息吗？"
                    :show="wxcDialogConfirmShow"
                    main-btn-color="#e994a9"
                    @wxcDialogCancelBtnClicked="dialogConfirmBtnNo"
                    @wxcDialogConfirmBtnClicked="dialogConfirmBtnClick">
        </wxc-dialog>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcDialog, WxcLoading} from 'weex-ui';

    import mixin from '../../../common/mixin';
    import Picker from '../../../common/picker-3';


    export default {
        components: {
            WxcCell,
            WxcDialog,
            Picker,
            WxcLoading
        },
        mixins: [mixin],
        props: [],
        data: () => ({
            isLoad: false,
            memberAddressId: '',
            memberAddressName: '',
            memberAddressMobile: '',
            memberAddressDetail: '',
            memberAddressProvince: '',
            memberAddressCity: '',
            memberAddressArea: '',
            memberAddressIsDefault: false,
            memberAddressAreaId: '',
            memberAddressCityId: '',
            memberAddressProvinceId: '',
            wxcDialogConfirmShow: false,
			visible: false
        }),
        created () {

        },
        mounted () {
            this.memberAddressId = decodeURI(decodeURI(this.getParameter('memberAddressId')));
            this.handleUserAddressDetails();
            this.changeTitle('地址详情');

            this.globalEvent.addEventListener('handleSelectAddress', (data) => {
                this.memberAddressProvince = data.memberAddressProvince,
                this.memberAddressCity = data.memberAddressCity,
                this.memberAddressArea = data.memberAddressArea
            });
        },
        methods: {
            dialogConfirmBtnNo () {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            dialogConfirmBtnClick () {
                this.isLoad = true;
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/delete',
                    data: {
                        memberAddressId: this.memberAddressAreaId,
                    },
                    success: () => {
                        this.isLoad = false;
                        this.chuangshi.sendEventListener({
                            name: 'handleRefresh',
                            data: {    }
                        });

                        this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
                        this.toast("删除成功");
                        this.pop();
                    },
                    error: () => {

                    }
                });
            },
            handleUserAddressDetails() {
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/find',
                    data: {
                        memberAddressId: this.memberAddressId
                    },
                    success: (data) => {
                        if (data) {
                            this.memberAddressAreaId = data.memberAddressId;
                            this.memberAddressName = data.memberAddressName;
                            this.memberAddressMobile = data.memberAddressMobile;
                            this.memberAddressProvince = data.memberAddressProvince;
                            this.memberAddressCity = data.memberAddressCity;
                            this.memberAddressArea = data.memberAddressArea;
                            this.memberAddressDetail = data.memberAddressDetail;
                            this.memberAddressIsDefault = data.memberAddressIsDefault;
                            this.address = [data.memberAddressProvince, data.memberAddressCity, data.memberAddressArea];
                        }
                    },
                    error: () => {

                    }
                });
            },
            handleRevise() {
                if(this.memberAddressName == '' || typeof (this.memberAddressName) == 'undefind'){
                    this.toast("收货人不能为空");
                    return;
                }
                if(this.memberAddressMobile == '' || typeof (this.memberAddressMobile) == 'undefind' || !this.isPhone(this.memberAddressMobile)){
                    this.toast("手机号码不合法");
                    return;
                }
                if(this.memberAddressProvince == '' || typeof (this.memberAddressProvince) == 'undefind'){
                    this.toast("省市区不能为空");
                    return;
                }
                if(this.memberAddressDetail == '' || typeof (this.memberAddressDetail) == 'undefind'){
                    this.toast("详细地址不能为空");
                    return;
                }
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/update',
                    data: {
                        memberAddressAreaId: this.memberAddressAreaId,
                        memberAddressCityId: this.memberAddressCityId,
                        memberAddressProvinceId: this.memberAddressProvinceId,
                        memberAddressId: this.memberAddressId,
                        memberAddressName: this.memberAddressName,
                        memberAddressMobile: this.memberAddressMobile,
                        memberAddressProvince: this.memberAddressProvince,
                        memberAddressCity: this.memberAddressCity,
                        memberAddressArea: this.memberAddressArea,
                        memberAddressDetail: this.memberAddressDetail,
                        memberAddressIsDefault: this.memberAddressIsDefault,
                    },
                    success: () => {
                        this.isLoad = false;
                        this.chuangshi.sendEventListener({
                            name: 'handleRefresh',
                            data: {    }
                        });

                        this.toast('修改成功');
                        this.pop();
                    },
                    error: () => {

                    }
                });
            },
            handleDelete() {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            // handleReviseCity() {
				// this.visible = true;
            // },
            handleIsDefault() {
                this.memberAddressIsDefault = !this.memberAddressIsDefault
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .border-buttom-none{
        border-bottom: none;
    }

    .textarea{
        width: 710px;
        height: 150px;
    }

    .margin-top-20{
        margin-top: 20px;
    }

    .page-box{
        margin-top: 20px;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        border-top-style: solid;
    }

    .balance{
        width: 750px;
        flex-direction: row;
        flex-wrap: wrap;
        background-color: #ffffff;
        padding: 24px;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
        border-bottom-style: solid;
    }
    .balance-label{
        width: 190px;
    }
    .balance-title{
        flex: 1;
    }
    .balance-title-input{
        flex: 1;
    }
    .balance-cell {
        flex-direction: row;
    }
    .balance-cell-title {
        width: 190px;
    }
    .sublime{
        height:100px;
        line-height:100px;
        border-radius: 12px;
        position:fixed;
        left:0px;
        right:0px;
        bottom:0px;
        font-size:34px;
        margin-top:80px;
        text-align:center;
        color:#ffffff;
        background-color:#e994a9;
    }
    .delete {
        height:100px;
        line-height:100px;
        border-radius: 12px;
        position:fixed;
        left:0px;
        right:0px;
        bottom:110px;
        font-size:34px;
        margin-top:80px;
        text-align:center;
        color:#000000;
        background-color:#ffffff;
        border-top-color: #e2e2e2;
        border-top-width: 1px;
        border-bottom-color: #e2e2e2;
        border-bottom-width: 1px;
    }
    .btn-wrap {
        background-color: #ccc;
        height: 88px;
        font-size: 38px;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }
    .btn {
        line-height: 88px;
        height: 88px;
        width: 100px;
        text-align: center;
        color: #007aff;
        font-size: 32px;
    }
    .flex {
        flex-direction: row;
    }
    .flex-1 {
        flex: 1;
    }
</style>
