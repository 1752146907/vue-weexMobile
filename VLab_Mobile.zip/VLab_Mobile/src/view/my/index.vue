<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<div class="header-top"
				  :has-top-border="false"
				  :has-bottom-border="true">
			<div class="header-top-user">
				<image class="user-avatar"
					   :src="imageHost + userAvatar"></image>
				<text class="user-name">{{userName}}</text>
			</div>
		</div>
		<wxc-cell class="balance-cell"
				  :has-top-border="true"
				  :has-bottom-border="true"
				  :has-arrow="true"
				  @wxcCellClicked="handleToBalance">
			<div class="balance-cell-content"
				 slot="label">
				<image class="balance-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/money.png"></image>
				<div class="balance-cell-title">余额</div>
			</div>
			<div class="balance-cell-desc">提现</div>
		</wxc-cell>
		<wxc-cell class="official-cell"
				  :has-bottom-border="true"
				  :has-arrow="true"
                  :cell-style="{marginBottom: '20px'}"
				  @wxcCellClicked="handleToOfficial">
			<div class="balance-cell-content"
				 slot="label">
				<image class="balance-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/vip.png"></image>
				<div class="balance-cell-title">官方消息</div>
			</div>
			<div class="balance-cell-desc">更多</div>
		</wxc-cell>
		<!--<wxc-cell class="balance-cell"-->
				  <!--:has-top-border="true"-->
				  <!--:has-bottom-border="true"-->
				  <!--:has-arrow="true"-->
				  <!--@wxcCellClicked="handleToOrderList('ALL')">-->
			<!--<div class="balance-cell-content"-->
				 <!--slot="label">-->
				<!--<image class="balance-icon"-->
					   <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/form.png"></image>-->
				<!--<div class="balance-cell-title">我的订单</div>-->
			<!--</div>-->
			<!--<div class="order-cell-desc">查看全部订单</div>-->
		<!--</wxc-cell>-->
		<!--<wxc-cell class="order-cell"-->
				  <!--:has-top-border="false"-->
				  <!--:has-bottom-border="true">-->
			<!--<div class="order-cell-content"-->
				 <!--slot="label">-->
				<!--<div class="order-cell-content-item"  @click="handleToOrderList('WAITING_PAID')">-->
					<!--<image class="order-cell-content-item-icon"-->
						   <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pay.png"></image>-->
					<!--<text class="pay-img-badge" v-if="memberWaitPay > 0">{{memberWaitPay}}</text>-->
					<!--<div class="order-cell-content-item-text">待付款</div>-->
				<!--</div>-->
				<!--<div class="order-cell-content-item" @click="handleToOrderList('WAITING_DELIVERY')">-->
					<!--<image class="order-cell-content-item-icon"-->
						   <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/send.png"></image>-->
					<!--<text class="pay-img-badge" v-if="memberWaitSend > 0">{{memberWaitSend}}</text>-->
					<!--<div class="order-cell-content-item-text">代发货</div>-->
				<!--</div>-->
				<!--<div class="order-cell-content-item" @click="handleToOrderList('WAITING_RECEIVE')">-->
					<!--<image class="order-cell-content-item-icon"-->
						   <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/deliver.png"></image>-->
					<!--<text class="pay-img-badge" v-if="memberWaitReceive > 0">{{memberWaitReceive}}</text>-->
					<!--<div class="order-cell-content-item-text">待收货</div>-->
				<!--</div>-->
				<!--<div class="order-cell-content-item" @click="handleToOrderList('COMPLETE')">-->
					<!--<image class="order-cell-content-item-icon"-->
						   <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/comment.png"></image>-->
					<!--<div class="order-cell-content-item-text">已完成</div>-->
				<!--</div>-->
			<!--</div>-->
		<!--</wxc-cell>-->
		<div class="body-item">
			<div class="body-item-left"
				 @click="handleToCircle">
				<image class="body-item-left-icon circle-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-07-icon.png"></image>
				<div class="body-item-left-title">我的圈子</div>
			</div>
			<div class="body-item-right"
                 @click="handleEcaluate">
				<image class="body-item-right-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-08-icon.png"></image>
				<div class="body-item-right-title">我的评论</div>
			</div>
		</div>
		<div class="body-item">
			<div class="body-item-left"
				 @click="handleToOrderList('ALL')">
				<image class="body-item-left-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-06-icon.png"></image>
				<div class="body-item-left-title">进货管理</div>
			</div>
			<div class="body-item-right"
				 @click="handleToDeliveryOrderList('ALL')">
				<image class="body-item-right-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-04-icon.png"></image>
				<div class="body-item-right-title">发货管理</div>
			</div>
		</div>
		<div class="body-item">
			<div class="body-item-left"
				 @click="handleToTeam">
				<image class="body-item-left-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-01-icon.png"></image>
				<div class="body-item-left-title">我的代理</div>
			</div>
			<div class="body-item-right"
				 @click="handleExit">
				<image class="body-item-right-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-02-icon.png"></image>
				<div class="body-item-right-title">我的授权</div>
			</div>
		</div>
		<div class="body-item body-item-bottom">
			<div class="body-item-left"
				 @click="handleToQrcode">
				<image class="body-item-left-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-03-icon.png"></image>
				<div class="body-item-left-title">发展代理</div>
			</div>
			<div class="body-item-right"
				 @click="handleToAddressList">
				<image class="body-item-right-icon"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-05-icon.png"></image>
				<div class="body-item-right-title">收货地址</div>
			</div>
		</div>

		<!--<wxc-cell class="balance-cell"-->
				  <!--:has-top-border="true"-->
				  <!--:has-bottom-border="true"-->
				  <!--:has-arrow="true"-->
				  <!--@wxcCellClicked="handleToBankCard">-->
			<!--<div class="balance-cell-content"-->
				 <!--slot="label">-->
				<!--<image class="balance-icon"-->
					   <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/vip.png"></image>-->
				<!--<div class="balance-cell-title">我的银行卡</div>-->
			<!--</div>-->
		<!--</wxc-cell>-->
		<wxc-dialog title="确定退出"
					content="退出需重新授权登录，您真的要选择退出吗？"
					cancel-text="再想想"
					confirm-text="退出"
					:show="showDialog"
					main-btn-color="#e994a9"
					@wxcDialogCancelBtnClicked="wxcExitCancel"
					@wxcDialogConfirmBtnClicked="wxcExitConfirm">
		</wxc-dialog>
	</scroller>
</template>

<script>
    import {WxcCell, WxcDialog} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcDialog
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            userAvatar: '',
            userName: '',
            memberWaitPay: 0,
            memberWaitSend: 0,
            memberWaitReceive: 0,
            memberBalance: '',
            memberWaitBalance: '',
            showDialog: false
		}),
        mounted () {
            this.storage.getItem(this.token, (res) => {
                if (res.result === 'success') {
                    this.handleUserDetails();
                    this.handleUserOrderList();
                }
            });
            // this.storage.setItem(this.token, "131d47c6810f45053a63241b8955d02f4b796ec0b4dbf98cede5405b2dd9e030ac3e4e19eeb4d6ebcc8f9518cbf3ed3c3c2128b0b92de30eecaf34098a7ff580c0e949ba14f54f558bc569214fe4900ed74c972b10494e2aab6d66e6f35a49d8")

        },
        methods: {
            handleExit () {
                this.storage.getItem(this.token, (res) => {
                    if (res.result === 'success') {
                        this.showDialog = true;
                    } else {
                        this.handleIsLogin({
                            success: () => {
                                setTimeout(function () {
                                    this.handleUserDetails();
                                    this.toast("登录成功");
								}.bind(this),300);
                            },
                            error: () => {

                            },
                        })
                    }
                })
            },
            wxcExitCancel () {
                this.showDialog = false;
            },
            wxcExitConfirm () {
                this.showDialog = false;
                if (this.platform !== 'web') {
                    this.storage.removeItem(this.setMemberId);
                    this.storage.removeItem(this.token, event => {
                        if (event.result === 'success') {
                            this.userAvatar = '';
                            this.userName = '';

                            this.toast("退出成功");
                            setTimeout(function () {
                                this.pushRoot('/index');
                            }, 2000)
                        } else {
                            this.toast("您已取消授权");
						}
                    })
                }
			},
            handleEcaluate () {
                this.toast("功能开发中，敬请期待")
                // this.handleIsLogin({
                //     success: () => {
                //         setTimeout(function () {
                //             this.handleUserDetails();
                //         }.bind(this),300);
                //
                //         this.push('/my/evaluate');
                //     },
                //     error: () => {
                //
                //     },
                // })
            },
            handleToCircle () {
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/circle/homePage');
                    },
                    error: () => {

                    },
                })
			},
            handleToBalance(){
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/my/balance');
                    },
                    error: () => {

                    },
                })
            },
            handleToOfficial () {
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/dynamic/index');
                    },
                    error: () => {

                    },
                })
			},
            handleToBankCard() {
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/my/bankCard/index');
                    },
                    error: () => {

                    },
                })
            },
            handleToTeam(){
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/my/team/detail');
                    },
                    error: () => {

                    },
                })
			},
            handleToQrcode() {
                this.toast("功能开发中，敬请期待")
                // this.handleIsLogin({
                //     success: () => {
                //         setTimeout(function () {
                //             this.handleUserDetails();
                //         }.bind(this),300);
                //
                //         this.push('/my/qrcode/index');
                //     },
                //     error: () => {
                //
                //     },
                // })
            },
            handleToAddressList() {
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/my/delivery/index');
                    },
                    error: () => {

                    },
                })
            },
            handleUserDetails() {
                this.request({
                    url: '/xingxiao/member/mobile/v1/view',
                    data: {},
                    success: (data) => {
                        if (data) {
                            this.userAvatar = data.memberAvatarPath;
                            this.userName = data.memberNickName;
                        }
                    },
                    error: () => {

                    }
                });
            },
            handleUserOrderList() {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/statistics',
                    data: {},
                    success: (data) => {
                        for (var i = 0; i < data.length; i++){
                            if (data[i].saleOrderStatus == "COMPLETE") {
                            }
                            else if (data[i].saleOrderStatus === "WAITING_DELIVERY") {
                                this. memberWaitSend = data[i].total
                            }
                            else if (data[i].saleOrderStatus === "WAITING_PAID") {
                                this.memberWaitPay = data[i].total
                            }
                            else if (data[i].saleOrderStatus && data[i].saleOrderStatus === "WAITING_RECEIVE") {
                                this.memberWaitReceive = data[i].total
                            }
                        }
                    },
                    error: () => {

                    }
                });
            },
            handleToOrderList(purchaseOrderId) {
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/order/purchaseIndex?purchaseOrderId=' + purchaseOrderId);
                    },
                    error: () => {

                    },
                })
			},
            handleToDeliveryOrderList(deliveryOrderStatus) {
                this.handleIsLogin({
                    success: () => {
                        setTimeout(function () {
                            this.handleUserDetails();
                        }.bind(this),300);

                        this.push('/order/deliveryIndex?deliveryOrderStatus=' + deliveryOrderStatus);
                    },
                    error: () => {

                    },
                })
            }
        }
    }
</script>

<style scoped>

	.container {
		width: 750px;
		padding-bottom: 160px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}
	.header-top {
		width: 750px;
		height: 400px;
		padding-top: 50px;
		background-color: #e994a9;
		align-items: center;
		justify-content: center;
	}
	.header-top-user {
		text-align: center;
	}
	.user-avatar {
		width: 160px;
		height: 160px;
		border-bottom-left-radius: 100px;
		border-bottom-right-radius: 100px;
		border-top-left-radius: 100px;
		border-top-right-radius: 100px;
	}
	.user-name {
		font-size: 34px;
		text-align: center;
		margin-top: 20px;
		color: #ffffff;
	}
	.balance-cell {
		width: 750px;
		height: 106px;
		margin-top: 20px;
	}
	.official-cell {
		width: 750px;
		height: 106px;
	}
	.balance-cell-content {
		flex-direction: row;
	}
	.balance-icon {
		width: 60px;
		height: 60px;
	}
	.balance-cell-title {
		padding-top: 8px;
		margin-left: 20px;
		font-size: 34px;
	}
	.balance-cell-desc {
		padding-right: 8px;
		padding-bottom: 4px;
		color: #999999;
		font-size: 34px;
	}
	.order-cell-desc {
		padding-right: 8px;
		padding-bottom: 4px;
		color: #999999;
		font-size: 28px;
	}
	.order-cell {
		width: 750px;
		height: 200px;
		margin-bottom: 20px;
	}
	.order-cell-content {
		flex-direction: row;
	}
	.order-cell-content-item {
		width: 176px;
		height: 168px;
		position: relative;
		text-align: center;
		align-items: center;
		justify-content: center;
	}
	.order-cell-content-item-icon {
		width: 50px;
		height: 50px;
	}
	.pay-img-badge {
		display:inline-block;
		padding: 8px 8px;
		min-width: 16px;
		border-radius: 50%;
		background-color: #E64340;
		color: #FFFFFF;
		line-height: 16px;
		text-align: center;
		font-size: 24px;
		position: absolute;
		top: 16px;
		right: 36px;
	}
	.order-cell-content-item-text {
		margin-top: 10px;
	}
	.brand-cell {
		width: 750px;
		height: 106px;
	}
	.body-item {
		width: 750px;
		height: 200px;
		align-items: center;
		flex-direction: row;
		border-top-width: 2px;
		border-top-color: #e2e2e2;
		background-color: #ffffff;
	}
	.body-item-left {
		width: 372px;
		height: 160px;
		align-items: center;
		border-right-width: 2px;
		border-right-color: #e2e2e2;
	}
	.body-item-left-icon {
		width: 60px;
		height: 60px;
		margin-top: 20px;
	}
	.circle-icon{
		width: 66px;
		height: 66px;
	}
	.body-item-left-title {
		margin-top: 20px;
		font-size: 34px;
	}
	.body-item-right {
		width: 372px;
		height: 160px;
		align-items: center;
	}
	.body-item-right-icon {
		width: 54px;
		height: 54px;
		margin-top: 26px;
	}
	.body-item-right-title {
		margin-top: 20px;
		font-size: 34px;
	}
	.body-item-bottom {
		border-bottom-width: 2px;
		border-bottom-color: #e2e2e2;
	}
</style>
