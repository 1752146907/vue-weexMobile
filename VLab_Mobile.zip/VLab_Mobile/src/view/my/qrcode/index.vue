<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <image class="code-background" src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/code-background.png"></image>
        <image class="qrcode-img" :src="imageHost + wxaCodePath"></image>
        <image class="code-background-bottom" src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/code-background-bottom.png"></image>
    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';

    import mixin from '../../../common/mixin';

    export default {
        components: {
            WxcCell
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            wxaCodePath: '',
        }),
        created () {

        },
        mounted () {
            this.handleWxaCodePath();
            this.changeTitle('我的二维码');
        },
        methods: {
            handleWxaCodePath() {
                this.request({
                    url: '/xingxiao/member/mobile/v1/agency/wxaCode',
                    data: {

                    },
                    success: (data) => {
                        if (data) {
                            this.wxaCodePath = data.wxaCodePath
                        }
                    },
                    error: () => {

                    }
                });
            },
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        position: relative;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .code-background {
        width: 750px;
        height: 1334px;
        position: absolute;
    }
    .qrcode-img {
        width: 600px;
        height: 600px;
        position: relative;
        margin-top: 420px;
        margin-left: 75px;
    }
    .code-background-bottom {
        width: 750px;
        height: 140px;
        position: fixed;
        left: 0px;
        right: 0px;
        bottom: 0px;

    }

</style>
