<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <wxc-cell class="balance-cell"
                  :has-top-border="true"
                  :has-bottom-border="true"
                  :has-arrow="true"
                  @wxcCellClicked="handleToBalance">
            <div class="balance-cell-content"
                 slot="label">
                <image class="balance-icon"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/money.png"></image>
                <text class="balance-cell-title">余额：￥{{memberBalance}}</text>
            </div>
            <div class="balance-cell-desc">提现记录</div>
        </wxc-cell>
        <wxc-cell class="card-cell"
                    :has-top-border="true"
                    :has-bottom-border="true"
                    :has-arrow="true"
                    @wxcCellClicked="handleToBankCard">
            <div class="balance-cell-content" slot="label">
                <image class="balance-icon"
                        src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/vip.png"></image>
                <div class="balance-cell-title">我的银行卡</div>
            </div>
        </wxc-cell>
        <div class="balance" style="border-bottom: none">
            <div class="balance-label" name="label">提现到银行卡：</div>
            <text class="balance-title" name="title">{{memberBankcardNumber}}</text>
        </div>
        <div class="balance">
            <div class="balance-label" name="label">提现金额：</div>
            <div class="balance-title" name="title">
                <input type="number"
                       class="balance-title-input"
                       v-model="inputAmount"
                       placeholder="请输入金额">
            </div>
        </div>
        <text class="sublime" @click="handlWithdraw">确定</text>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcLoading
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            memberBalance: '',
            memberWaitBalance: '',
            memberBankcardNumber: '',
            inputAmount: ''
        }),
        mounted () {
            this.changeTitle('我的提现');
            this.handleUserDetails();
            this.handleUserBankCard();
        },
        methods: {
            handleToBankCard() {
                this.push('/my/bankCard/index');
            },
            handleToBalance(){
                this.push('/my/bill/index');
            },
            handleUserDetails() {
                this.request({
                    url: '/xingxiao/member/mobile/v1/view',
                    data: {},
                    success: (data) => {
                        if (data) {
                            this.memberBalance = (data.memberBalance + data.memberWaitBalance).toFixed(2)
                        }
                    },
                    error: () => {

                    }
                });
            },
            handleUserBankCard() {
                this.request({
                    url: '/xingxiao/memberBankcard/mobile/v1/find/default',
                    data: {},
                    success: (data) => {
                        if (data) {
                            var memberBankcardNumber = data.memberBankcardNumber;
                            var reg = /^(\d{4})\d+(\d{4})$/;
                            memberBankcardNumber = memberBankcardNumber.replace(reg, "$1 **** **** $2");
                            this.memberBankcardNumber = memberBankcardNumber;
                        }
                    },
                    error: () => {

                    }
                });
            },
            handleToOrderList(saleOrderStatus) {
                this.$router.push({name:'orderList', params:{saleOrderStatus: saleOrderStatus}});
            },
            handlWithdraw: function () {
                if (this.inputAmount <= 0) {
                    this.toast('请输入余额');
                    return;
                }
                if (this.inputAmount > this.memberBalance) {
                    this.toast('余额不足');
                    return;
                }
                if (this.memberBankcardNumber == '') {
                    this.toast("请先添加银行卡");
                    return;
                }
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/shareWithdrawApplication/mobile/v1/save',
                    data: {
                        amount: this.inputAmount
                    },
                    success: () => {
                        wx.navigateTo({
                            url: '/view/bill/index'
                        });
                    },
                    error: function () {
                        this.isLoad = false;
                    }
                })
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .balance {
        width: 750px;
        background-color: #ffffff;
    }
    .balance-cell {
        width: 750px;
        height: 106px;
        margin-top: 20px;
    }
    .card-cell {
        width: 750px;
        height: 106px;
        margin-top: 20px;
        margin-bottom: 20px;
    }
    .balance-cell-content {
        flex-direction: row;
    }
    .balance-icon {
        width: 60px;
        height: 60px;
    }
    .balance-cell-title {
        padding-top: 8px;
        margin-left: 20px;
        font-size: 34px;
    }
    .balance-cell-desc {
        padding-right: 8px;
        padding-bottom: 4px;
        color: #999999;
        font-size: 34px;
    }

    .balance{
        flex-direction: row;
        flex-wrap: wrap;
        background: #ffffff;
        padding: 24px;
        border-top-color: #e2e2e2;
        border-top-width: 1px;
        border-bottom-color: #e2e2e2;
        border-bottom-width: 1px;
        border-top-style: solid;
        border-bottom-style: solid;
    }
    .balance-label{
        width: 240px;
    }
    .balance-title{
        flex: 1;
    }
    .balance-title-input{
        flex: 1;
    }

    .sublime{
        height:100px;
        line-height:100px;
        position:fixed;
        left:0px;
        right:0px;
        bottom:0px;
        font-size:34px;
        margin-top:80px;
        text-align:center;
        color:#ffffff;
        background-color:#e994a9;

    }
</style>
