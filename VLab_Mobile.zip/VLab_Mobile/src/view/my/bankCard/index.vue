<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <wxc-cell class="bank-card-cell"
                  :has-top-border="true"
                  :has-bottom-border="true"
                  :has-arrow="true"
                  @wxcCellClicked="handleBankCardDetail(bankCard.memberBankcardId)"
                  v-for="bankCard in bankCardList"
                  :key="bankCard.memberBankcardNumber">
            <div class="bank-card-cell-content"
                 slot="label">
                <image class="bank-card-icon"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/card.png"></image>
                <div class="bank-card-label">
                    <div class="bank-card-title">{{bankCard.memberBankcardOrganization}}</div>
                    <div class="bank-card-desc">{{bankCard.memberBankcardNumber}}</div>
                </div>
            </div>
            <div class="bank-card-default" v-if="bankCard.memberBankcardIsDefault">默认</div>
        </wxc-cell>
        <text class="add-card" @click="handleAddCard">添加银行卡</text>

        <div class="no-data"
             v-if="bankCardList.length <= 0">
            <image class="no-data-img"
                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
            <text class="no-data-text">当前没有数据</text>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';

    import mixin from '../../../common/mixin';

    export default {
        components: {
            WxcCell
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            bankCardList: -1,
        }),
        created () {

        },
        mounted () {
            this.changeTitle('我的银行卡');
            this.handleBankCardList();
            this.globalEvent.addEventListener('refreshCard', (data) => {
                this.handleBankCardList();
            });

        },
        methods: {
            handleAddCard() {
                this.push('/bankCard/addCard');
            },
            handleBankCardDetail(memberBankcardId) {
                this.push('/bankCard/detail?memberBankcardId=' + memberBankcardId);
            },
            handleBankCardList() {
                this.request({
                    url: '/xingxiao/memberBankcard/mobile/v1/list',
                    data: {

                    },
                    success: (data) => {
                        this.bankCardList = data;
                        for(var i = 0; i < data.length; i++) {
                            this.memberBankcardId = data[i].memberBankcardId
                        }
                    },
                    error: () => {

                    }
                });
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        position: relative;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .bank-card-cell {
        width: 750px;
        height: 136px;
        margin-top: 20px;
    }
    .bank-card-cell-content {
        flex-direction: row;
    }
    .bank-card-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        margin-top: 10px;
    }
    .bank-card-label {
        margin-left: 20px;
    }
    .bank-card-title {
        font-size: 34px;
    }
    .bank-card-desc {
        font-size: 30px;
        color: #999999;
    }
    .bank-card-default {
        font-size: 34px;
        color: #999999;
    }
    .add-card {
        background-color: #e994a9;
        width: 750px;
        height: 100px;
        line-height: 100px;
        color: #ffffff;
        font-size: 34px;
        text-align: center;
        position: fixed;
        bottom: 0px;
    }
    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

</style>
