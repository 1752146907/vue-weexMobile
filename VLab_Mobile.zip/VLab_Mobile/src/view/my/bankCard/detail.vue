<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="header-box">
            <image class="header-box-img"
                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/card.png"></image>
        </div>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="true"
                  @wxcCellClicked="handleBankName"
                  :has-bottom-border="false">
            <div class="bank-name-cell-label" slot="label" name="bankCode">银行：</div>
            <text class="cardholder-input cart-picker">{{memberBankcardOrganization ? memberBankcardOrganization : '请选择'}}</text>
        </wxc-cell>
        <div class="line"></div>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="false"
                  :has-bottom-border="false">
            <div class="bank-name-cell-label" slot="label">姓名：</div>
            <input class="bank-name" placeholder="请输入姓名" slot="title" v-model="memberBankcardName" />
        </wxc-cell>
        <div class="line"></div>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="false"
                  :has-bottom-border="true">
            <div class="bank-name-cell-label" slot="label">卡号：</div>
            <input class="bank-name" placeholder="请输入卡号" slot="title" v-model="memberBankcardNumber" />
        </wxc-cell>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="false"
                  v-if="memberBankcardCode">
            <div class="switch-title" slot="label">设为默认银行卡</div>
            <switch slot="value"
                    :checked="memberBankcardIsDefault"
                    @change="handleIsDefault"></switch>
        </wxc-cell>
        <div class="preservation-btn"
                    @click="handleSublime">
            <text class="preservation-btn-text">保存</text>
        </div>
        <div class="delete-btn"
                    @click="wxcButtonClickedDelete">
            <text class="delete-btn-text">删除</text>
        </div>

        <wxc-dialog title="确定删除"
                    content="本操作不可恢复，您确定删除本条银行卡信息吗？"
                    :show="wxcDialogConfirmShow"
                    main-btn-color="#e994a9"
                    @wxcDialogCancelBtnClicked="dialogConfirmBtnNo"
                    @wxcDialogConfirmBtnClicked="dialogConfirmBtnClick">
        </wxc-dialog>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcButton, WxcLoading, WxcDialog} from 'weex-ui';

    import mixin from '../../../common/mixin';

    const picker = weex.requireModule('picker')
    const items = ['工商银行', '农业银行', '中国银行', '建设银行', '招商银行', '邮储银行', '交通银行', '浦发银行', '民生银行', '兴业银行', '平安银行', '中信银行', '华夏银行', '广发银行', '光大银行', '北京银行', '宁波银行']


    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcLoading,
            WxcDialog
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            wxcDialogConfirmShow: false,
            memberBankcardCode: '',
            memberBankcardId: '',
            memberBankcardIsDefault: false,
            index: 0,
            memberBankcardName: '',
            memberBankcardNumber: '',
            memberBankcardOrganization: '',
            bankCodeList: [
                {
                    id: 1002,
                    name: '工商银行'
                },
                {
                    id: 1005,
                    name: '农业银行'
                },
                {
                    id: 1026,
                    name: '中国银行'
                },
                {
                    id: 1003,
                    name: '建设银行'
                },
                {
                    id: 1001,
                    name: '招商银行'
                },
                {
                    id: 1066,
                    name: '邮储银行'
                },
                {
                    id: 1020,
                    name: '交通银行'
                },
                {
                    id: 1004,
                    name: '浦发银行'
                },
                {
                    id: 1006,
                    name: '民生银行'
                },
                {
                    id: 1009,
                    name: '兴业银行'
                },
                {
                    id: 1010,
                    name: '平安银行'
                },
                {
                    id: 1021,
                    name: '中信银行'
                },
                {
                    id: 1025,
                    name: '华夏银行'
                },
                {
                    id: 1027,
                    name: '广发银行'
                },
                {
                    id: 1022,
                    name: '光大银行'
                },
                {
                    id: 1032,
                    name: '北京银行'
                },
                {
                    id: 1056,
                    name: '宁波银行'
                }
            ],
        }),
        created () {
            this.memberBankcardId = decodeURI(decodeURI(this.getParameter('memberBankcardId')));
            this.handleBankCardDetail();
        },
        mounted () {
            this.changeTitle('我的银行卡');

        },
        computed: {
            cartValue () {
                if (this.index < items.length) {
                    return items[this.index]
                }
                return ''
            }
        },
        methods: {
            handleBankName () {
                picker.pick({
                    index: this.index,
                    items
                }, event => {
                    if (event.result === 'success') {
                        this.memberBankcardOrganization = items[event.data];
                        this.index = event.data;
                        this.toast(this.memberBankcardOrganization);
                        this.memberBankcardCode = this.bankCodeList[this.index].id
                    }
                })
            },
            dialogConfirmBtnNo () {
                this.isLoad = false;
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            dialogConfirmBtnClick () {
                this.isLoad = true;
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
                this.request({
                    url: '/xingxiao/memberBankcard/mobile/v1/delete',
                    data: {
                        memberBankcardId: this.memberBankcardId
                    },
                    success: () => {
                        this.isLoad = false;
                        this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
                        this.toast("删除成功");
                        this.pop();
                    },
                    error: () => {

                    }
                });
            },
            handleSublime() {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/memberBankcard/mobile/v1/update',
                    data: {
                        memberBankcardCode: this.memberBankcardCode,
                        memberBankcardId: this.memberBankcardId,
                        memberBankcardNumber: this.memberBankcardNumber,
                        memberBankcardIsDefault: this.memberBankcardIsDefault,
                        memberBankcardName: this.memberBankcardName,
                        memberBankcardOrganization: this.memberBankcardOrganization
                    },
                    success: () => {
                        this.isLoad = false;
                        this.chuangshi.sendEventListener({
                            name: 'refreshCard',
                            data: {

                            }
                        });
                        this.toast('修改成功');
                        this.pop();
                    },
                    error: () => {

                    }
                });
            },
            wxcButtonClickedDelete() {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            handleBankCardDetail() {
                this.request({
                    url: '/xingxiao/memberBankcard/mobile/v1/find',
                    data: {
                        memberBankcardId: this.memberBankcardId
                    },
                    success: (data) => {
                            this.memberBankcardCode = data.memberBankcardCode;
                            this.memberBankcardId = data.memberBankcardId;
                            this.memberBankcardNumber = data.memberBankcardNumber;
                            this.memberBankcardIsDefault = data.memberBankcardIsDefault;
                            this.memberBankcardName = data.memberBankcardName;
                            this.memberBankcardOrganization = data.memberBankcardOrganization;
                    },
                    error: () => {

                    }
                });
            },
            handleIsDefault () {
                this.memberBankcardIsDefault = !this.memberBankcardIsDefault;
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        position: relative;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .header-box {
        width: 750px;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    .header-box-img {
        width: 160px;
        height: 160px;
        border-radius: 50%;
    }
    .bank-name-cell {
        width: 750px;
        color: #000000;
    }
    .bank-name-cell-label {
        width: 100px;
        color: #000000;
        font-size: 30px;
    }
    .cardholder-input {
        width: 650px;
        text-align: left;
    }
    .line {
        border-top-style: solid;
        border-top-color: #E2E2E2;
        border-top-width: 1px;
        margin-left: 20px;
    }
    .bank-name {
        font-size: 30px;

    }
    .preservation-btn {
        width: 750px;
        height: 84px;
        position: fixed;
        bottom: 100px;
        left: 0px;
        right: 0px;
        border-radius: 12px;
        background-color: #e994a9;
    }
    .preservation-btn-text{
        line-height: 84px;
        font-size: 34px;
        text-align: center;
        color: #ffffff;
    }
    .delete-btn {
        width: 750px;
        height: 84px;
        position: fixed;
        bottom: 0px;
        left: 0px;
        right: 0px;
        background-color:#ffffff;
        border-radius: 12px;
        border-top-color: #e2e2e2;
        border-top-width: 1px;
    }
    .delete-btn-text{
        line-height: 84px;
        font-size: 34px;
        text-align: center;
        color:#000000;
    }

</style>
