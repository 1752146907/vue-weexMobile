<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="header-text">请绑定持卡人本人的银行卡</div>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="true"
                  @wxcCellClicked="handleBankName"
                  :has-bottom-border="false">
            <div class="bank-name-cell-label" slot="label" name="bankCode">银行名称</div>
                <text class="cardholder-input cart-picker">{{bankName ? bankName : '请选择'}}</text>
        </wxc-cell>
        <div class="line"></div>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="false"
                  :has-bottom-border="false">
            <div class="bank-name-cell-label" slot="label">持卡人</div>
            <input class="bank-name"
                   v-model="memberBankcardName"
                   placeholder="请输入姓名"
                   slot="title" />
        </wxc-cell>
        <div class="line"></div>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="false"
                  :has-bottom-border="true">
            <div class="bank-name-cell-label" slot="label">卡号</div>
            <input class="bank-name"
                   v-model="memberBankcardNumber"
                   placeholder="请输入卡号"
                   slot="title" />
        </wxc-cell>
        <wxc-cell class="bank-name-cell"
                  :has-top-border="false">
            <div class="switch-title" slot="label">设为默认银行卡</div>
            <switch slot="value"
                    class="bank-name-cell-switch"
                    :checked="memberBankcardIsDefault"
                    @change="handleIsDefault"></switch>
        </wxc-cell>
        <text class="preservation-btn"
              @click="handleSubmit">添加
        </text>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcButton, WxcLoading} from 'weex-ui';

    import mixin from '../../../common/mixin';

    const picker = weex.requireModule('picker')
    const items = ['工商银行', '农业银行', '中国银行', '建设银行', '招商银行', '邮储银行', '交通银行', '浦发银行', '民生银行', '兴业银行', '平安银行', '中信银行', '华夏银行', '广发银行', '光大银行', '北京银行', '宁波银行']


    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcLoading
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            index: 0,
            bankName: '',
            bankCode: '',
            memberBankcardName: '',
            memberBankcardNumber: '',
            bankCodeList: [
                {
                    id: 1002,
                    name: '工商银行'
                },
                {
                    id: 1005,
                    name: '农业银行'
                },
                {
                    id: 1026,
                    name: '中国银行'
                },
                {
                    id: 1003,
                    name: '建设银行'
                },
                {
                    id: 1001,
                    name: '招商银行'
                },
                {
                    id: 1066,
                    name: '邮储银行'
                },
                {
                    id: 1020,
                    name: '交通银行'
                },
                {
                    id: 1004,
                    name: '浦发银行'
                },
                {
                    id: 1006,
                    name: '民生银行'
                },
                {
                    id: 1009,
                    name: '兴业银行'
                },
                {
                    id: 1010,
                    name: '平安银行'
                },
                {
                    id: 1021,
                    name: '中信银行'
                },
                {
                    id: 1025,
                    name: '华夏银行'
                },
                {
                    id: 1027,
                    name: '广发银行'
                },
                {
                    id: 1022,
                    name: '光大银行'
                },
                {
                    id: 1032,
                    name: '北京银行'
                },
                {
                    id: 1056,
                    name: '宁波银行'
                }
            ],
            memberBankcardIsDefault: true
        }),
        created () {

        },
        mounted () {
            this.changeTitle('添加银行卡');

        },
        computed: {
            cartValue () {
                if (this.index < items.length) {
                    return items[this.index]
                }
                return ''
            }
        },
        methods: {
            handleBankName () {
                picker.pick({
                    index: this.index,
                    items
                }, event => {
                    if (event.result === 'success') {
                        this.bankName = items[event.data];
                        this.index = event.data;
                        this.toast(this.bankName);
                        this.bankCode = this.bankCodeList[this.index].id
                    }
                })
            },
            handleSubmit() {
                if (this.bankName == '') {
                    this.toast('请选择银行');
                    return;
                }
                if (this.memberBankcardName == '') {
                    this.toast('请输入持卡人名字');
                    return;
                }
                if (this.memberBankcardNumber == '') {
                    this.toast('请输入卡号');
                    return;
                }
                if (this.memberBankcardNumber.length < 16 || this.memberBankcardNumber.length > 19) {
                    this.toast('银行卡号长度必须在16到19之间');
                    return;
                }
                var num = /^\d*$/;//全数字
                if (!num.exec(this.memberBankcardNumber)) {
                    this.toast('银行卡号必须全为数字');
                    return false;

                }
                var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
                if (strBin.indexOf(this.memberBankcardNumber.substring(0, 2)) == -1) {
                    this.toast('银行卡号开头6位不符合规范');
                    return false;
                }

                this.isLoad = true;
                this.request({
                    url: '/xingxiao/memberBankcard/mobile/v1/save',
                    data: {
                        memberBankcardOrganization: this.bankName,
                        memberBankcardCode: this.bankCode,
                        memberBankcardNumber: this.memberBankcardNumber,
                        memberBankcardName: this.memberBankcardName,
                        memberBankcardIsDefault: this.memberBankcardIsDefault
                    },
                    success: function (data) {
                        this.isLoad = false;
                        this.toast('添加成功');
                        this.pop();
                    }.bind(this)
                });
            },
            handleIsDefault () {
                this.memberBankcardIsDefault = !this.memberBankcardIsDefault;
            }
        }
    }
</script>

<style scoped>
    .wrapper {
        justify-content: center;
        align-items: center;
    }
    .group {
        flex-direction: row;
        justify-content: center;
        margin-bottom: 60px;
        align-items: center;
    }
    .label {
        font-size: 60px;
        color: #888888;
    }
    .title {
        font-size: 100px;
        color: #41B883;
    }
    .button {
        font-size: 50px;
        width: 280px;
        color: #41B883;
        text-align: center;
        padding-top: 25px;
        padding-bottom: 25px;
        border-width: 2px;
        border-style: solid;
        border-color: rgb(162, 217, 192);
        background-color: rgba(162, 217, 192, 0.2);
    }
    .container {
        width: 750px;
        position: relative;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .header-text {
        width: 750px;
        padding-top: 40px;
        padding-left: 20px;
        margin-bottom: 12px;
        font-size: 30px;
        color: #808080;
    }
    .bank-name-cell {
        width: 750px;
        color: #000000;
    }
    .bank-name-cell-label {
        width: 160px;
        color: #000000;
        font-size: 30px;
    }
    .bank-name-cell-switch{
        margin-right: 20px;
    }
    .cardholder-input {
        width: 520px;
        height: 54px;
        font-size: 30px;
    }
    .cart-picker{
        line-height: 54px;
    }
    .picker-text {
        margin-left: 40px;
    }
    .line {
        border-top-style: solid;
        border-top-color: #E2E2E2;
        border-top-width: 1px;
        margin-left: 20px;
    }
    .bank-name {
        font-size: 30px;
        margin-left: 40px;
    }
    .preservation-btn {
        width: 750px;
        height: 90px;
        line-height: 90px;
        position: fixed;
        bottom: 0px;
        left: 0px;
        right: 0px;
        font-size: 34px;
        text-align: center;
        color: #ffffff;
        background-color: #e994a9;
    }

</style>
