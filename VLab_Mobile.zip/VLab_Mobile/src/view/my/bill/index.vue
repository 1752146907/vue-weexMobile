<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="no-data" v-if="WithdrawList.length == 0">
            <image class="no-data-img"
                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
            <text class="no-data-text">当前没有数据</text>
        </div>
        <div class="address" v-for="item in WithdrawList">
            <wxc-cell :title="item.shareWithdrawApplicationName + item.shareWithDrawApplicationStatus"
                      :desc="'备注：' + item.shareWithdrawApplicationRemark"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
                <slot name="value">￥{{item.shareWithdrawApplicationAmount}}</slot>
            </wxc-cell>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';

    import mixin from '../../../common/mixin';

    export default {
        components: {
            WxcCell
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            pageIndex: 1,
            pageSize: 20,
            memberId: '',
            WithdrawList: '',
        }),
        mounted () {
            this.changeTitle('提现列表');
            this.handleWithDraw();
        },
        methods: {
            handleWithDraw(){
                this.request({
                    url: '/xingxiao/shareWithdrawApplication/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                    },
                    success: (data) => {
                        this.WithdrawList = data.list;
                        if (data) {

                        }
                    },
                    error: () => {

                    }
                });
            },
            handleToOrderList(saleOrderStatus) {
                this.$router.push({name:'orderList', params:{saleOrderStatus: saleOrderStatus}});
            },
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
        position: relative;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

</style>
