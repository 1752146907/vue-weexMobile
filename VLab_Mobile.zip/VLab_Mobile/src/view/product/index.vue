<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<slider class="slider" interval="5000" auto-play="true" :index="0">
			<div class="slider-frame" v-for="(img, index) in productInfo.productMobileImageList">
				<image class="slider-image" resize="cover" :src="imageHost + img.imagePath"></image>
				<text class="slider-index">{{index + 1}}/{{productInfo.productMobileImageList.length}}</text>
			</div>
		</slider>

		<div class="nav-text">
			<text class="nav-text-title">{{productInfo.productTitle}}</text>
			<text class="nav-text-synopsis">{{productInfo.productSubtitle}}</text>
			<text class="nav-text-price">￥{{productInfo.productPrice}}</text>
		</div>

		<div class="purchase">
			<div class="purchase-modules">
				<text class="purchase-modules-title">购买配置：{{productInfo.productMinPurchaseQuantity}}</text>
			</div>
		</div>
		<div class="product-detail" v-if="productInfo">
			<Html :inner="productInfo.productMobileDetail"
				  :globalEvent="globalEvent"
				  :chuangshi="chuangshi"
				  :platform="platform"></Html>
			<!--<web style="width: 750px"-->
				 <!--:style="{height: pageHeight + 'px'}"-->
				 <!--src="http://m.vpluslab.com/#/app/index"></web>-->
		</div>

		<div class="footer">
			<div class="footer-total">
				<div class="footer-total-text">
					<text class="footer-total-text-selected-number">已选：{{productInfo.productMinPurchaseQuantity}} 个</text>
					<text class="footer-total-text-total-amount">总金额: ￥{{sumPrice}}</text>
				</div>
				<div class="footer-pay" @click="handleToOrder">
					<text class="footer-pay-text">立即购买</text>
				</div>
			</div>
		</div>
	</scroller>

</template>

<script>
	import {WxcStepper, WxcLoading} from 'weex-ui';
	import Html from '../../component/html';

	import mixin from '../../common/mixin';

	export default {
		components: {
			WxcStepper,
			WxcLoading,
			Html
		},
		mixins: [mixin],
		data: () => ({
            productId: '',
			productNumber: 1,
			productInfo: '',
			isLoad: false,
			productTotal: 0,
			sumPrice: '0.00',
			showSelectActive: true
		}),
		mounted () {
		    if(this.getParameter('productId')){
                this.productId = this.getParameter('productId')
			}

			this.haneleLoad();

			if (this.platform != 'web') {
				// this.globalEvent.addEventListener('getWeiXinAuth', (data) => {
                 //    // this.toast(data.code)
                 //    this.handleGetUserInfo(data.code);
				// });

				this.globalEvent.addEventListener('getWeiXinPaySuccess', (data) => {
					console.log('getWeiXinPaySuccess')
				});

				this.globalEvent.addEventListener('getWeiXinPayCancel', (data) => {
					console.log('getWeiXinPayCancel')
				});

				this.globalEvent.addEventListener('getWeiXinPayFail', (data) => {
					console.log('getWeiXinPayFail')
				});

				this.globalEvent.addEventListener('getAliPaySuccess', (data) => {
					console.log('getAliPaySuccess')
				});

				this.globalEvent.addEventListener('getAliPayFail', (data) => {
					console.log('getAliPayFail')
				});
			}
		},
		methods: {
			haneleLoad () {
				this.request({
					url: '/xingxiao/product/mobile/v1/purchase/find',
					data: {
                        productId: this.productId
					},
					success: (data) => {
					    data.productPrice = data.productPrice.toFixed(2)
					    this.sumPrice = (data.productMinPurchaseQuantity * data.productPrice).toFixed(2)
						this.productInfo = data
					},
					error: () => {
						this.isLoad = false;
					}
				});
			},
			handleToOrder () {
                this.handleIsLogin({
					success: () => {
                        this.isLoad = true;
                        var purchaseOrderProductList = JSON.stringify([
                            {
                                productId: this.productInfo.productId,
                                productQuantity: this.productInfo.productMinPurchaseQuantity
                            }
                        ]);
                        this.storage.setItem("purchaseOrderProductList", purchaseOrderProductList)
                        this.push('/order/purchaseCheck?totalAmount=' + this.sumPrice);
					},
					fail: () => {

					}
				});
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		padding-bottom: 60px;
	}

	.slider {
		width: 750px;
		height: 750px;
	}

	.slider-image {
		width: 750px;
		height: 750px;
	}

	.slider-frame {
		width: 750px;
		height: 750px;
		position: relative;
	}

	.slider-index {
		right: 20px;
		bottom: 20px;
		color: #e994a9;
		position: absolute
	}

	.nav-text {
		width: 750px;
		padding: 20px;
		background-color: #ffffff;
		border-top-color: #D9D9D9;
		border-top-width: 1px;
		border-bottom-color: #D9D9D9;
		border-bottom-width: 1px;
	}

	.nav-text-title {
		font-size: 32px;
		font-weight: bold;
	}

	.nav-text-synopsis {
		font-size: 28px;
		color: #4B4B4B;
		line-height: 53px;
	}

	.nav-text-price {
		font-size: 30px;
		color: #e994a9;
		font-weight: bold;
	}

	.purchase {
		width: 750px;
		padding: 20px;
		background-color: #ffffff;
		border-top-color: #D9D9D9;
		border-top-width: 1px;
		border-bottom-color: #D9D9D9;
		border-bottom-width: 1px;
		margin-top: 10px;
		margin-bottom: 10px;
	}

	.purchase-title {
		font-size: 32px;
	}

	.purchase-configuration-item {
		width: 700px;
		height: 68px;
		border-left-color: #4B4B4B;
		border-left-width: 1px;
		border-right-color: #4B4B4B;
		border-right-width: 1px;
		border-top-color: #4B4B4B;
		border-top-width: 1px;
		border-bottom-color: #4B4B4B;
		border-bottom-width: 1px;
		margin-top: 15px;
		padding: 12px 15px 0px 15px;
		background-color: #ffffff;
		border-bottom-left-radius: 10px;
		border-bottom-right-radius: 10px;
		border-top-left-radius: 10px;
		border-top-right-radius: 10px;
		flex-direction: row;
		flex-wrap: wrap;
	}

	.purchase-configuration-item-active {
		width: 700px;
		height: 68px;
		border-left-color: #e994a9;
		border-left-width: 1px;
		border-right-color: #e994a9;
		border-right-width: 1px;
		border-top-color: #e994a9;
		border-top-width: 1px;
		border-bottom-color: #e994a9;
		border-bottom-width: 1px;
		margin-top: 15px;
		padding: 12px 15px 0px 15px;
		background-color: #ffffff;
		border-bottom-left-radius: 10px;
		border-bottom-right-radius: 10px;
		border-top-left-radius: 10px;
		border-top-right-radius: 10px;
		flex-direction: row;
		flex-wrap: wrap;
	}

	.purchase-configuration-item-text-active {
		color: #e994a9;
	}

	.purchase-configuration-item-price-active {
		color: #e994a9;
	}

	.purchase-configuration-item-text {
		width: 490px;
		color: #4B4B4B;
		font-size: 28px;
	}

	.purchase-configuration-item-price {
		width: 150px;
		color: #4B4B4B;
		font-size: 28px;
	}

	.purchase-modules {
		flex-direction: row;
		flex-wrap: wrap;
	}

	.purchase-modules-title {
		width: 500px;
	}

	.purchase-modules-stepper {
		width: 210px;
	}

	.product-detail {
		width: 750px;
		margin-top: 10px;
		margin-bottom: 80px;
	}

	.footer {
		width: 750px;
		height: 96px;
		position: fixed;
		bottom: 0px;
		left: 0px;
		right: 0px;
		background-color: #ffffff;
		border-top-color: #d9d9d9;
		border-top-width: 1px;
	}

	.footer-total {
		height: 90px;
		background-color: #fff;
		flex-direction: row
	}

	.footer-total-text {
		width: 530px;
		font-size: 22px;
		padding-top: 10px;
		padding-left: 10px;
		box-sizing: border-box;
	}

	.footer-total-text-selected-number {
		font-size: 26px;
	}

	.footer-total-text-total-amount {
		font-size: 28px;
	}

	.footer-pay {
		width: 220px;
		height: 96px;
	}

	.footer-pay-text {
		line-height: 96px;
		font-size: 32px;
		color: #fff;
		text-align: center;
		background-color: #e994a9;
	}
</style>