<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="order-info" v-if="deliveryOrderDetail">
            <wxc-cell v-if="deliveryOrderDetail.deliveryOrderStatus == 'WAITING_DELIVERY'"
                      title="您的订单：待发货"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell v-if="deliveryOrderDetail.deliveryOrderStatus == 'WAITING_RECEIVE'"
                      title="您的订单：待收货"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell v-if="deliveryOrderDetail.deliveryOrderStatus == 'COMPLETE'"
                      title="您的订单：已完成"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell :title="'发货编号：' + deliveryOrderDetail.deliveryOrderId"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true"></wxc-cell>
            <wxc-cell :title="'下单时间：' + deliveryOrderDetail.systemCreateTime"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true"></wxc-cell>
        </div>

        <div class="address">
            <text class="address-title">{{deliveryOrderDetail.deliveryOrderReceiveName}} {{deliveryOrderDetail.deliveryOrderReceiveMobile}}</text>
            <text class="address-value">{{deliveryOrderDetail.deliveryOrderReceiveCity + deliveryOrderDetail.deliveryOrderReceiveArea + deliveryOrderDetail.deliveryOrderReceiveAddress}}</text>
        </div>

        <div class="order-list"
             v-if="deliveryOrderDetail">
            <div class="order-list-body"
                 v-for="children in deliveryOrderDetail.deliveryOrderProductList">
                <image class="order-list-body-image"
                       :src="imageHost + children.productImagePath"></image>
                <div class="order-list-body-info">
                    <text class="order-list-body-info-title">{{children.productTitle}}</text>
                    <text class="order-list-body-info-price">￥{{children.productPrice}} X {{children.productQuantity}}</text>
                </div>
            </div>
        </div>

        <div class="address">
            <text class="address-title remark-title">留言</text>
            <text class="address-value remark-value">{{deliveryOrderDetail.purchaseOrderRemark ? deliveryOrderDetail.purchaseOrderRemark : '暂无留言'}}</text>
        </div>

        <div class="product-info">
            <wxc-cell :has-arrow="false"
                      :has-top-border="true"
                      label="商品总数">
                <slot name="value">
                    <text class="product-info-value">{{deliveryOrderDetail.deliveryOrderTotalQuantity}}</text>
                </slot>
            </wxc-cell>
            <wxc-cell :has-arrow="false"
                      :has-top-border="false"
                      label="商品金额">
                <slot name="value">
                    <text class="product-info-value">￥{{deliveryOrderDetail.deliveryOrderTotalAmount}}</text>
                </slot>
            </wxc-cell>
        </div>

        <div class="product-info">
            <!--<div v-for="(express, index) in deliveryOrderDetail.deliveryOrderExpressList"-->
                <!--:key="index">-->
                <!--<text class="express-number">物流单号：{{express.expressNo}}</text>-->
                <!--<div v-for="(children, index) in express.expressTraces"-->
                     <!--:key="index"-->
                     <!--v-if="index == 0">-->
                    <!--<wxc-simple-flow :list="[-->
                                <!--{-->
                                    <!--date: '{{children.ftime}}',-->
                                    <!--desc: '',-->
                                    <!--highlight: true,-->
                                    <!--title: '{{children.context}}'-->
                                <!--},-->
                                <!--{-->
                                    <!--date: '2017-05-24 19:49:03',-->
                                    <!--desc: '商家会在2个工作小时内电话或旺旺联系您',-->
                                    <!--title: '商家已接单'-->
                                <!--}-->
                            <!--]"-->
                                     <!--:themeColor="themeColor"></wxc-simple-flow>-->
                <!--</div>-->
            <!--</div>-->
            <div class='express'
                 v-for="(express, index) in deliveryOrderDetail.deliveryOrderExpressList"
                 :key="index">
                <text class='express-title'>物流单号：{{express.expressNo}}</text>
                <text class='express-state'>· 状态：{{express.expressCompanyName}}({{express.expressStatus}})</text>
                <div class="express-list"
                     v-for="(children, index) in express.expressTraces"
                     :key="index">
                    <div class='express-line'></div>
                    <div class='express-item'><text class="express-item-time">{{children.ftime}}</text><text class="express-item-context">{{children.context}}</text></div>
                </div>
            </div>
        </div>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading, WxcSimpleFlow} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcLoading,
            WxcSimpleFlow
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            deliveryOrderId: '',
            deliveryOrderDetail: '',
            themeColor: {
                lineColor: '#e994a9',
                pointInnerColor: '#e994a9',
                pointBorderColor: '#e994a9',
                highlightTitleColor: '#e994a9',
                highlightPointInnerColor: '#e994a9',
                highlightPointBorderColor: '#e994a9'
            }
        }),
        mounted () {
            this.changeTitle('订单详情');
            this.deliveryOrderId = decodeURI(decodeURI(this.getParameter('deliveryOrderId')));
            this.handleLoad();
        },
        methods: {
            handleLoad: function () {
                this.request({
                    url: '/xingxiao/delivery/order/mobile/v1/find',
                    data: {
                        deliveryOrderId: this.deliveryOrderId
                    },
                    success: (data) => {
                        data.systemCreateTime = this.formatTime(data.systemCreateTime)
                        this.deliveryOrderDetail = data;
                    },
                    error: (data) => {
                        // this.toast(data.message);
                    }
                });
            },
            formatTime: function (timestamp) {
                var date = new Date(timestamp);

                var year = date.getFullYear()
                var month = date.getMonth() + 1
                var day = date.getDate()

                var hour = date.getHours()
                var minute = date.getMinutes()
                var second = date.getSeconds()

                return [year, month, day].join('-') + ' ' + [hour, minute, second].join(':');
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        padding-bottom: 60px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .order-info{
        margin-top: 20px;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
    }

    .order-list{
        width: 750px;
        margin-top: 20px;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
    }
    .order-list-body{
        flex-direction: row;
        flex-wrap: wrap;
        padding: 20px;
    }
    .order-list-body-image{
        width: 150px;
        height: 150px;
        margin-right: 20px;
    }
    .order-list-body-info{
        flex: 1;
    }
    .order-list-body-info-title{
        margin-top: 10px;
        font-weight: bold;
    }
    .order-list-body-info-price{
        color: #999999;
        font-size: 28px;
    }

    .address{
        margin-top: 20px;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        background-color: #ffffff;
    }
    .address-list{
        width: 750px;
        border-top: none;
        font-size: 30px;
    }
    .address-title{
        width: 750px;
        font-size: 30px;
        color: #000000;
        padding-left: 24px;
        padding-top: 24px;
    }
    .address-value{
        font-size: 28px;
        color: #999999;
        padding-left: 24px;
        padding-right: 24px;
        padding-bottom: 24px;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
    }

    .remark-title{
        margin-left: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
        padding-bottom: 16px;
        padding-left: 0px;
    }

    .remark-value{
        padding-top: 20px;
    }

    .product-info{
        width: 750px;
        margin-top: 20px;
    }
    .product-info-value{
        color: #999999;
        font-size: 30px;
    }

    .express{
        background-color: #ffffff;
        padding-top: 0px;
        padding-right: 32px;
        padding-bottom: 30px;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
    }
    .express-item{
        color: #999999;
        font-size: 24px;
        padding-top: 10px;
    }
    .express-title{
        width: 750px;
        margin-bottom: 10px;
        padding-top: 20px;
        padding-right: 0px;
        padding-bottom: 20px;
        padding-left: 30px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #dddddd;
    }
    .express-list{
        padding-left: 46px;
    }
    .express-state{
        color: #222222;
        padding-top: 10px;
        padding-right: 0px;
        padding-left: 30px;
        font-size: 28px;
    }
    .express-item-time{
        color: #e994a9;
    }
    .express-line{
        width: 10px;
        height: 20px;
        line-height: 36px;
        margin-left: 40px;
        margin-top: 10px;
        margin-bottom: 4px;
        border-left-style: dashed;
        border-left-width: 2px;
        border-left-color: #e994a9;
    }
    .express-item-context{
        color: #999999;
        font-size: 28px;
    }

</style>
