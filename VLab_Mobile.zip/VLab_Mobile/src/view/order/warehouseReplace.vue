<template>
    <scroller class="wrapper"
              :style="{height: pageHeight + 'px'}">
            <div class="container">
                <div class="address"
                     v-if="addressData.memberAddressId">
                    <wxc-cell :title="addressData.memberAddressName + ' ' + addressData.memberAddressMobile"
                              :desc="addressData.memberAddressProvince + addressData.memberAddressCity + addressData.memberAddressArea + addressData.memberAddressDetail"
                              class="address-list"
                              :has-arrow="true"
                              @wxcCellClicked="handleChangeAddress"
                              :has-top-border="true">
                    </wxc-cell>
                </div>
            </div>
            <div class="product-info">
                <wxc-cell :has-arrow="false"
                          :has-top-border="true"
                          label="数量：">
                    <input name="value" class="product-info-input" type="number" placeholder="请输入数量">
                </wxc-cell>
                <wxc-cell :has-arrow="false"
                          :has-top-border="false"
                          label="金额：">
                    <input name="value" class="product-info-input" type="number" placeholder="请输入金额">
                </wxc-cell>
                <wxc-cell :has-arrow="true"
                          :has-top-border="false"
                          @wxcCellClicked="hanlePlayPick"
                          label="快递支付：">
                    <text name="value" class="product-info-input">{{paymentMethod ? paymentMethod : '请选择支付方式'}}</text>
                </wxc-cell>
            </div>
            <div class="product-info-play">
                <wxc-cell :has-arrow="false"
                          :has-top-border="true"
                          @wxcCellClicked="handleSelectPlay"
                          :auto-accessible="false">
                    <image class="product-info-play-icon"
                           slot="label"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/al-icon.png"></image>
                    <text class="product-info-play-title"
                          slot="title">支付宝
                    </text>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select.png"></image>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="!selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select-active.png"></image>
                </wxc-cell>
                <wxc-cell :has-arrow="false"
                          :has-top-border="false"
                          @wxcCellClicked="handleSelectPlay"
                          :auto-accessible="false">
                    <image class="product-info-play-icon"
                           slot="label"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/wx-icon.png"></image>
                    <text class="product-info-play-title"
                          slot="title">微信
                    </text>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select-active.png"></image>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="!selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select.png"></image>
                </wxc-cell>
            </div>
        <div class="footer">
            <div class="footer-total">
                <text class="footer-pay" @click="handleAddOrder">立即支付</text>
            </div>
        </div>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>

</template>

<script>
    import {WxcStepper, WxcLoading, WxcCell} from 'weex-ui';

    import mixin from '../../common/mixin';

    const picker = weex.requireModule('picker')

    export default {
        components: {
            WxcCell,
            WxcStepper,
            WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            saleOrderId: '',
            selectWXPlay: false,
            productNumber: 1,
            productInfo: '',
            isLoad: false,
            sumPrice: '',
            showSelectActive: true,
            addressData: '',
            saleOrderProductList: [],
            totalAmount: 0,
            expressAmount: 0,
            playItem: ['到付', '自付'],
            memberAddressId: '',
            paymentMethod: ''
        }),
        props: {

        },
        created () {
            
        },
        mounted () {
            this.changeTitle('提交订单');
            this.sumPrice = this.getParameter('totalAmount');
            this.storage.getItem("saleOrderProductList", (data) => {
                this.saleOrderProductList = JSON.parse(data.data)
            })
            this.handleAddressIsDefault();

            this.globalEvent.addEventListener('selectAddress', (data) => {
                // this.toast(data.memberAddressId);
                this.addressData.memberAddressId = data.memberAddressId;
                this.addressData.memberAddressProvince = data.memberAddressProvince;
                this.addressData.memberAddressName = data.memberAddressName;
                this.addressData.memberAddressCity = data.memberAddressCity;
                this.addressData.memberAddressArea = data.memberAddressArea;
                this.addressData.memberAddressDetail = data.memberAddressDetail;
            });

            if (this.platform != 'web') {
                this.globalEvent.addEventListener('getWeiXinPaySuccess', (data) => {
                    this.toast('订单处理成功');
                    this.pop();
                    this.push('/order/detail?saleOrderId=' + this.saleOrderId);
                });

                this.globalEvent.addEventListener('getWeiXinPayCancel', (data) => {
                    this.toast('付款失败');
                    this.pop();
                    this.push('/order/detail?saleOrderId=' + this.saleOrderId);
                });

                this.globalEvent.addEventListener('getWeiXinPayFail', (data) => {
                    this.toast('付款失败');
                    this.pop();
                    this.push('/order/detail?saleOrderId=' + this.saleOrderId);
                });
                this.globalEvent.addEventListener('getAliPaySuccess', (data) => {
                    this.toast('付款失败');
                    this.pop();
                    // this.push('/order/index?saleOrderStatus=' + ALL);
                    this.push('/order/detail?saleOrderId=' + this.saleOrderId);
                });
                this.globalEvent.addEventListener('getAliPayFail', (data) => {
                    this.toast('付款失败');
                    this.pop();
                    this.push('/order/detail?saleOrderId=' + this.saleOrderId);
                });
            }
        },
        methods: {
            handleAddressIsDefault() {
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/find/default',
                    data: {

                    },
                    success: (data) => {
                        this.addressData = data;
                    },
                    error: (data) => {

                    },
                });
            },
            onTextarea (e) {
                this.purchaseOrderRemark = e.value;
            },
            handleAddOrder() {
                if(!this.addressData.memberAddressId){
                    this.toast("地址不能为空");
                    return;
                }
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/purchase/order/mobile/v1/save',
                    data: {
                        purchaseOrderProductList: this.saleOrderProductList,
                        memberAddressId: this.addressData.memberAddressId,
                        purchaseOrderFrom: "V+Lab_app",
                    },
                    success: (data) => {
                        this.saleOrderId = data.purchaseOrderId
                        if(this.selectWXPlay){
                            this.handleWxPlay(data.purchaseOrderId);
                        } else {
                            this.handleAlPlay(data.purchaseOrderId);
                        }
                    },
                    error: (data) => {
                        this.toast(data);
                        this.isLoad = false;
                    }
                });
            },
            handleAlPlay(purchaseOrderId) {
                this.request({
                    url: '/xingxiao/purchase/order/mobile/v1/app/alipay',
                    data: {
                        purchaseOrderId: purchaseOrderId
                    },
                    success: (data) => {
                        this.chuangshi.getAliPay({
                        	payOrder: data.body
                        });
                        this.isLoad = false;
                    }
                })
            },
            handleWxPlay(purchaseOrderId) {
                this.request({
                    url: '/xingxiao/purchase/order/mobile/v1/mini/wxpay',
                    data: {
                        purchaseOrderId: purchaseOrderId
                    },
                    success: (data) => {
                        this.chuangshi.getWeiXinPay({
                            appId: data.appid,
                            partnerId: data.partnerid,
                            prepayId: data.prepayid,
                            package: data.packagestr,
                            nonceStr: data.noncestr,
                            timeStamp: data.timestamp,
                            sign: data.sign
                        });
                        this.isLoad = false;
                    }
                })
            },
            hanlePlayPick () {
                picker.pick({
                    items: this.playItem,
                    height: "500px",
                    confirmTitle: '确定',
                    cancelTitle: '取消'
                }, event => {
                    var result = event.result;
                    if (result == 'success') {
                        this.paymentMethod = this.playItem[event.data];
                    }
                })
            },
            handleChangeAddress() {
                this.push('/my/delivery/index?selectAddress=' + true);
            },
            handleSelectPlay() {
                this.selectWXPlay = !this.selectWXPlay;
            }
        }
    }
</script>

<style scoped>
    .wrapper {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        margin-bottom: 90px;
        background-color: #f5f5f9;
    }

    .address{
        margin-top: 20px;
    }
    .address-list{
        width: 750px;
        padding-top: 30px !important;
        padding-bottom: 30px !important;
    }

    .product-info{
        width: 750px;
        margin-top: 20px;
    }

    .product-info-input{
        width: 240px;
        font-size: 30px;
        text-align: right;
        color: #666666;
    }

    .product-info-play{
        margin-top: 20px;
    }
    .product-info-play-icon {
        width: 56px;
        height: 56px;
    }
    .product-info-play-title{
        width: 580px;
        height: 46px;
        margin-left: 14px;
    }
    .product-info-play-valus{
        width: 46px;
        height: 46px;
        margin-right: 20px;
    }

    .footer {
        width: 750px;
        height: 90px;
        position: fixed;
        bottom: 0px;
        left: 0px;
        right: 0px;
        background-color: #ffffff;
        border-top-color: #d9d9d9;
        border-top-width: 1px;
        border-top-style: solid;
    }
    .footer-total{
        height: 90px;
        background-color: #fff;
        flex-direction: row
    }
    .footer-pay {
        width: 750px;
        height: 90px;
        line-height: 90px;
        font-size: 32px;
        color: #fff;
        text-align: center;
        background-color: #e994a9;
    }
</style>
