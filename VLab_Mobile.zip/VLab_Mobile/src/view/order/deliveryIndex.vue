<template>
    <scroller class="container"
              @loadmore="handleLoadMore"
              loadmoreoffset="20"
              :style="{height: pageHeight + 'px'}">
        <div class="handle">
            <image class="handle-depoy-img"
                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-01-icon.png"></image>
            <text class="handle-my-depot">我的总仓库存:0</text>
        </div>
        <div class="tab">
            <text class="tab-list"
                 :class="[saleAction == '' ? 'tab-list-active': '']"
                 @click="handleTab('')">全部</text>
            <text class="tab-list"
                 :class="[saleAction == 'WAITING_DELIVERY' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_DELIVERY')">待发货</text>
            <text class="tab-list"
                 :class="[saleAction == 'WAITING_RECEIVE' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_RECEIVE')">待收货</text>
            <text class="tab-list"
                 :class="[saleAction == 'COMPLETE' ? 'tab-list-active': '']"
                 @click="handleTab('COMPLETE')">已完成</text>
        </div>
        <div class="order">
            <div class="order-list"
                 v-for="(orderList, index) in deliveryOrderProductList"
                 :key="index">
                <div class="order-list-hander" @click="handleToDetail(orderList.deliveryOrderId)">
                    <div class="order-list-hander-number">
                        <div class="order-list-hander-number-box">
                            <image class="order-list-hander-number-img"
                                   v-if="orderList"
                                   :src="imageHost + orderList.memberAvatarPath"></image>
                            <text class="order-list-hander-number-text">{{orderList.memberNickName}}</text>
                        </div>
                    </div>
                    <text class="order-list-hander-state" v-if="orderList.deliveryOrderStatus == 'WAIT_WAREHOUSE_DELIVERY'">待仓库发货</text>
                    <text class="order-list-hander-state" v-if="orderList.deliveryOrderStatus == 'WAITING_DELIVERY'">待发货</text>
                    <text class="order-list-hander-state" v-if="orderList.deliveryOrderStatus == 'WAITING_RECEIVE'">待收货</text>
                    <text class="order-list-hander-state" v-if="orderList.deliveryOrderStatus == 'COMPLETE'">已完成</text>
                </div>
                <div class="order-list-body"
                     @click="handleToDetail(orderList.deliveryOrderId)"
                     v-for="children in orderList.deliveryOrderProductList">
                    <image class="order-list-body-image"
                           v-if="orderList"
                           :src="imageHost + children.productImagePath"></image>
                    <div class="order-list-body-info">
                        <text class="order-list-body-info-title">{{children.productTitle}}</text>
                        <text class="order-list-body-info-price">￥{{children.productOriginalPrice}} X {{children.productQuantity}}</text>
                    </div>
                </div>
                <text class="order-list-footer"
                      @click="handleToDetail(orderList.purchaseOrderId)">共{{orderList.deliveryOrderProductList.length}}件产品，合计:￥{{orderList.deliveryOrderTotalAmount}}</text>
                <div class="order-list-address"
                     @click="handleToDetail(orderList.purchaseOrderId)">
                    <text class="order-list-address-member">{{orderList.deliveryOrderReceiveName}} 电话:{{orderList.deliveryOrderReceiveMobile}}</text>
                    <text class="order-list-address-time">{{orderList.systemCreateTime}}</text>
                </div>
                <div class="order-list-sublime"
                     v-if="orderList.deliveryOrderStatus == 'WAITING_DELIVERY'">
                    <text class="order-list-sublime-slef" @click="handleSlefWarehouse(orderList.deliveryOrderId)">自己发货</text>
                    <text style="flex: 1"></text>
                    <text class="order-list-sublime-sum" @click="handleSumWarehouse(orderList.deliveryOrderId)">总仓库代发货</text>
                </div>
            </div>
        </div>

        <div v-if="deliveryOrderProductList.list">
            <div class="no-data"
                 v-if="deliveryOrderProductList.list.length == 0">
                <image class="no-data-img"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
                <text class="no-data-text">当前没有数据</text>
            </div>
        </div>

        <wxc-dialog title="确定发货"
                    content="确定该订单交给总仓库代发货？"
                    cancel-text="取消"
                    confirm-text="确定"
                    :show="showDialog"
                    main-btn-color="#e994a9"
                    @wxcDialogCancelBtnClicked="wxcExitCancel"
                    @wxcDialogConfirmBtnClicked="wxcExitConfirm">
        </wxc-dialog>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading, WxcDialog} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcLoading,
            WxcDialog
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            showDialog: false,
            isLoad: false,
            pageIndex: 1,
            pageSize: 10,
            deliveryOrderStatus: '',
            deliveryOrderProductList: '',
            saleAction: '',
            totalProductList: '',
            deliveryOrderId: ''
        }),
        mounted () {
            this.changeTitle('我的订单');
            if(decodeURI(decodeURI(this.getParameter('deliveryOrderStatus'))) != 'ALL'){
                this.deliveryOrderStatus = decodeURI(decodeURI(this.getParameter('deliveryOrderStatus')));
                this.saleAction = decodeURI(decodeURI(this.getParameter('deliveryOrderStatus')));
            }
            this.handleLoad();

            this.globalEvent.addEventListener('deliverySuccess', (data) => {
                this.saleAction = '';
                this.handleLoad();
            })

        },
        methods: {
            wxcExitCancel () {
                this.showDialog = false;
            },
            wxcExitConfirm () {
                this.request({
                    url: '/xingxiao/delivery/order/mobile/v1/warehouse/replace/deliver',
                    data: {
                        deliveryOrderId: this.deliveryOrderId
                    },
                    success: (data) => {
                         this.handleLoad();
                         this.toast("已由总仓库发货")
                    }
                })
                this.showDialog = false;
            },
            handleSumWarehouse: function(deliveryOrderId) {
                this.showDialog = true;
                this.deliveryOrderId = deliveryOrderId;
                // this.push('/order/warehouseReplace');
            },
            handleSlefWarehouse: function(deliveryOrderId) {
                this.push('/order/slefReplace?deliveryOrderId=' + deliveryOrderId);
            },
            handleLoadMore: function() {
                this.pageSize = this.pageSize + 6;
                if(this.pageSize >= this.totalProductList){
                    return;
                }
                this.handleLoad();
            },
             formatTime: function(timestamp) {
                var date = new Date(timestamp);
                var year = date.getFullYear()
                var month = date.getMonth() + 1
                var day = date.getDate()
                var hour = date.getHours()
                var minute = date.getMinutes()
                var second = date.getSeconds()
                return [year, month, day].join('-') + ' ' + [hour, minute, second].join(':');
            },
            handleLoad: function() {
                this.request({
                    url: '/xingxiao/delivery/order/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        deliveryOrderStatus: this.deliveryOrderStatus
                    },
                    success: (data) => {
                        for(let i = 0; i < data.list.length; i++) {
                            for(let j = 0; j < data.list[i].deliveryOrderProductList.length; j++) {
                               data.list[i].deliveryOrderProductList[j].productOriginalPrice = data.list[i].deliveryOrderProductList[j].productOriginalPrice.toFixed(2);
                            }
                        }
                        this.deliveryOrderProductList = data.list;
                        this.totalProductList = data.total;
                    },
                    error: (data) => {
                        this.isLoad = false;
                    }
                });
            },
            handleTab: function (status) {
                this.saleAction = status;
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/delivery/order/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        deliveryOrderStatus: status
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.deliveryOrderProductList = data.list;
                    },
                    error: (data) => {
                        // this.toast(data.message);
                    }
                });
            },
            handleToDetail: function (deliveryOrderId) {
                this.push('/order/deliveryDetail?deliveryOrderId=' + deliveryOrderId);
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        padding-bottom: 20px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .handle{
        width: 750px;
        height: 120px;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        background-color: #ffffff;
        margin-top: 20px;
        margin-bottom: 20px;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #cccccc;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        padding-top: 20px;
        padding-right: 20px;
        padding-bottom: 20px;
        padding-left: 20px;
    }
    .handle-depoy-img{
        width: 50px;
        height: 46px;
        margin-left: 20px;
        margin-right: 20px;
    }
    .handle-my-depot{
        flex: 1;
        height: 40px;
    }
    .tab{
        width: 750px;
        height: 90px;
        flex-direction: row;
        flex-wrap: wrap;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #cccccc;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        margin-bottom: 18px;
        z-index: 999;
    }
    .tab-list{
        width: 187.5px;
        line-height: 90px;
        text-align: center;
        padding-right: 0px;
        padding-left: 0px;
    }
    .tab-list-active{
        color: #e994a9;
        border-bottom-style: solid;
        border-bottom-width: 4px;
        border-bottom-color: #e994a9;
    }

    .order{
        width: 750px;
        padding-bottom: 20px;
    }
    .order-list{
        width: 750px;
        margin-bottom: 10px;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #cccccc;
    }
    .order-list-hander{
        padding: 20px 10px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        flex-direction: row;
        justify-content: center;
    }
    .order-list-hander-number{
        width: 530px;
        padding-top: 0px;
        padding-left: 20px;
        padding-bottom: 0px;
        padding-right: 16px;
    }
    .order-list-hander-number-box{
        flex-direction: row;
        justify-content: center;
    }
    .order-list-hander-number-text{
        flex: 1;
        line-height: 60px;
        padding-left: 10px;
        white-space: nowrap
    }
    .order-list-hander-number-img {
        width: 60px;
        height: 60px;
    }
    .order-list-hander-state{
        width: 180px;
        text-align: right;
        color: #e994a9;
    }
    .order-list-body{
        flex-direction: row;
        flex-wrap: wrap;
        padding-top: 20px;
        padding-right: 20px;
        padding-bottom: 20px;
        padding-left: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-body-image{
        width: 150px;
        height: 150px;
        margin-right: 20px;
    }
    .order-list-body-info{
        flex: 1;
    }
    .order-list-body-info-title{
        margin-top: 20px;
        font-weight: bold;
    }
    .order-list-body-info-price{
        color: #999999;
    }
    .order-list-footer{
        padding: 20px 30px 20px 20px;
        text-align: left;
        font-size: 28px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-address{
        flex-direction: row;
        padding: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-address-member{
        flex: 1;
    }
    .order-list-address-time{
        width: 300px;
        padding-top: 6px;
        font-size: 28px;
        text-align: right;
    }
    .order-list-sublime{
        padding-left: 20px;
        padding-right: 20px;
        padding-top: 20px;
        padding-bottom: 20px;
        flex-direction: row;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-sublime-slef{
        width: 180px;
        height: 60px;
        line-height: 60px;
        color: #ffffff;
        background-color: #e994a9;
        font-size: 30px;
        padding: 0px 20px;
        text-align: center;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }
    .order-list-sublime-sum{
        width: 220px;
        height: 60px;
        line-height: 60px;
        color: #ffffff;
        background-color: #e994a9;
        font-size: 30px;
        padding: 0px 20px;
        text-align: center;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

</style>
