<template>
    <scroller class="container"
              @loadmore="handleLoadMore"
              loadmoreoffset="20"
              :style="{height: pageHeight + 'px'}">
        <div class="tab">
            <text class="tab-list"
                 :class="[purchaseAction == '' ? 'tab-list-active': '']"
                 @click="handleTab('')">全部</text>
            <text class="tab-list"
                 :class="[purchaseAction == 'WAITING_PAID' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_PAID')">待付款</text>
            <text class="tab-list"
                 :class="[purchaseAction == 'WAITING_DELIVERY' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_DELIVERY')">待发货</text>
            <text class="tab-list"
                 :class="[purchaseAction == 'WAITING_RECEIVE' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_RECEIVE')">待收货</text>
            <text class="tab-list"
                 :class="[purchaseAction == 'COMPLETE' ? 'tab-list-active': '']"
                 @click="handleTab('COMPLETE')">已完成</text>
        </div>
        <div class="order">
            <div class="order-list"
                 v-for="(orderList, index) in purchaseOrderProductList"
                 :key="index">
                <div class="order-list-hander"
                     @click="handleToDetail(orderList.purchaseOrderId)">
                    <div class="order-list-hander-number">
                        <div class="order-list-hander-number-box">
                            <image class="order-list-hander-number-img"
                                   v-if="orderList"
                                   :src="imageHost + orderList.deliverMemberAvatarPath"></image>
                            <text class="order-list-hander-number-text">{{orderList.deliverMemberNickName}}</text>
                        </div>
                    </div>
                    <text class="order-list-hander-state" v-if="orderList.purchaseOrderStatus == 'WAITING_PAID'">待付款</text>
                    <text class="order-list-hander-state" v-if="orderList.purchaseOrderStatus == 'WAITING_DELIVERY'">待发货</text>
                    <text class="order-list-hander-state" v-if="orderList.purchaseOrderStatus == 'WAITING_RECEIVE'">待收货</text>
                    <text class="order-list-hander-state" v-if="orderList.purchaseOrderStatus == 'COMPLETE'">已完成</text>
                </div>
                <div class="order-list-body"
                     @click="handleToDetail(orderList.purchaseOrderId)"
                     v-for="children in orderList.purchaseOrderProductList">
                    <image class="order-list-body-image"
                           v-if="orderList"
                           :src="imageHost + children.productImagePath"></image>
                    <div class="order-list-body-info">
                        <text class="order-list-body-info-title">{{children.productTitle}}</text>
                        <text class="order-list-body-info-price">￥{{children.productOriginalPrice}} X {{children.productQuantity}}</text>
                    </div>
                </div>
                <text class="order-list-footer"
                      @click="handleToDetail(orderList.purchaseOrderId)">共{{orderList.purchaseOrderProductList.length}}件产品，合计:￥{{orderList.purchaseOrderTotalAmount}}</text>
                <div class="order-list-address"
                     @click="handleToDetail(orderList.purchaseOrderId)">
                    <text class="order-list-address-member">{{orderList.purchaseOrderReceiveName}} 电话:{{orderList.purchaseOrderReceiveMobile}}</text>
                    <text class="order-list-address-time">{{orderList.systemCreateTime}}</text>
                </div>
                <div class="order-list-sublime"
                     v-if="orderList.purchaseOrderStatus == 'WAITING_PAID'"
                     @click="handleToDetail(orderList.purchaseOrderId)">
                    <text class="order-list-sublime-text">立即付款</text>
                </div>
            </div>
        </div>

        <div v-if="purchaseOrderProductList.list">
            <div class="no-data"
                 v-if="purchaseOrderProductList.list.length == 0">
                <image class="no-data-img"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
                <text class="no-data-text">当前没有数据</text>
            </div>
        </div>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcLoading
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            pageIndex: 1,
            pageSize: 10,
            purchaseOrderStatus: '',
            purchaseOrderProductList: '',
            purchaseAction: '',
            totalProductList: ''
        }),
        mounted () {
            this.changeTitle('我的订单');
            if(decodeURI(decodeURI(this.getParameter('purchaseOrderStatus'))) != 'ALL'){
                this.purchaseOrderStatus = decodeURI(decodeURI(this.getParameter('purchaseOrderStatus')));
                this.purchaseAction = decodeURI(decodeURI(this.getParameter('purchaseOrderStatus')));
            }
            this.handleLoad();
        },
        methods: {
            handleLoadMore: function() {
                this.pageSize = this.pageSize + 6;
                if(this.pageSize >= this.totalProductList){
                    return;
                }
                this.handleLoad();
                // console.log(this.totalProductList)
            },
             formatTime: function(timestamp) {
                var date = new Date(timestamp);
                var year = date.getFullYear()
                var month = date.getMonth() + 1
                var day = date.getDate()
                var hour = date.getHours()
                var minute = date.getMinutes()
                var second = date.getSeconds()
                return [year, month, day].join('-') + ' ' + [hour, minute, second].join(':');
            },
            handleLoad: function() {
                this.request({
                    url: '/xingxiao/purchase/order/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        purchaseOrderStatus: this.purchaseOrderStatus,
                        purchaseOrderProductList: []
                    },
                    success: (data) => {
                        this.purchaseOrderProductList = data.list;
                        for(let i = 0; i < this.purchaseOrderProductList.length; i++){
                            for(let c in this.purchaseOrderProductList[i].purchaseOrderProductList){
                                this.purchaseOrderProductList[i].purchaseOrderProductList[c].productOriginalPrice = this.purchaseOrderProductList[i].purchaseOrderProductList[c].productOriginalPrice.toFixed(2);
                            }
                            this.purchaseOrderProductList[i].systemCreateTime = this.formatTime(this.purchaseOrderProductList[i].systemCreateTime);
                            this.purchaseOrderProductList[i].purchaseOrderTotalAmount = this.purchaseOrderProductList[i].purchaseOrderTotalAmount.toFixed(2);
                        }
                        this.totalProductList = data.total
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleTab: function (status) {
                this.purchaseAction = status;
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/purchase/order/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        purchaseOrderStatus: status
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.purchaseOrderProductList = data.list;
                    },
                    error: (data) => {
                        // this.toast(data.message);
                    }
                });
            },
            handleToDetail: function (purchaseOrderId) {
                this.push('/order/purchaseDetail?purchaseOrderId=' + purchaseOrderId);
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        padding-bottom: 20px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .tab{
        width: 750px;
        height: 90px;
        flex-direction: row;
        flex-wrap: wrap;
        background-color: #ffffff;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        margin-bottom: 18px;
        position: sticky;
        left: 0px;
        top: 0px;
        z-index: 999;
    }
    .tab-list{
        width: 150px;
        text-align: center;
        padding-top: 26px;
        padding-right: 0px;
        padding-left: 0px;
        padding-bottom: 14px;
    }
    .tab-list-active{
        color: #e994a9;
        border-bottom-style: solid;
        border-bottom-width: 4px;
        border-bottom-color: #e994a9;
    }

    .order{
        width: 750px;
        padding-bottom: 20px;
    }
    .order-list{
        width: 750px;
        margin-bottom: 10px;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #cccccc;
    }
    .order-list-hander{
        padding: 20px 10px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        flex-direction: row;
        justify-content: center;
    }
    .order-list-hander-number{
        width: 630px;
        padding: 0px 16px;
    }
    .order-list-hander-number-box{
        flex-direction: row;
        justify-content: center;
    }
    .order-list-hander-number-text{
        flex: 1;
        line-height: 60px;
        padding-left: 10px;
        white-space: nowrap
    }
    .order-list-hander-number-img {
        width: 60px;
        height: 60px;
    }
    .order-list-hander-state{
        width: 120px;
        text-align: left;
        color: #e994a9;
    }
    .order-list-body{
        flex-direction: row;
        flex-wrap: wrap;
        padding-top: 20px;
        padding-right: 20px;
        padding-bottom: 20px;
        padding-left: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-body-image{
        width: 150px;
        height: 150px;
        margin-right: 20px;
    }
    .order-list-body-info{
        flex: 1;
    }
    .order-list-body-info-title{
        margin-top: 20px;
        font-weight: bold;
    }
    .order-list-body-info-price{
        color: #999999;
    }
    .order-list-footer{
        padding: 20px 30px 20px 20px;
        text-align: left;
        font-size: 28px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-address{
        flex-direction: row;
        padding: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-address-member{
        flex: 1;
    }
    .order-list-address-time{
        width: 300px;
        padding-top: 6px;
        font-size: 28px;
        text-align: right;
    }
    .order-list-sublime{
        padding-left: 80px;
        padding-top: 20px;
        padding-bottom: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-sublime-text{
        width: 180px;
        height: 60px;
        line-height: 60px;
        color: #ffffff;
        background-color: #e994a9;
        font-size: 30px;
        padding: 0px 20px;
        text-align: center;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

</style>
