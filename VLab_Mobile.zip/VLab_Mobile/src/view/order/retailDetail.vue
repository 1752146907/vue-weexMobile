<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="order-info" v-if="saleOrderDetail.saleOrderStatus">
            <wxc-cell v-if="saleOrderDetail.saleOrderStatus == 'WAITING_PAID'"
                      title="您的订单：待付款"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell v-if="saleOrderDetail.saleOrderStatus == 'WAITING_DELIVERY'"
                      title="您的订单：待发货"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell v-if="saleOrderDetail.saleOrderStatus == 'WAITING_RECEIVE'"
                      title="您的订单：待收货"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell v-if="saleOrderDetail.saleOrderStatus == 'COMPLETE'"
                      title="您的订单：已完成"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true">
            </wxc-cell>
            <wxc-cell :title="'订单编号：' + saleOrderDetail.saleOrderId"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true"></wxc-cell>
            <wxc-cell :title="'下单时间：' + saleOrderDetail.systemCreateTime"
                      class="address-list"
                      :has-arrow="false"
                      :has-top-border="true"></wxc-cell>
        </div>

        <div class="address">
            <text class="address-title">{{saleOrderDetail.saleOrderReceiveName}} {{saleOrderDetail.saleOrderReceiveMobile}}</text>
            <text class="address-value">{{saleOrderDetail.saleOrderReceiveCity + saleOrderDetail.saleOrderReceiveArea + saleOrderDetail.saleOrderReceiveAddress}}</text>
            <!--<wxc-cell :title="saleOrderDetail.saleOrderReceiveName + saleOrderDetail.saleOrderReceiveMobile"-->
                      <!--:desc="saleOrderDetail.saleOrderReceiveCity + saleOrderDetail.saleOrderReceiveArea + saleOrderDetail.saleOrderReceiveAddress"-->
                      <!--class="address-list"-->
                      <!--:has-arrow="false"-->
                      <!--:has-top-border="true">-->
            <!--</wxc-cell>-->
        </div>

        <div class="order-list"
             v-if="saleOrderDetail">
            <div class="order-list-body">
                <image class="order-list-body-image"
                       :src="imageHost + saleOrderDetail.saleOrderProductList[0].productImagePath"></image>
                <div class="order-list-body-info">
                    <text class="order-list-body-info-title">{{saleOrderDetail.saleOrderProductList[0].productTitle}}</text>
                    <text class="order-list-body-info-price">￥{{saleOrderDetail.saleOrderProductList[0].productPrice}} X {{saleOrderDetail.saleOrderProductList[0].productQuantity}}</text>
                </div>
            </div>
        </div>

        <div class="product-info">
            <wxc-cell :has-arrow="false"
                      :has-top-border="true"
                      label="商品金额">
                <slot name="value">
                    <text class="product-info-value">￥{{saleOrderDetail.saleOrderPayAccount}}</text>
                </slot>
            </wxc-cell>
            <wxc-cell :has-arrow="false"
                      :has-top-border="false"
                      label="运费">
                <slot name="value">
                    <text class="product-info-value">￥{{saleOrderDetail.saleOrderExpressAmount}}</text>
                </slot>
            </wxc-cell>
        </div>

        <div class="product-info-play"
             v-if="saleOrderDetail.saleOrderStatus == 'WAITING_PAID'">
            <wxc-cell :has-arrow="false"
                      :has-top-border="true"
                      @wxcCellClicked="handleSelectPlay"
                      :auto-accessible="false">
                <image class="product-info-play-icon"
                       slot="label"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/al-icon.png"></image>
                <text class="product-info-play-title"
                      slot="title">支付宝
                </text>
                <image class="product-info-play-valus"
                       slot="value"
                       v-if="selectWXPlay"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select.png"></image>
                <image class="product-info-play-valus"
                       slot="value"
                       v-if="!selectWXPlay"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select-active.png"></image>
            </wxc-cell>
            <wxc-cell :has-arrow="false"
                      :has-top-border="false"
                      @wxcCellClicked="handleSelectPlay"
                      :auto-accessible="false">
                <image class="product-info-play-icon"
                       slot="label"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/wx-icon.png"></image>
                <text class="product-info-play-title"
                      slot="title">微信
                </text>
                <image class="product-info-play-valus"
                       slot="value"
                       v-if="selectWXPlay"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select-active.png"></image>
                <image class="product-info-play-valus"
                       slot="value"
                       v-if="!selectWXPlay"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select.png"></image>
            </wxc-cell>
        </div>

        <div class="footer">
            <div class="footer-total">
                <div class="footer-total-text" v-if="saleOrderDetail.saleOrderStatus == 'WAITING_PAID'">
                    <text class="total-amount">总金额: ￥{{saleOrderDetail.saleOrderPayAccount}}</text>
                </div>
                <div class="footer-total-text" v-if="saleOrderDetail.saleOrderStatus != 'WAITING_PAID'">
                    <text class="total-amount">实付款：￥{{saleOrderDetail.saleOrderPayAccount}}</text>
                </div>
                <div class="footer-pay"
                     @click="handlePlay"
                     v-if="saleOrderDetail.saleOrderStatus == 'WAITING_PAID'">
                    <text class="footer-pay-text">立即支付</text>
                </div>
            </div>
        </div>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcLoading
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            selectWXPlay: false,
            isLoad: false,
            saleOrderId: '',
            saleOrderDetail: ''
        }),
        mounted () {
            this.changeTitle('订单详情');
            this.saleOrderId = decodeURI(decodeURI(this.getParameter('saleOrderId')));
            this.handleLoad();

            if (this.platform != 'web') {
                this.globalEvent.addEventListener('getAliPaySuccess', (data) => {
                    this.toast('订单处理成功');
                    this.isLoad = false;
                    this.push('/order/index?saleOrderStatus=' + ALL);
                });
                this.globalEvent.addEventListener('getAliPayFail', (data) => {
                    this.toast('订单处理失败');
                    this.isLoad = false;
                });
            }
        },
        methods: {
            handleLoad: function () {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/find',
                    data: {
                        saleOrderId: this.saleOrderId
                    },
                    success: (data) => {
                        data.systemCreateTime = this.formatTime(data.systemCreateTime)
                        this.saleOrderDetail = data;
                    },
                    error: (data) => {
                        // this.toast(data.message);
                    }
                });
            },
            handlePlay: function () {
                this.isLoad = true;
                if(this.selectWXPlay){
                    this.handleWxPlay(this.saleOrderId);
                } else {
                    this.handleAlPlay(this.saleOrderId);
                }
            },
            handleAlPlay(saleOrderId) {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/app/alipay',
                    data: {
                        saleOrderId: saleOrderId
                    },
                    success: (data) => {
                        this.chuangshi.getAliPay({
                            payOrder: data.body
                        });
                    }
                })
            },
            handleWxPlay(saleOrderId) {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/app/wxpay',
                    data: {
                        saleOrderId: saleOrderId
                    },
                    success: (data) => {
                        this.chuangshi.getWeiXinPay({
                            appId: data.appid,
                            partnerId: data.partnerid,
                            prepayId: data.prepayid,
                            package: data.packagestr,
                            nonceStr: data.noncestr,
                            timeStamp: data.timestamp,
                            sign: data.sign
                        });
                        this.isLoad = false;
                    }
                })
            },
            handleSelectPlay() {
                this.selectWXPlay = !this.selectWXPlay;
            },
            formatTime: function (timestamp) {
                var date = new Date(timestamp);

                var year = date.getFullYear()
                var month = date.getMonth() + 1
                var day = date.getDate()

                var hour = date.getHours()
                var minute = date.getMinutes()
                var second = date.getSeconds()

                return [year, month, day].join('-') + ' ' + [hour, minute, second].join(':');
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        padding-bottom: 20px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
        padding-bottom: 150px;
    }

    .order-info{
        margin-top: 20px;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
    }

    .order-list{
        width: 750px;
        margin-top: 20px;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
    }
    .order-list-body{
        flex-direction: row;
        flex-wrap: wrap;
        padding: 20px;
    }
    .order-list-body-image{
        width: 150px;
        height: 150px;
        margin-right: 20px;
    }
    .order-list-body-info{
        flex: 1;
    }
    .order-list-body-info-title{
        margin-top: 10px;
        font-weight: bold;
    }
    .order-list-body-info-price{
        color: #999999;
        font-size: 28px;
    }

    .product-info-play{
        margin-top: 20px;
    }
    .product-info-play-icon {
        width: 56px;
        height: 56px;
    }
    .product-info-play-title{
        width: 580px;
        height: 46px;
        margin-left: 14px;
    }
    .product-info-play-valus{
        width: 46px;
        height: 46px;
        margin-right: 20px;
    }

    .address{
        margin-top: 20px;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #e2e2e2;
        background-color: #ffffff;
    }
    .address-list{
        width: 750px;
        border-top: none;
        font-size: 30px;
    }
    .address-title{
        width: 750px;
        font-size: 30px;
        color: #000000;
        padding-left: 24px;
        padding-top: 24px;
    }
    .address-value{
        font-size: 28px;
        color: #999999;
        padding-left: 24px;
        padding-right: 24px;
        padding-bottom: 24px;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
    }

    .product-info{
        width: 750px;
        margin-top: 30px;
    }
    .product-info-value{
        color: #999999;
        font-size: 30px;
    }

    .footer {
        width: 750px;
        height: 90px;
        position: fixed;
        bottom: 0px;
        left: 0px;
        right: 0px;
        background-color: #ffffff;
        border-top-width: 1px;
        border-top-color: #d9d9d9;
    }
    .footer-total{
        height: 90px;
        flex-direction: row
    }
    .footer-total-text{
        width: 530px;
        font-size: 22px;
        padding-top: 20px;
        padding-left: 20px;
        box-sizing: border-box;
    }
    .total-amount{
        font-size: 32px;
    }
    .footer-pay {
        width: 220px;
        height: 90px;
        background-color: #e994a9;
    }
    .footer-pay-text{
        line-height: 90px;
        font-size: 32px;
        text-align: center;
        color: #ffffff;
    }

</style>
