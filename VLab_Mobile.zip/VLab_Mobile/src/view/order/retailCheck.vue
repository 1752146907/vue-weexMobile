<template>
    <scroller class="wrapper"
              :style="{height: pageHeight + 'px'}">
            <div class="container">
                <div class="address"
                     v-if="addressData.memberAddressId">
                    <wxc-cell :title="addressData.memberAddressName + ' ' + addressData.memberAddressMobile"
                              :desc="addressData.memberAddressProvince + addressData.memberAddressCity + addressData.memberAddressArea + addressData.memberAddressDetail"
                              class="address-list"
                              :has-arrow="true"
                              @wxcCellClicked="handleChangeAddress"
                              :has-top-border="true">
                    </wxc-cell>
                </div>
            </div>
            <div class="product-info">
                <wxc-cell :has-arrow="false"
                          :has-top-border="true"
                          label="商品金额">
                    <text name="value">￥{{sumPrice}}</text>
                </wxc-cell>
                <wxc-cell :has-arrow="false"
                          :has-top-border="false"
                          label="运费">
                    <text name="value">￥{{expressAmount}}</text>
                </wxc-cell>
            </div>
            <div class="product-info-play">
                <wxc-cell :has-arrow="false"
                          :has-top-border="true"
                          @wxcCellClicked="handleSelectPlay"
                          :auto-accessible="false">
                    <image class="product-info-play-icon"
                           slot="label"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/al-icon.png"></image>
                    <text class="product-info-play-title"
                          slot="title">支付宝
                    </text>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select.png"></image>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="!selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select-active.png"></image>
                </wxc-cell>
                <wxc-cell :has-arrow="false"
                          :has-top-border="false"
                          @wxcCellClicked="handleSelectPlay"
                          :auto-accessible="false">
                    <image class="product-info-play-icon"
                           slot="label"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/wx-icon.png"></image>
                    <text class="product-info-play-title"
                          slot="title">微信
                    </text>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select-active.png"></image>
                    <image class="product-info-play-valus"
                           slot="value"
                           v-if="!selectWXPlay"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/select.png"></image>
                </wxc-cell>
            </div>
            <div class="footer">
                <div class="footer-total">
                    <div class="footer-total-text">
                        <!--<div class="selected-number">已选：{{productNumber}} 个</div>-->
                        <text class="footer-total-amount">总金额: ￥{{sumPrice}}</text>
                    </div>
                    <div class="footer-pay" @click="handleAddOrder">
                        <text class="footer-pay-text">立即支付</text>
                    </div>
                </div>
            </div>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>

</template>

<script>
    import {WxcStepper, WxcLoading, WxcCell} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcStepper,
            WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            saleOrderId: '',
            selectWXPlay: false,
            productNumber: 1,
            productInfo: '',
            isLoad: false,
            sumPrice: '',
            showSelectActive: true,
            addressData: '',
            saleOrderProductList: [],
            totalAmount: 0,
            expressAmount: 0,
            memberAddressId: ''
        }),
        props: {

        },
        created () {
            
        },
        mounted () {
            this.changeTitle('提交订单');
            this.sumPrice = this.getParameter('totalAmount');
            this.storage.getItem("saleOrderProductList", (data) => {
                this.saleOrderProductList = JSON.parse(data.data);
            })
            this.handleAddressIsDefault();

            this.globalEvent.addEventListener('selectAddress', (data) => {
                // this.toast(data.memberAddressId);
                this.addressData.memberAddressId = data.memberAddressId;
                this.addressData.memberAddressProvince = data.memberAddressProvince;
                this.addressData.memberAddressName = data.memberAddressName;
                this.addressData.memberAddressCity = data.memberAddressCity;
                this.addressData.memberAddressArea = data.memberAddressArea;
                this.addressData.memberAddressDetail = data.memberAddressDetail;
            });

            if (this.platform != 'web') {
                this.globalEvent.addEventListener('getWeiXinPaySuccess', (data) => {
                    this.toast('订单处理成功');
                    this.pop(-2);
                    this.push('/order/retailDetail?saleOrderId=' + this.saleOrderId);
                });

                this.globalEvent.addEventListener('getWeiXinPayCancel', (data) => {
                    this.toast('付款失败');
                    this.pop(-2);
                    this.push('/order/retailDetail?saleOrderId=' + this.saleOrderId);
                });

                this.globalEvent.addEventListener('getWeiXinPayFail', (data) => {
                    this.toast('付款失败');
                    this.pop(-2);
                    this.push('/order/retailDetail?saleOrderId=' + this.saleOrderId);
                });
                this.globalEvent.addEventListener('getAliPaySuccess', (data) => {
                    this.toast('付款失败');
                    this.pop(-2);
                    // this.push('/order/index?saleOrderStatus=' + ALL);
                    this.push('/order/retailDetail?saleOrderId=' + this.saleOrderId);
                });
                this.globalEvent.addEventListener('getAliPayFail', (data) => {
                    this.toast('付款失败');
                    this.pop(-2);
                    this.push('/order/retailDetail?saleOrderId=' + this.saleOrderId);
                });
            }
        },
        methods: {
            handleAddressIsDefault() {
                this.request({
                    url: '/xingxiao/member/address/mobile/v1/find/default',
                    data: {

                    },
                    success: (data) => {
                        this.addressData = data;
                    },
                    error: (data) => {

                    },
                });
            },
            handleAddOrder() {
                if(!this.addressData.memberAddressId){
                    this.toast("地址不能为空");
                    return;
                }
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/save',
                    data: {
                        saleOrderProductList: this.saleOrderProductList,
                        memberAddressId: this.addressData.memberAddressId,
                        memberCouponId: "",
                        memberInvoiceId: "",
                        saleOrderDeliverPattern: "",
                        saleOrderIsOpenInvoice: false,
                        saleOrderRemark: "",
                        saleOrderFrom: "V+Lab_app",
                    },
                    success: (data) => {
                        this.saleOrderId = data.saleOrderId
                        if(this.selectWXPlay){
                            this.handleWxPlay(data.saleOrderId);
                        } else {
                            this.handleAlPlay(data.saleOrderId);
                        }
                    },
                    error: (data) => {
                        this.toast(data);
                        this.isLoad = false;
                    }
                });
            },
            handleAlPlay(saleOrderId) {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/app/alipay',
                    data: {
                        saleOrderId: saleOrderId
                    },
                    success: (data) => {
                        this.chuangshi.getAliPay({
                            payOrder: data.body
                        });
                        this.isLoad = false;
                    }
                })
            },
            handleWxPlay(saleOrderId) {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/app/wxpay',
                    data: {
                        saleOrderId: saleOrderId
                    },
                    success: (data) => {
                        this.chuangshi.getWeiXinPay({
                            appId: data.appid,
                            partnerId: data.partnerid,
                            prepayId: data.prepayid,
                            package: data.packagestr,
                            nonceStr: data.noncestr,
                            timeStamp: data.timestamp,
                            sign: data.sign
                        });
                        this.isLoad = false;
                    }
                })
            },
            handleChangeAddress() {
                this.push('/my/delivery/index?selectAddress=' + true);
            },
            handleSelectPlay() {
                this.selectWXPlay = !this.selectWXPlay;
            }
        }
    }
</script>

<style scoped>
    .wrapper {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        margin-bottom: 90px;
        background-color: #f5f5f9;
    }

    .address{
        margin-top: 20px;
    }
    .address-list{
        width: 750px;
    }

    .product-info{
        width: 750px;
        margin-top: 20px;
    }

    .product-info-play{
        margin-top: 20px;
    }
    .product-info-play-icon {
        width: 56px;
        height: 56px;
    }
    .product-info-play-title{
        width: 580px;
        height: 46px;
        margin-left: 14px;
    }
    .product-info-play-valus{
        width: 46px;
        height: 46px;
        margin-right: 20px;
    }

    .footer {
        width: 750px;
        height: 90px;
        position: fixed;
        bottom: 0px;
        left: 0px;
        right: 0px;
        background-color: #ffffff;
        border-top-color: #d9d9d9;
        border-top-width: 1px;
        border-top-style: solid;
    }
    .footer-total{
        height: 90px;
        background-color: #fff;
        flex-direction: row
    }
    .footer-total-text{
        width: 530px;
        font-size: 22px;
        padding-top: 10px;
        padding-left: 20px;
        box-sizing: border-box;
    }
    .footer-total-text .selected-number{
        font-size: 18px;
    }
    .footer-total-amount{
        padding-top: 10px;
    }
    .footer-pay {
        width: 220px;
        height: 90px;
    }
    .footer-pay-text{
        line-height: 90px;
        font-size: 32px;
        color: #fff;
        text-align: center;
        background-color: #e994a9;
    }
</style>
