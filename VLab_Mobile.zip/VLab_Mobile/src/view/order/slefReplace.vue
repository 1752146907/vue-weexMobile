<template>
    <scroller class="wrapper"
              :style="{height: pageHeight + 'px'}">
        <div class="product-info"
             v-for="(item, index) in expressList"
             :key="index">
            <wxc-cell :has-arrow="true"
                      :has-top-border="true"
                      :has-bottom-border="false"
                      @wxcCellClicked="hanleExpressPick(index)"
                      label="快递公司：">
                <text name="value"
                      class="product-info-input">{{expressCode[item.expressCodeIndex].label}}</text>
            </wxc-cell>
            <wxc-cell :has-arrow="false"
                      :has-top-border="true"
                      label="快递单号：">
                <input name="value"
                       class="product-info-input"
                       type="number"
                       placeholder="请输入快递单号"
                       v-model="item.expressNo">
            </wxc-cell>
            <wxc-cell :has-arrow="false"
                      :has-top-border="false"
                      :has-bottom-border="false"
                      label="金额：">
                <input name="value"
                       class="product-info-input"
                       type="number"
                       v-model="item.expressCost"
                       placeholder="请输入金额">
            </wxc-cell>
            <div class="del-express"
                 v-if="item.isAllowDelete">
                <text class="del-express-text"
                      @click="handleDelExpress(index)">删除该快递单号</text>
            </div>
        </div>

        <div class='add-express'>
            <text class='add-express-text' @click='handleExpressAdd'>新增快递单</text>
        </div>

        <div class="footer">
            <div class="footer-total">
                <text class="footer-pay" @click="handleSublime">立即提交</text>
            </div>
        </div>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>

</template>

<script>
    import {WxcStepper, WxcLoading, WxcCell} from 'weex-ui';

    import mixin from '../../common/mixin';
    import expressCode from '../../common/expressCode';

    const picker = weex.requireModule('picker')

    export default {
        components: {
            WxcCell,
            WxcStepper,
            WxcLoading
        },
        mixins: [mixin],
        expressCode: [expressCode],
        data: () => ({
            isLoad: false,
            deliveryOrderId: '',
            express: [],
            expressList: [{
                expressCodeIndex: 0,
                courierServicesCompany: '',
                expressNo: '',
                expressCost: '',
                isAllowDelete: false
            }],
            expressCode: expressCode
        }),
        props: {

        },
        created () {

        },
        mounted () {
            this.changeTitle('新增快递单');
            this.deliveryOrderId = decodeURI(decodeURI(this.getParameter('deliveryOrderId')));
            this.handleExpressCode();
        },
        methods: {
            handleExpressCode () {
                for(let i = 0; i < this.expressCode.length; i++) {
                    this.express.push(this.expressCode[i].label);
                }
            },
            handleExpressAdd () {
                var expressList = this.expressList;

                expressList.push({
                    expressCodeIndex: 0,
                    courierServicesCompany: '',
                    expressNo: '',
                    expressCost: '',
                    isAllowDelete: true,
                    isCheck: true
                });

                this.expressList = expressList;
            },
            handleDelExpress (index) {
                this.expressList.splice(index, 1);
            },
            hanleExpressPick (index) {
                picker.pick({
                    items: this.express,
                    height: "500px",
                    confirmTitle: '确定',
                    cancelTitle: '取消'
                }, event => {
                    var result = event.result;
                    if (result == 'success') {
                        this.expressList[index].courierServicesCompany = this.express[event.data];
                        this.toast(this.express[event.data]);
                        this.expressList[index].expressCodeIndex = event.data;
                    }
                })
            },
            handleSublime () {
                if ( this.deliveryOrderId.trim() == "undefined" ) {
                    this.toast("未选择发货单")

                    return;
                }
                var expressList = this.expressList;
                var deliveryOrderExpressList = [];
                this.isCheck = true;

                for (var i = 0; i < expressList.length; i++) {

                    var express = expressList[i];
                    if (express.expressNo.trim() == '') {
                        this.toast('快递单号不能空');
                        this.isCheck = false;
                    }
                    if (express.expressCost.trim() == '') {
                        this.toast('运费不能为空');
                        this.isCheck = false;
                    }

                    if (express.expressCost < 0) {
                        this.toast('运费不能小于0');
                        this.isCheck = false;
                    }

                    deliveryOrderExpressList.push({
                        expressNo: express.expressNo,
                        expressCost: express.expressCost,
                        expressCompanyCode: expressCode[express.expressCodeIndex].value,
                        expressCompanyName: expressCode[express.expressCodeIndex].label
                    });
                }
                if (this.isCheck) {
                    this.isLoad = true;
                    this.request({
                        url: '/xingxiao/delivery/order/mobile/v1/self/deliver',
                        data: {
                            deliveryOrderId: this.deliveryOrderId,
                            deliveryOrderExpressList: deliveryOrderExpressList
                        },
                        success: (data) => {
                            this.chuangshi.sendEventListener({
                                name: 'deliverySuccess',
                                data: {

                                }
                            });

                            this.isLoad = false;
                            this.toast("提交成功");
                            this.pop();
                        }
                    })
                }
            }
        }
    }
</script>

<style scoped>
    .wrapper {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        padding-bottom: 190px;
        background-color: #f5f5f9;
    }

    .product-info{
        width: 750px;
        margin-top: 20px;
        background-color: #ffffff;
        border-bottom-color: #e2e2e2;
        border-bottom-width: 1px;
        border-bottom-style: solid;
    }

    .del-express{
        width: 750px;
        border-top-color: #e2e2e2;
        border-top-width: 1px;
        border-top-style: solid;
    }
    .del-express-text{
        width: 250px;
        background-color: #e994a9;
        margin-left: 20px;
        color: #ffffff;
        padding-top: 10px;
        padding-right: 20px;
        padding-bottom: 10px;
        padding-left: 20px;
        font-size: 30px;
        margin-top: 20px;
        margin-bottom: 20px;
        border-bottom-left-radius: 10px;
        border-bottom-right-radius: 10px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .product-info-input{
        width: 420px;
        font-size: 30px;
        text-align: right;
        color: #666666;
    }

    .add-express{
        margin-top: 80px;
        padding-top: 0px;
        padding-bottom: 0px;
    }
    .add-express-text{
        width: 650px;
        margin-left: 50px;
        line-height: 80px;
        text-align: center;
        background-color: #ffffff;
        border-top-color: #cccccc;
        border-top-width: 1px;
        border-top-style: solid;
        border-right-color: #cccccc;
        border-right-width: 1px;
        border-right-style: solid;
        border-bottom-color: #cccccc;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-left-color: #cccccc;
        border-left-width: 1px;
        border-left-style: solid;
        font-size: 32px;
        border-bottom-left-radius: 8px;
        border-bottom-right-radius: 8px;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .footer {
        width: 750px;
        height: 90px;
        position: fixed;
        bottom: 0px;
        left: 0px;
        right: 0px;
        background-color: #ffffff;
        border-top-color: #d9d9d9;
        border-top-width: 1px;
        border-top-style: solid;
    }
    .footer-total{
        height: 90px;
        background-color: #fff;
        flex-direction: row
    }
    .footer-pay {
        width: 750px;
        height: 90px;
        line-height: 90px;
        font-size: 32px;
        color: #fff;
        text-align: center;
        background-color: #e994a9;
    }
</style>
