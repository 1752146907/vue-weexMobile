<template>
    <scroller class="container"
              @loadmore="handleLoadMore"
              loadmoreoffset="20"
              :style="{height: pageHeight + 'px'}">
        <div class="tab">
            <text class="tab-list"
                 :class="[saleAction == '' ? 'tab-list-active': '']"
                 @click="handleTab('')">全部</text>
            <text class="tab-list"
                 :class="[saleAction == 'WAITING_PAID' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_PAID')">待付款</text>
            <text class="tab-list"
                 :class="[saleAction == 'WAITING_DELIVERY' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_DELIVERY')">待发货</text>
            <text class="tab-list"
                 :class="[saleAction == 'WAITING_RECEIVE' ? 'tab-list-active': '']"
                 @click="handleTab('WAITING_RECEIVE')">待收货</text>
            <text class="tab-list"
                 :class="[saleAction == 'COMPLETE' ? 'tab-list-active': '']"
                 @click="handleTab('COMPLETE')">已完成</text>
        </div>
        <div class="order">
            <div class="order-list" @click="handleToDetail(orderList.saleOrderId)"
                 v-for="(orderList, index) in saleOrderProductList.list"
                 :key="index">
                <div class="order-list-hander">
                    <div class="order-list-hander-number">
                        <text class="order-list-hander-number-text">订单号:{{orderList.saleOrderId}}</text>
                    </div>
                    <text class="order-list-hander-state" v-if="orderList.saleOrderStatus == 'WAITING_PAID'">待付款</text>
                    <text class="order-list-hander-state" v-if="orderList.saleOrderStatus == 'WAITING_DELIVERY'">待发货</text>
                    <text class="order-list-hander-state" v-if="orderList.saleOrderStatus == 'WAITING_RECEIVE'">待收货</text>
                    <text class="order-list-hander-state" v-if="orderList.saleOrderStatus == 'COMPLETE'">已完成</text>
                </div>
                <div class="order-list-body">
                    <image class="order-list-body-image"
                           v-if="orderList"
                           :src="imageHost + orderList.saleOrderProductList[0].productImagePath"></image>
                    <div class="order-list-body-info">
                        <text class="order-list-body-info-title">{{orderList.saleOrderProductList[0].productTitle}}</text>
                        <text class="order-list-body-info-price">￥{{orderList.saleOrderProductList[0].productPrice}} X {{orderList.saleOrderTotalQuantity}}</text>
                    </div>
                </div>
                <text class="order-list-footer">共{{orderList.saleOrderTotalQuantity}}件产品，合计：￥{{orderList.saleOrderPayAccount}}</text>
            </div>
        </div>

        <div v-if="saleOrderProductList.list">
            <div class="no-data"
                 v-if="saleOrderProductList.list.length == 0">
                <image class="no-data-img"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
                <text class="no-data-text">当前没有数据</text>
            </div>
        </div>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcLoading
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isLoad: false,
            pageIndex: 1,
            pageSize: 10,
            saleOrderStatus: '',
            saleOrderProductList: '',
            saleAction: '',
            totalProductList: ''
        }),
        mounted () {
            this.changeTitle('我的订单');
            if(decodeURI(decodeURI(this.getParameter('saleOrderStatus'))) != 'ALL'){
                this.saleOrderStatus = decodeURI(decodeURI(this.getParameter('saleOrderStatus')));
                this.saleAction = decodeURI(decodeURI(this.getParameter('saleOrderStatus')));
            }
            this.handleLoad();
        },
        methods: {
            handleLoadMore: function() {
                this.pageSize = this.pageSize + 6;
                if(this.pageSize >= this.totalProductList){
                    this.toast('没有更多了');
                    return;
                }
                this.handleLoad();
                // console.log(this.totalProductList)
            },
            handleLoad: function() {
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        saleOrderStatus: this.saleOrderStatus
                    },
                    success: (data) => {
                        this.saleOrderProductList = data;
                        this.totalProductList = data.total
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleTab: function (status) {
                this.saleAction = status;
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/sale/order/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        saleOrderStatus: status
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.saleOrderProductList = data;
                    },
                    error: (data) => {
                        // this.toast(data.message);
                    }
                });
            },
            handleToDetail: function (saleOrderId) {
                this.push('/order/detail?saleOrderId=' + saleOrderId);
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        padding-bottom: 20px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .tab{
        width: 750px;
        height: 90px;
        flex-direction: row;
        flex-wrap: wrap;
        background-color: #ffffff;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        margin-bottom: 18px;
        position: sticky;
        left: 0px;
        top: 0px;
        z-index: 999;
    }
    .tab-list{
        width: 150px;
        text-align: center;
        padding-top: 26px;
        padding-right: 0px;
        padding-left: 0px;
        padding-bottom: 14px;
    }
    .tab-list-active{
        color: #e994a9;
        border-bottom-style: solid;
        border-bottom-width: 4px;
        border-bottom-color: #e994a9;
    }

    .order{
        width: 750px;
        padding-bottom: 20px;
    }
    .order-list{
        width: 750px;
        margin-bottom: 10px;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-width: 1px;
        border-top-color: #cccccc;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-hander{
        padding: 20px 10px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
        flex-direction: row;
        justify-content: center;
    }
    .order-list-hander-number{
        width: 630px;
        padding: 0px 16px;
    }
    .order-list-hander-number-text{
        text-align: left;
        white-space: nowrap
    }
    .order-list-hander-state{
        width: 120px;
        text-align: left;
        color: #999999;
    }
    .order-list-body{
        flex-direction: row;
        flex-wrap: wrap;
        padding: 10px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #cccccc;
    }
    .order-list-body-image{
        width: 150px;
        height: 150px;
        margin-right: 20px;
    }
    .order-list-body-info{
        flex: 1;
    }
    .order-list-body-info-title{
        margin-top: 20px;
        font-weight: bold;
    }
    .order-list-body-info-price{
        color: #999999;
    }
    .order-list-footer{
        padding: 20px 30px 20px 20px;
        text-align: right;
    }
    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

</style>
