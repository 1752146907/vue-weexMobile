
<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!-- 内容 -->

        <div class="content">
                <web style="width: 750px"
                     :style="{height: pageHeight + 'px'}"
                     v-if="isArticleOuterLink && articleOuterLink"
                     :src="articleOuterLink"></web>
                <web style="width: 750px"
                     :style="{height: pageHeight + 'px'}"
                     v-if="!isArticleOuterLink && articleId"
                     :src="'http://m.vpluslab.com/#/article/details/' + articleId + '?isApp=true'"></web>
        </div>
    </scroller>
</template>

<script>

    import Html from '../../component/html';

    import mixin from '../../common/mixin';

    export default {
        components: {
            Html
        },
        mixins: [mixin],
        data: () => ({
            articleId: '',
            articleContent: '',
            articleTitle: '',
            articleAuthor: '',
            articlePublishTime: '',
            isArticleOuterLink: false
        }),
        created() {

        },
        mounted() {
            let articleId = this.getParameter('articleId');
            if (articleId) {
                this.articleId = articleId;
            }
            let isArticleOuterLink = this.getParameter('isArticleOuterLink');
            let articleOuterLink = this.getParameter('articleOuterLink');
            if(isArticleOuterLink && articleOuterLink){
                this.isArticleOuterLink = isArticleOuterLink;
                this.articleOuterLink = decodeURIComponent(articleOuterLink);
            }
            this.changeTitle('动态详情');
        },
        methods: {

        }
    }
</script>

<style scoped>
    .content {
        width: 750px;
        padding-bottom: 20px;
    }
</style>