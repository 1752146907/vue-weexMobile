<template>
    <scroller class="container"
              @loadmore="handleLoadMore"
              loadmoreoffset="40"
              :style="{height: pageHeight + 'px'}">
        <div class="item-cell"
             v-for="(item, index) in articleList"
             :key="index"
             v-if="index <= showNumber">
            <div class="item-month">
                <div>
                    <text class="item-month-num">{{item.month}}</text>
                </div>
                <div>
                    <text class="item-month-txt">月</text>
                </div>
                <div>
                    <text class="item-month-year">{{item.year}}</text>
                </div>
            </div>

            <div @click="handleToDetail(item.articleId, item.articleIsOuterLink, item.articleOuterLink)">
                <div class="item-panel">
                    <image class="item-panel-img"
                           resize="cover"
                           :src="imageHost + item.articleImagePath"></image>
                </div>
                <text class="item-panel-text" lines="2">{{item.articleTitle}}</text>
            </div>
        </div>
        <!--<div class="header-box">-->
        <!--<text class="header-year" @click="handleBoxShow">{{year}}年</text>-->
        <!--<text class="header-month" @click="handleBoxShow">{{month}}月</text>-->
        <!--<image class="header-icon"-->
        <!--src="http://pic.51yuansu.com/pic3/cover/02/09/87/599ebadaf36a2_610.jpg"-->
        <!--@click="handleBoxShow"></image>-->
        <!--<div class="time-box-hide" v-if="boxShow">-->
        <!--<div class="time-box-header">-->
        <!--<text class="prev" @click="yearPrev">-->
        <!--<image class="prev-img"-->
        <!--src="http://pic.51yuansu.com/pic3/cover/02/09/87/599ebadaf36a2_610.jpg"-->
        <!--v-if="yearMonthList.length > 1 && showYearMonth.year != yearMonthList[yearMonthList.length - 1].year"></image>-->
        <!--</text>-->
        <!--<text class="content-year">{{showYearMonth.year}}</text>-->
        <!--<text class="next" @click="yearNext">-->
        <!--<image class="next-img"-->
        <!--src="http://pic.51yuansu.com/pic3/cover/02/09/87/599ebadaf36a2_610.jpg"-->
        <!--v-if="yearMonthList.length > 1 && showYearMonth.year != yearMonthList[0].year"></image>-->
        <!--</text>-->
        <!--</div>-->
        <!--<div class="month-box">-->
        <!--<text class="content-month"-->
        <!--v-for="(item , index) in showYearMonth.monthList"-->
        <!--:class="showYearMonth.year == year && item == month ? 'content-month-active' : 'content-month'"-->
        <!--@click="hanldeSelectYearMonth(showYearMonth.year, item)">{{item}}月</text>-->
        <!--</div>-->
        <!--</div>-->
        <!--</div>-->
    </scroller>


</template>

<script>
    import {WxcStepper, WxcLoading} from 'weex-ui'

    import mixin from '../../common/mixin';

    const modal = weex.requireModule('modal')

    export default {
        components: {
            WxcStepper,
            WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            boxShow: false,
            year: '',
            month: '',
            showIndex: 0,
            showYearMonth: '',
            yearMonthList: [],
            articleList: [],
            isArticleListShowAll: false,
            showNumber: 8,
            showDotDotDotText: "查看更多",
            lists: [1, 2, 3, 4, 5]
        }),
        mounted() {
            this.changeTitle('动态');
            // this.handleLoadYearAndMonthList();
            this.hanldeLoadArticle();
        },
        methods: {
            handleLoadMore() {
                if (this.showNumber >= this.articleList.length) {
                    return;
                } else {
                    this.showNumber = this.showNumber + 4
                }
            },
            handleLoadYearAndMonthList: function () {
                this.request({
                    url: '/xingxiao/article/desktop/v1/yearAndMonthlist',
                    data: {},
                    success: (data) => {
                        if (data && data.length > 0) {
                            this.yearMonthList = data;
                            var lastedYearMonth = this.yearMonthList[0];
                            this.year = lastedYearMonth.year;
                            this.month = lastedYearMonth.monthList[0];
                            this.showIndex = 0;
                        }
                    },
                    error: () => {

                    }
                });
            },
            handleBoxShow: function () {
                if (!this.boxShow) {
                    var year = this.year;
                    for (var i = 0; i < this.yearMonthList.length; i++) {
                        if (year == this.yearMonthList[i].year) {
                            this.showYearMonth = this.yearMonthList[i];
                            break;
                        }
                    }
                }
                this.boxShow = !this.boxShow;
            },
            yearPrev: function () {
                var year = this.showYearMonth.year;
                for (var i = 0; i < this.yearMonthList.length; i++) {
                    if (year == this.yearMonthList[i].year && i < (this.yearMonthList.length - 1)) {
                        this.showYearMonth = this.yearMonthList[i + 1];
                        break;
                    }
                }
            },
            yearNext: function () {
                var year = this.showYearMonth.year;
                for (var i = 0; i < this.yearMonthList.length; i++) {
                    if (year == this.yearMonthList[i].year && i > 0) {
                        this.showYearMonth = this.yearMonthList[i - 1];
                        break;
                    }
                }
            },
            hanldeSelectYearMonth: function (year, month) {
                this.year = year;
                this.month = month;

                this.hanldeLoadArticle();
            },
            hanldeLoadArticle: function () {
                this.request({
                    url: '/xingxiao/article/desktop/v1/storyList',
                    data: {
                        year: this.year,
                        month: this.month
                    },
                    success: (data) => {
                        if (data && data.length > 0) {
                            this.articleList = data;
                        }
                    },
                    error: () => {

                    }
                })
            },
            handleToDetail: function (articleId, articleIsOuterLink, articleOuterLink) {
                if (articleIsOuterLink == 1) {
                    this.push('/dynamic/detail?articleOuterLink=' + encodeURIComponent(articleOuterLink) + '&isArticleOuterLink=' + true)
                } else {
                    this.push('/dynamic/detail?articleId=' + articleId);
                }
            }
        }
    }
</script>

<style scoped>
    .panel {
        width: 600px;
        height: 250px;
        margin-left: 75px;
        margin-top: 35px;
        margin-bottom: 35px;
        flex-direction: column;
        justify-content: center;
        border-width: 2px;
        border-style: solid;
        border-color: rgb(162, 217, 192);
        background-color: rgba(162, 217, 192, 0.2);
    }

    .text {
        font-size: 50px;
        text-align: center;
        color: #41B883;
    }

    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        padding: 10px 40px 120px 40px;
    }

    .header-box {
        padding-top: 10px;
        flex-direction: row;
        position: relative;
    }

    .header-year {
        font-size: 40px;
        color: #686868;
    }

    .header-month {
        font-size: 40px;
        margin-left: 16px;
        color: #686868;
    }

    .header-icon {
        width: 32px;
        height: 20px;
        margin-top: 20px;
        margin-left: 8px;
        color: #686868;
    }

    .header-icon-180 {
        width: 36px;
        height: 24px;
        margin-top: 16px;
        margin-left: 8px;
        color: #686868;
        transform: rotate(180deg);
    }

    .time-box-hide {
        width: 328px;
        background-color: #ffffff;
        border-top-style: solid;
        border-top-color: #f996aa;
        border-top-width: 2px;
        position: absolute;
        top: 60px;
        left: 0px;
        border-bottom-left-radius: 6px;
        border-bottom-right-radius: 6px;
        box-shadow: 1px 1px 1px #e9e9e9;
    }

    .time-box-header {
        position: relative;
        height: 68px;
    }

    .prev {
        position: absolute;
        top: 10px;
        left: 8px;
    }

    .prev-img {
        width: 36px;
        height: 20px;
        margin-top: 12px;
        transform: rotate(90deg);
    }

    .next {
        position: absolute;
        right: 8px;
        top: 10px;
    }

    .next-img {
        width: 36px;
        height: 20px;
        margin-top: 12px;
        transform: rotate(270deg);
    }

    .content-year {
        font-size: 36px;
        position: absolute;
        top: 16px;
        left: 120px;
    }

    .month-box {
        flex-wrap: wrap;
        flex-direction: row;
        width: 328px;
    }

    .content-month-active {
        width: 72px;
        height: 72px;
        background-color: #f4a2b0;
        border-radius: 50%;
        display: inline-block;
        text-align: center;
        padding-top: 20px;
        margin-left: 8px;
        color: #ffffff;
        font-size: 24px;
    }

    .content-month {
        width: 72px;
        height: 72px;
        border-radius: 50%;
        display: inline-block;
        text-align: center;
        padding-top: 20px;
        margin-left: 8px;
        font-size: 24px;
    }

    .item-panel {
        flex-direction: column;
        justify-content: center;
        padding: 12px;
        background-color: #ffffff;
    }

    .item-panel-img {
        width: 500px;
        height: 396px;
        background-size: cover;
        background-position: 50%;
        background-repeat: no-repeat;
        overflow: hidden;
    }

    .item-panel-text {
        lines: 2;
        width: 528px;
        font-size: 28px;
        color: #010101;
        line-height: 40px;
        padding-top: 28px;
        font-weight: bold;
    }

    .item-cell {
        flex-direction: row;
        padding-top: 35px;
        padding-bottom: 35px;
    }

    .item-month {
        width: 130px;
        flex-direction: row;
        flex-wrap: wrap;
    }

    .item-month-num {
        font-size: 52px;
    }

    .item-month-txt {
        font-size: 24px;
        padding-top: 20px;
        margin-left: 4px;
    }

    .item-month-year {
        width: 100px;
        text-align: center;
        background-color: #f0a7af;
        color: #ffffff;
        font-size: 20px;
        border-radius: 4px;
        position: absolute;
        top: 80px;
        right: 0px;
    }

    .more {
        width: 750px;
        display: block;
        font-size: 30px;
        color: #686868;
        margin-bottom: 40px;
        text-align: center;
    }

</style>