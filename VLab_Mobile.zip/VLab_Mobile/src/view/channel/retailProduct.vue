<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<slider class="slider" interval="5000" auto-play="true" :index="0">
			<div class="slider-frame" v-for="(img, index) in productInfo.productImageList">
				<image class="slider-image" resize="cover" :src="imageHost + img.imagePath"></image>
				<text class="slider-index">{{index + 1}}/{{productInfo.productImageList.length}}</text>
			</div>
		</slider>

		<div class="nav-text">
			<text class="nav-text-title">{{productInfo.productTitle}}</text>
			<text class="nav-text-synopsis">{{productInfo.productSubtitle}}</text>
			<text class="nav-text-price">￥48.00</text>
		</div>

		<div class="purchase">
			<text class="purchase-title">购买配置</text>
			<div v-for="(product, index) in productInfo.productSkuPriceList"
				 @click="handleClickPurchase(product.productSkuId, index)"
				 v-bind:class="[seleSkuId == product.productSkuId && showSelectActive == true ? 'purchase-configuration-item-active':'purchase-configuration-item']"
			>
				<text class="purchase-configuration-item-text"
					  v-bind:class="[seleSkuId == product.productSkuId && showSelectActive == true  ? 'purchase-configuration-item-text-active' : '']"
				>{{product.compositeAttributeKey}}
				</text>
				<text class="purchase-configuration-item-price"
					  v-bind:class="[seleSkuId == product.productSkuId && showSelectActive == true  ? 'purchase-configuration-item-price-active' : '']"
				>￥{{product.productSkuPrice}}.00
				</text>
			</div>
			<div class="purchase-modules">
				<text class="purchase-modules-title">购买数量</text>
				<wxc-stepper class="purchase-modules-stepper"
							 :default-value="productNumber"
							 step="1"
							 :max="productQuantity.max"
							 @wxcStepperValueChanged="wxcStepperValueChanged"
							 min="1"></wxc-stepper>
			</div>
		</div>
		<div class="product-detail" v-if="productInfo">
			<Html :inner="productInfo.productMobileDetail"
				  :globalEvent="globalEvent"
				  :chuangshi="chuangshi"
				  :platform="platform"></Html>
			<!--<web style="width: 750px"-->
				 <!--:style="{height: pageHeight + 'px'}"-->
				 <!--src="http://m.vpluslab.com/#/app/index"></web>-->
		</div>

		<div class="footer">
			<div class="footer-total">
				<div class="footer-total-text">
					<text class="footer-total-text-selected-number">已选：{{productNumber}} 个</text>
					<text class="footer-total-text-total-amount">总金额: ￥{{sumPrice}}</text>
				</div>
				<div class="footer-pay" @click="handleToOrder">
					<text class="footer-pay-text">立即购买</text>
				</div>
			</div>
		</div>
	</scroller>

</template>

<script>
	import {WxcStepper, WxcLoading} from 'weex-ui';
	import Html from '../../component/html';

	import mixin from '../../common/mixin';

	export default {
		components: {
			WxcStepper,
			WxcLoading,
			Html
		},
		mixins: [mixin],
		data: () => ({
            productId: '',
            productQuantity: {
                quantity: 1,
                min: 1,
                max: 100
            },
			productNumber: 1,
			productInfo: '',
			isLoad: false,
			productTotal: 0,
			seleSkuId: '',
			sumPrice: '48.00',
			showSelectActive: true
		}),
		mounted () {
            this.changeTitle('商品详情');
		    if(this.getParameter('productId')){
                this.productId = this.getParameter('productId');
                if(this.productId == '1035421817968144386'){
                    this.productQuantity = {
                        quantity: 1,
                        min: 1,
                        max: 10
                    }
				}
			}

			this.haneleLoad();

			if (this.platform != 'web') {
				// this.globalEvent.addEventListener('getWeiXinAuth', (data) => {
                 //    // this.toast(data.code)
                 //    this.handleGetUserInfo(data.code);
				// });

				this.globalEvent.addEventListener('getWeiXinPaySuccess', (data) => {
					console.log('getWeiXinPaySuccess')
				});

				this.globalEvent.addEventListener('getWeiXinPayCancel', (data) => {
					console.log('getWeiXinPayCancel')
				});

				this.globalEvent.addEventListener('getWeiXinPayFail', (data) => {
					console.log('getWeiXinPayFail')
				});

				this.globalEvent.addEventListener('getAliPaySuccess', (data) => {
					console.log('getAliPaySuccess')
				});

				this.globalEvent.addEventListener('getAliPayFail', (data) => {
					console.log('getAliPayFail')
				});
			}
		},
		methods: {
			haneleLoad () {
				this.request({
					url: '/xingxiao/product/mobile/v1/view',
					data: {
                        productId: this.productId
					},
					success: (data) => {
						this.productInfo = data;
						this.seleSkuId = data.productSkuPriceList[0].productSkuId;
					},
					error: () => {
						this.isLoad = false;
					}
				});
			},
			wxcStepperValueChanged (e) {
				var number = e.value;
				this.showSelectActive = true;
				if(this.productId == '1002483230350774273') {
                    if (number >= 1 && number < 10) {
                        this.seleSkuId = this.productInfo.productSkuPriceList[0].productSkuId;
                        this.sumPrice = (this.productInfo.productSkuPriceList[0].productSkuPrice * number).toFixed(2);
                        if (number != 1) {
                            this.showSelectActive = false;
                        }
                    } else if (number >= 10 && number < 100) {
                        this.seleSkuId = this.productInfo.productSkuPriceList[1].productSkuId;
                        this.sumPrice = ((this.productInfo.productSkuPriceList[1].productSkuPrice / 10) * number).toFixed(2)
                        if (number != 10) {
                            this.showSelectActive = false;
                        }
                    } else if (number == 100) {
                        this.seleSkuId = this.productInfo.productSkuPriceList[2].productSkuId;
                        this.sumPrice = this.productInfo.productSkuPriceList[2].productSkuPrice.toFixed(2);
                    }
				} else {
				    if (number > 10) {
                        this.productNumber = 10;
                        this.seleSkuId = this.productInfo.productSkuPriceList[2].productSkuId;
                        this.sumPrice = this.productInfo.productSkuPriceList[2].productSkuPrice.toFixed(2);
                        return;
					}
                    if (number >= 1 && number < 3) {
                        this.seleSkuId = this.productInfo.productSkuPriceList[0].productSkuId;
                        this.sumPrice = (this.productInfo.productSkuPriceList[0].productSkuPrice * number).toFixed(2);
                        if (number != 1) {
                            this.showSelectActive = false;
                        }
                    } else if (number >= 3 && number < 10) {
                        this.seleSkuId = this.productInfo.productSkuPriceList[1].productSkuId;
                        this.sumPrice = ((this.productInfo.productSkuPriceList[1].productSkuPrice / 3) * number).toFixed(2)
                        if (number != 3) {
                            this.showSelectActive = false;
                        }
                    } else if (number == 10) {
                        this.seleSkuId = this.productInfo.productSkuPriceList[2].productSkuId;
                        this.sumPrice = this.productInfo.productSkuPriceList[2].productSkuPrice.toFixed(2);
                    }
				}
				this.productNumber = number;
			},
			handleClickPurchase (id, index) {
				this.seleSkuId = id;
				this.showSelectActive = true;
				var number = this.number > 1 ? this.number : 1;
                if(this.productId == '1002483230350774273'){
                    for (let i = 0; i < this.productInfo.productSkuPriceList.length; i++) {
                        if (this.productInfo.productSkuPriceList[i].productSkuId === id) {
                            this.seleSkuId = id;
                            if (id == this.productInfo.productSkuPriceList[i].productSkuId) {
                                if (i === 0 && number <= 10) {
                                    this.productNumber = 1;
                                } else if (i === 1 && (number <= 10 || number === 100)) {
                                    this.productNumber = 10;
                                } else if (i === 2 && number < 100) {
                                    this.productNumber = 100;
                                }
                                this.sumPrice = this.productInfo.productSkuPriceList[i].productSkuPrice.toFixed(2);
                                return;
                            }
                        }
                    }
				} else{
                    for (let i = 0; i < this.productInfo.productSkuPriceList.length; i++) {
                        if (this.productInfo.productSkuPriceList[i].productSkuId === id) {
                            this.seleSkuId = id;
                            if (id == this.productInfo.productSkuPriceList[i].productSkuId) {
                                if (i === 0 && number <= 3) {
                                    this.productNumber = 1;
                                } else if (i === 1 && (number <= 3 || number === 10)) {
                                    this.productNumber = 3;
                                } else if (i === 2 && number < 10) {
                                    this.productNumber = 10;
                                }
                                this.sumPrice = this.productInfo.productSkuPriceList[i].productSkuPrice.toFixed(2);
                                return;
                            }
                        }
                    }
				}
			},
			handleToOrder () {
                this.handleIsLogin({
					success: () => {
                        this.isLoad = true;
                        var seleOrderProductList = JSON.stringify([
                            {
                                productId: this.productInfo.productId,
                                productImagePath: this.productInfo.productImageList[0].imagePath,
                                productQuantity: this.productQuantity.quantity,
                                productSkuId: this.seleSkuId,
                                productTitle: this.productInfo.productTitle,
                            }
                        ]);
                        this.storage.setItem("saleOrderProductList", seleOrderProductList)
                        this.push('/order/retailCheck?totalAmount=' + this.sumPrice);
					},
					fail: () => {

					}
				});
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		padding-bottom: 60px;
	}

	.slider {
		width: 750px;
		height: 750px;
	}

	.slider-image {
		width: 750px;
		height: 750px;
	}

	.slider-frame {
		width: 750px;
		height: 750px;
		position: relative;
	}

	.slider-index {
		right: 20px;
		bottom: 20px;
		color: #e994a9;
		position: absolute
	}

	.nav-text {
		width: 750px;
		padding: 20px;
		background-color: #ffffff;
		border-top-color: #D9D9D9;
		border-top-width: 1px;
		border-bottom-color: #D9D9D9;
		border-bottom-width: 1px;
	}

	.nav-text-title {
		font-size: 32px;
		font-weight: bold;
	}

	.nav-text-synopsis {
		font-size: 28px;
		color: #4B4B4B;
		line-height: 53px;
	}

	.nav-text-price {
		font-size: 30px;
		color: #e994a9;
		font-weight: bold;
	}

	.purchase {
		width: 750px;
		padding: 20px;
		background-color: #ffffff;
		border-top-color: #D9D9D9;
		border-top-width: 1px;
		border-bottom-color: #D9D9D9;
		border-bottom-width: 1px;
		margin-top: 10px;
		margin-bottom: 10px;
	}

	.purchase-title {
		font-size: 32px;
	}

	.purchase-configuration-item {
		width: 700px;
		height: 68px;
		border-left-color: #4B4B4B;
		border-left-width: 1px;
		border-right-color: #4B4B4B;
		border-right-width: 1px;
		border-top-color: #4B4B4B;
		border-top-width: 1px;
		border-bottom-color: #4B4B4B;
		border-bottom-width: 1px;
		margin-top: 15px;
		padding: 12px 15px 0px 15px;
		background-color: #ffffff;
		border-bottom-left-radius: 10px;
		border-bottom-right-radius: 10px;
		border-top-left-radius: 10px;
		border-top-right-radius: 10px;
		flex-direction: row;
		flex-wrap: wrap;
	}

	.purchase-configuration-item-active {
		width: 700px;
		height: 68px;
		border-left-color: #e994a9;
		border-left-width: 1px;
		border-right-color: #e994a9;
		border-right-width: 1px;
		border-top-color: #e994a9;
		border-top-width: 1px;
		border-bottom-color: #e994a9;
		border-bottom-width: 1px;
		margin-top: 15px;
		padding: 12px 15px 0px 15px;
		background-color: #ffffff;
		border-bottom-left-radius: 10px;
		border-bottom-right-radius: 10px;
		border-top-left-radius: 10px;
		border-top-right-radius: 10px;
		flex-direction: row;
		flex-wrap: wrap;
	}

	.purchase-configuration-item-text-active {
		color: #e994a9;
	}

	.purchase-configuration-item-price-active {
		color: #e994a9;
	}

	.purchase-configuration-item-text {
		width: 490px;
		color: #4B4B4B;
		font-size: 28px;
	}

	.purchase-configuration-item-price {
		width: 150px;
		color: #4B4B4B;
		font-size: 28px;
	}

	.purchase-modules {
		margin-top: 40px;
		padding-top: 20px;
		border-top-color: #bbbbc0;
		border-top-width: 1px;
		border-top-style: solid;
		flex-direction: row;
		flex-wrap: wrap;
	}

	.purchase-modules-title {
		width: 500px;
	}

	.purchase-modules-stepper {
		width: 210px;
	}

	.product-detail {
		width: 750px;
		margin-top: 10px;
		margin-bottom: 80px;
	}

	.footer {
		width: 750px;
		height: 96px;
		position: fixed;
		bottom: 0px;
		left: 0px;
		right: 0px;
		background-color: #ffffff;
		border-top-color: #d9d9d9;
		border-top-width: 1px;
	}

	.footer-total {
		height: 90px;
		background-color: #fff;
		flex-direction: row
	}

	.footer-total-text {
		width: 530px;
		font-size: 22px;
		padding-top: 10px;
		padding-left: 10px;
		box-sizing: border-box;
	}

	.footer-total-text-selected-number {
		font-size: 26px;
	}

	.footer-total-text-total-amount {
		font-size: 28px;
	}

	.footer-pay {
		width: 220px;
		height: 96px;
	}

	.footer-pay-text {
		line-height: 96px;
		font-size: 32px;
		color: #fff;
		text-align: center;
		background-color: #e994a9;
	}
</style>