<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">

        <Product></Product>

    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';
    import Product from "../product/index";

    import mixin from '../../common/mixin';

    export default {
        components: {
            Product,
            WxcCell
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            activeIndex: 0,
        }),

        created () {

        },
        mounted () {
            this.changeTitle('商品详情');
        },
        methods: {

        }
    }
</script>

<style scoped>

</style>
