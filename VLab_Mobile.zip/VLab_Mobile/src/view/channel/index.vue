<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<div class="header">
			<div class="header-menu">
				<div class="header-menu-item" @click="handleAgent">
					<text class="header-menu-item-text"
						  :class="[itemIndex == 0 ? 'header-menu-item-text-active' : 'header-menu-item-text']">我的代理</text>
				</div>
				<div class="header-menu-item-share" @click="handlePurchase">
					<text class="header-menu-item-text"
						  :class="[itemIndex == 1 ? 'header-menu-item-text-active' : 'header-menu-item-text']">我要进货</text>
				</div>
			</div>
		</div>

		<div class="content">
			<teamDetail v-if="itemIndex == 0"></teamDetail>

			<div v-if="itemIndex == 1">
				<wxc-cell class="cell"
						  :has-top-border="true"
						  :has-arrow="true"
						  v-for="(item, index) in productList"
						  :key="index"
						  @wxcCellClicked="handleProduct(item.productId)"
						  :has-margin="false">
					<image class="cell-img"
						   :src="imageHost + item.productImagePath"
						   slot="label"></image>
					<div class="cell-title" slot="title">{{item.productTitle}}</div>
				</wxc-cell>
			</div>

			<div class="no-data" v-if="itemIndex == 0 && !isNoLogin">
				<image class="no-data-img"
					   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
				<text class="no-data-text">当前没有数据</text>
			</div>
		</div>


	</scroller>

</template>

<script>
	import {WxcStepper, WxcLoading, WxcMinibar, WxcCell} from 'weex-ui';
    import teamDetail from '../my/team/detail';

	import mixin from '../../common/mixin';

	export default {
		components: {
            WxcCell,
            WxcMinibar,
			WxcStepper,
			WxcLoading,
            teamDetail
		},
		mixins: [mixin],
		data: () => ({
            itemIndex: 0,
			isLoad: false,
            productList: []
		}),
        props: {
            activeIndex: {
                type: String,
                required: true
            },
            isNoLogin: {
                type: Boolean,
                required: true
			}
        },
		mounted () {
			this.haneleLoad();
            this.globalEvent.addEventListener('handleChanner', (data) => {
                this.haneleLoad();
			});
			console.log(this.storage.setItem(this.token, '131d47c6810f45053a63241b8955d02ff698536bdc02572a39e1704007d076b5e5bb3f5f3919ac7af788eccb709a8e969d81b8c27ccd76d9c2ffb118f63da824f8b0aafbd83089ac67e2053a49df0205e5e1926df01294614c3251dfe3405464'));
		},
		methods: {
            haneleLoad() {
                this.request({
                    url: '/xingxiao/product/mobile/v1/purchase/list',
                    data: {

                    },
                    success: (data) => {
                        this.productList = data;
                    }
                });
            },
            handleProduct (productId) {
                // this.push('/channel/retailProduct?productId=' + productId);
                this.push('/channel/product?productId=' + productId);
                // switch(index) {
				// 	case 1:
				// 		this.push('/channel/product?productId=1002483230350774273');
				// 		break;
				// 	default:
                 //        this.push('/channel/product?productId=1035421817968144386');
				// }
			},
            handleAgent () {
                this.itemIndex = 0;
			},
            handlePurchase () {
                this.itemIndex = 1;
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		padding-bottom: 130px;
	}
	
	.header {
		width: 750px;
		height: 100px;
		align-items: center;
		border-bottom-width: 1px;
		border-bottom-color: #D8D8D8;
		background-color: #ffffff;
	}
	.header-menu {
		width: 750px;
		height: 100px;
		flex-direction: row;
		align-items: center;
		justify-content: center;
	}
	.header-menu-item {
		width: 325px;
		height: 100px;
		align-items: center;
		justify-content: center;
		border-right-style: solid;
		border-right-width: 2px;
		border-right-color: #ffffff;
	}
	.header-menu-item-share {
		width: 325px;
		height: 100px;
		align-items: center;
		justify-content: center;
	}
	.header-menu-item-text {
		font-family: PingFangSC-Regular;
		font-size: 32px;
		color: #000000;
		padding: 8px;
	}
	.header-menu-item-text-active {
		align-items: center;
		justify-content: center;
		font-family: PingFangSC-Regular;
		font-size: 32px;
		color: #e994a9;
		padding: 8px;
		border-bottom-color: #e994a9;
		border-bottom-width: 2px;
	}
	.content{
		padding-bottom: 20px;
	}
	.cell {
		width: 750px;
		margin-top: 20px;
	}
	.cell-img {
		width: 80px;
		height: 80px;
	}
	.cell-title {
		margin-left: 40px;
	}

	.no-data {
		position: absolute;
		top: 400px;
		left: 315px;
		width: 200px;
		height: 200px;
	}
	.no-data-img {
		width: 120px;
		height: 120px;
	}
	.no-data-text {
		margin-top: 20px;
		margin-left: -32px;
		width: 220px;
		height: 40px;
		color: #888;
		font-size: 32px;
	}

</style>