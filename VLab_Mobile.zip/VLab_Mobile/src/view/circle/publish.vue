<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <div class="container">
            <div class="commuity">
                <div class="community-box">
                    <div class="commuity-publish-header">
                        <div @click="handleSublime">
                            <text class="commuity-publish-header-sublime">发表</text>
                        </div>
                    </div>
                    <div class="commuity-publish-body">
                        <textarea class="textarea"
                                  placeholder="此刻的想法..."
                                  max-length="10"
                                  v-model="topicContent"></textarea>
                    </div>
                </div>
            </div>
            <div class="upload">
                <div class="upload-item"
                     v-for="(item, index) in topicImageList"
                     :key="index">
                    <image class="upload-item-image"
                           resize="cover"
                           @click="handleOpenImageLigh(topicImageList, index)"
                           :src="imageHost + item.imagePath"></image>
                    <image class="upload-item-image-close"
                           @click="handleDelImage(item.imageId)"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/close.png"></image>
                </div>
                <!--<div class="upload-item">-->
                    <!--<image class="upload-item-image"-->
                           <!--resize="cover"-->
                           <!--src="http://pic.fayi.com.cn/Upload/origin/123/62123.jpg"></image>-->
                    <!--<image class="upload-item-image-close"-->
                           <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/close.png"></image>-->
                <!--</div>-->
                <div class="upload-item"
                     v-if="topicImageList.length <= 8"
                     @click="handleClickAddImage">
                    <text class="upload-item-add">+</text>
                </div>
            </div>
            <!--<wxc-cell class="location"-->
                      <!--:has-top-border="true"-->
                      <!--:has-arrow="true"-->
                      <!--@wxcCellClicked="handleOpenLocation">-->
                <!--<image class="location-img"-->
                       <!--src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/my-05-icon.png"-->
                       <!--slot="label"></image>-->
                <!--<div class="location-title" slot="title">所在位置</div>-->
            <!--</wxc-cell>-->
        </div>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>

</template>

<script>
    import {WxcStepper, WxcLoading, WxcCell} from 'weex-ui';
    import Html from '../../component/html';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcStepper,
            WxcLoading,
            Html
        },
        mixins: [mixin],
        data: () => ({
            isLoad: false,
            topicContent: '',
            topicImageList: [],
            topicLatitude: '',
            topicLongtitude: '',
            topicLocation: ''
        }),
        props: {
            activeIndex: {
                type: String,
                required: true
            }
        },
        mounted() {
            this.changeTitle('圈子主页');
            this.handleListenerPickImageEvent();
        },
        methods: {
            handleOpenImageLigh(imagePath, index) {
                this.showImageList = [];
                for (var a = 0; a < imagePath.length; a++){
                    var showImageList = {};
                    showImageList = this.imageHost + imagePath[a].imagePath
                    this.showImageList.push(showImageList);
                }

                if (this.platform != 'web') {
                    this.chuangshi.openImageBrowser({
                        list: this.showImageList,
                        pageIndex: index
                    });
                }

            },
            handleClickAddImage () {
                this.chuangshi.openPhoto("publish-image");
            },
            handleListenerPickImageEvent () {
                this.globalEvent.addEventListener('publish-image', function (data) {
                    let action = data.action;   //事件名称
                    let base64Data = encodeURI(data.base64);

                    this.isLoad = true;

                    this.request({
                        url: this.imageHost + '/file/file/mobile/v1/image/base64/upload',
                        data: {
                            base64String: base64Data
                        },
                        success: (data) => {
                            this.isLoad = false;

                            switch (action) {
                                case 'publish-image':
                                    // this.topicImageList.push(data.fileId);
                                    // this.topicImageList.push(this.imageHost + data.fileOriginalPath);
                                    var topicImageListArr = {imageId: data.fileId, imagePath: data.fileOriginalPath}
                                    this.topicImageList.push(topicImageListArr)
                                    this.toast("上传成功");
                                    break;

                                default :
                                    break;
                            }
                        },
                        error: () => {
                            this.isLoad = false;
                        },
                        complete: () => {

                        }
                    });
                }.bind(this));
            },
            handleDelImage: function (id) {
                this.isLoad = true;
                for (let i = 0; i < this.topicImageList.length; i++) {
                    if(id == this.topicImageList[i].imageId) {
                        this.topicImageList.splice(i, 1);
                        this.isLoad = false;
                    }
                }
            },
            handleSublime: function () {
                if(this.topicContent.length > 1000) {
                    this.toast('文本长度不能超过1000');
                    return
                }
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/mobile/v1/save',
                    data: {
                        topicContent: this.topicContent,
                        topicImageList: this.topicImageList,
                        topicLatitude: this.topicLatitude,
                        topicLongtitude: this.topicLongtitude,
                        topicLocation: this.topicLocation
                    },
                    success: () => {
                        this.chuangshi.sendEventListener({    //触发事件监听
                            name: 'publishSuccess',
                            data: {    }
                        });

                        this.isLoad = false;
                        this.toast('发表成功');
                        this.pop();
                    }
                });
            },
            handleOpenLocation: function () {
                this.chuangshi.openLocation();
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        padding-bottom: 20px;
    }

    .textarea {
        width: 730px;
        height: 200px;
        margin-top: 10px;
        margin-left: 10px;
        padding-top: 10px;
        padding-bottom: 10px;
        padding-left: 10px;
        padding-right: 10px;
        color: #666666;
        font-size: 32px;
    }

    .commuity-publish-body{
        width: 750px;
        border-top-width: 1px;
        border-top-color: #cccccc;
    }
    .commuity-publish-header{
        padding: 20px;
        height: 102px;
        position: relative;
    }
    .commuity-publish-header-sublime{
        width: 162px;
        height: 62px;
        line-height: 62px;
        color: #ffffff;
        text-align: center;
        border-radius: 10px;
        background-color: #e994a9;
        position: absolute;
        right: 10px;
        font-size: 32px;
    }
    .upload{
        width: 750px;
        border-top-width: 1px;
        border-top-color: #cccccc;
        margin-top: 20px;
        padding: 30px 20px 20px 20px;
        flex-direction: row;
        flex-wrap: wrap;
    }
    .upload-item{
        width: 160px;
        height: 160px;
        margin-right: 14px;
        margin-bottom: 14px;
        border-width: 1px;
        border-color: #cccccc;
        position: relative;
    }
    .upload-item-image{
        width: 160px;
        height: 160px;
    }
    .upload-item-image-close{
        width: 40px;
        height: 40px;
        position: absolute;
        top: 0px;
        right: -2px;
    }
    .upload-item-add{
        color: #cccccc;
        justify-content: center;
        box-sizing: border-box;
        padding-top: 30px;
        padding-left: 54px;
        font-size: 68px;
    }
    .location {
        width: 750px;
        margin-top: 80px;
    }
    .location-img {
        width: 40px;
        height: 40px;
    }
    .location-title {
        margin-left: 30px;
        color: #666666;
    }

</style>