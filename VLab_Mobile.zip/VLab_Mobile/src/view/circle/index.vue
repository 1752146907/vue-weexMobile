<template>
    <scroller class="container"
              @loadmore="handleLoadMore"
              loadmoreoffset="940"
              @touchend="windowScrool"
              offset-accuracy="10"
              :style="{height: pageHeight + 'px'}">
        <div class="container">
            <div class="no-data"
                 v-if="topicList.length == 0 && loadSuccess">
                <image class="no-data-img"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
                <text class="no-data-text">当前没有数据</text>
            </div>
            <div class="community-box"
                 v-if="topicList.length > 0">
                <!--<div class="community-header"-->
                     <!--@click="handleSlef">-->
                    <!--<image class="community-header-background"-->
                           <!--resize="cover"-->
                           <!--src='http://pic.fayi.com.cn/Upload/origin/123/62123.jpg'></image>-->
                    <!--<text class="community-header-name">军师诸葛亮</text>-->
                    <!--<image class="community-header-author"-->
                           <!--src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=264028261,222908825&fm=23&gp=0.jpg"></image>-->
                <!--</div>-->
                <div class="community-main">
                    <div v-for="topic in topicList">
                        <div class="community-main-item"
                             v-if="topic.topicImageList.length == 0">
                            <image class="community-main-item-author"
                                   resize="cover"
                                   @click="handleToHomePage(topic.memberId, topic.topicId)"
                                   :src='imageHost + topic.memberAvatarPath'></image>
                            <div class="community-main-item-content">
                                <text class="community-main-item-content-author-name"
                                      @click="handleToHomePage(topic.memberId, topic.topicId)">{{topic.memberNickName}}</text>
                                <text class="community-main-item-content-moment-content"
                                      lines="3"
                                      @click="handleToCircleDetail(topic.topicId)">{{topic.topicContent}}</text>
                                <text class="location">{{topic.topicLocation}}</text>
                                <div class="community-main-item-content-card-moment-info">
                                    <text class="community-main-item-content-card-moment-info-time">{{topic.systemCreateTime}}</text>
                                    <text class="community-main-item-content-card-moment-info-delete"
                                          v-if="getMemberId == topic.memberId"
                                          @click="haneleDeleteTopic(topic.topicId)">删除</text>
                                    <div class="community-main-item-content-card-moment-info-feedbac">
                                        <div class="community-main-item-content-card-moment-info-feedbac-item"
                                             v-if="showTopicEvaluate == topic.topicId">
                                            <div class="community-main-item-content-card-moment-info-feedbac-item-box">
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-xin"
                                                       v-if="topic.memberIsLike"
                                                       @click="handleDelGood(topic.topicId)"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-xin"
                                                       v-if="!topic.memberIsLike"
                                                       @click="handleGood(topic.topicId)"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
                                                      v-if="topic.memberIsLike"
                                                      @click="handleDelGood(topic.topicId)">取消</text>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
                                                      v-if="!topic.memberIsLike"
                                                      @click="handleGood(topic.topicId)">点赞</text>
                                            </div>
                                            <text class="community-main-item-content-card-moment-info-feedbac-item-line">|</text>
                                            <div class="community-main-item-content-card-moment-info-feedbac-item-box"
                                                 @click="handleEvaluate(topic.topicId)">
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-pinjia"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/pinjia.png"></image>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-evaluate">评价</text>
                                            </div>
                                        </div>
                                        <image class="community-main-item-content-card-moment-info-feedbac-image"
                                               @click="handleDotDotDot(topic.topicId)"
                                               src='https://gw.alicdn.com/tfs/TB1_POLc3MPMeJjy1XcXXXpppXa-66-46.png'></image>
                                    </div>
                                </div>
                                <image class="community-main-item-content-moment-arrow"
                                       v-if="topic.topicLikeList.length > 0 || topic.topicCommentList.length > 0"
                                       src="https://gw.alicdn.com/tfs/TB1F0OLc3oQMeJjy0FnXXb8gFXa-30-12.png"></image>
                                <div class="community-main-item-content-moment-likes"
                                     :class="[topic.topicCommentList.length > 0 ? 'community-main-item-content-moment-likes-bottom-line' : '']"
                                     v-if="topic.topicLikeList.length > 0">
                                    <text class="community-main-item-content-moment-likes-good">♡</text>
                                    <text class="community-main-item-content-moment-likes-list link-text"
                                          v-for="(like, index) in topic.topicLikeList"
                                          :key="like.memberId"
                                          @click="handleOrterPage(like.memberId)">{{like.memberNickName}} <text class="community-main-item-content-moment-likes-list-line"
                                                                                                                v-if="index != topic.topicLikeList.length-1">，</text></text>
                                </div>
                                <text class="community-main-item-content-comment-list"
                                      @click="handleReply(comment.memberId, comment.topicCommentId, topic.topicId, comment.memberNickName)"
                                      v-for="(comment, index) in topic.topicCommentList"
                                      :key="index"
                                      :class="[index == '0' ? 'community-main-item-content-comment-list-one' : '']"
                                      v-if="topic.topicCommentList.length > 0">{{comment.memberNickName}}{{comment.replyMemberNickName ? ' 回复 ' + comment.replyMemberNickName : ''}}：{{comment.topicCommentContent}}</text>
                            </div>
                        </div>
                        <div class="community-main-item"
                             v-if="topic.topicImageList.length == 1">
                            <image class="community-main-item-author"
                                   resize="cover"
                                   @click="handleToHomePage(topic.memberId, topic.topicId)"
                                   :src='imageHost + topic.memberAvatarPath'></image>
                            <div class="community-main-item-content">
                                <text class="community-main-item-content-author-name" @click="handleToHomePage(topic.memberId, topic.topicId)">{{topic.memberNickName}}</text>
                                <text class="community-main-item-content-moment-content"
                                      lines="3"
                                      @click="handleToCircleDetail(topic.topicId)">{{topic.topicContent}}</text>
                                <image class="community-main-item-content-card-picture"
                                       resize="cover"
                                       v-for="(imageList, index) in topic.topicImageList"
                                       :key="imageList.imageId"
                                       @click="handleOpenImageLigh(topic.topicImageList, index)"
                                       :src='imageHost + imageList.imagePath'></image>
                                <text class="location margin-top-10">{{topic.topicLocation}}</text>
                                <div class="community-main-item-content-card-moment-info">
                                    <text class="community-main-item-content-card-moment-info-time">{{topic.systemCreateTime}}</text>
                                    <text class="community-main-item-content-card-moment-info-delete"
                                          v-if="getMemberId == topic.memberId"
                                          @click="haneleDeleteTopic(topic.topicId)">删除</text>
                                    <div class="community-main-item-content-card-moment-info-feedbac">
                                        <div class="community-main-item-content-card-moment-info-feedbac-item"
                                             v-if="showTopicEvaluate == topic.topicId">
                                            <div class="community-main-item-content-card-moment-info-feedbac-item-box">
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-xin"
                                                       v-if="topic.memberIsLike"
                                                       @click="handleDelGood(topic.topicId)"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-xin"
                                                       v-if="!topic.memberIsLike"
                                                       @click="handleGood(topic.topicId)"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
                                                      v-if="topic.memberIsLike"
                                                      @click="handleDelGood(topic.topicId)">取消</text>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
                                                      v-if="!topic.memberIsLike"
                                                      @click="handleGood(topic.topicId)">点赞</text>
                                            </div>
                                            <text class="community-main-item-content-card-moment-info-feedbac-item-line">|</text>
                                            <div class="community-main-item-content-card-moment-info-feedbac-item-box"
                                                 @click="handleEvaluate(topic.topicId)">
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-pinjia"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/pinjia.png"></image>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-evaluate">评价</text>
                                            </div>
                                        </div>
                                        <image class="community-main-item-content-card-moment-info-feedbac-image"
                                               @click="handleDotDotDot(topic.topicId)"
                                               src='https://gw.alicdn.com/tfs/TB1_POLc3MPMeJjy1XcXXXpppXa-66-46.png'></image>
                                    </div>
                                </div>
                                <image class="community-main-item-content-moment-arrow"
                                       src="https://gw.alicdn.com/tfs/TB1F0OLc3oQMeJjy0FnXXb8gFXa-30-12.png"
                                       v-if="topic.topicLikeList.length > 0 || topic.topicCommentList.length > 0"></image>
                                <div class="community-main-item-content-moment-likes"
                                     :class="[topic.topicCommentList.length > 0 ? 'community-main-item-content-moment-likes-bottom-line' : '']"
                                     v-if="topic.topicLikeList.length > 0">
                                    <text class="community-main-item-content-moment-likes-good">♡</text>
                                    <text class="community-main-item-content-moment-likes-list link-text"
                                          v-for="(like, index) in topic.topicLikeList"
                                          :key="like.memberId"
                                          @click="handleOrterPage(like.memberId)">{{like.memberNickName}} <text class="community-main-item-content-moment-likes-list-line"
                                                                                                                v-if="index != topic.topicLikeList.length-1">，</text></text>
                                </div>
                                <text class="community-main-item-content-comment-list"
                                      v-for="(comment, index) in topic.topicCommentList"
                                      :key="index"
                                      :class="[index == '0' ? 'community-main-item-content-comment-list-one' : '']"
                                      @click="handleReply(comment.memberId, comment.topicCommentId, topic.topicId, comment.memberNickName)"
                                      v-if="topic.topicCommentList.length > 0">{{comment.memberNickName}}{{comment.replyMemberNickName ? ' 回复 ' + comment.replyMemberNickName : ''}}：{{comment.topicCommentContent}}</text>
                            </div>
                        </div>
                        <div class="community-main-item"
                             v-if="topic.topicImageList.length > 1">
                            <image class="community-main-item-author"
                                   resize="cover"
                                   @click="handleToHomePage(topic.memberId, topic.topicId)"
                                   :src='imageHost + topic.memberAvatarPath'></image>
                            <div class="community-main-item-content">
                                <text class="community-main-item-content-author-name"
                                      @click="handleToHomePage(topic.memberId, topic.topicId)">{{topic.memberNickName}}</text>
                                <text class="community-main-item-content-moment-content"
                                      lines="3"
                                      @click="handleToCircleDetail(topic.topicId)">{{topic.topicContent}}</text>
                                <div class="community-main-item-content-moment-many-pictures">
                                    <image resize="cover"
                                           @click="handleOpenImageLigh(topic.topicImageList, index)"
                                           class="community-main-item-content-moment-many-pictures-image"
                                           v-for="(imageList, index) in topic.topicImageList"
                                           :key="imageList.imageId"
                                           :src='imageHost + imageList.imagePath'>
                                    </image>
                                </div>
                                <text class="location margin-top-10">{{topic.topicLocation}}</text>
                                <div class="community-main-item-content-card-moment-info">
                                    <text class="community-main-item-content-card-moment-info-time">{{topic.systemCreateTime}}</text>
                                    <text class="community-main-item-content-card-moment-info-delete"
                                          v-if="getMemberId == topic.memberId"
                                          @click="haneleDeleteTopic(topic.topicId)">删除</text>
                                    <div class="community-main-item-content-card-moment-info-feedbac">
                                        <div class="community-main-item-content-card-moment-info-feedbac-item"
                                             v-if="showTopicEvaluate == topic.topicId">
                                            <div class="community-main-item-content-card-moment-info-feedbac-item-box">
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-xin"
                                                       v-if="topic.memberIsLike"
                                                       @click="handleDelGood(topic.topicId)"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-xin"
                                                       v-if="!topic.memberIsLike"
                                                       @click="handleGood(topic.topicId)"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/xin.png"></image>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
                                                      v-if="topic.memberIsLike"
                                                      @click="handleDelGood(topic.topicId)">取消</text>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-fabulous"
                                                      v-if="!topic.memberIsLike"
                                                      @click="handleGood(topic.topicId)">点赞</text>
                                            </div>
                                            <text class="community-main-item-content-card-moment-info-feedbac-item-line">|</text>
                                            <div class="community-main-item-content-card-moment-info-feedbac-item-box"
                                                 @click="handleEvaluate(topic.topicId)">
                                                <image class="community-main-item-content-card-moment-info-feedbac-item-pinjia"
                                                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/pinjia.png"></image>
                                                <text class="community-main-item-content-card-moment-info-feedbac-item-evaluate">评价</text>
                                            </div>
                                        </div>
                                        <image class="community-main-item-content-card-moment-info-feedbac-image"
                                               @click="handleDotDotDot(topic.topicId)"
                                               src='https://gw.alicdn.com/tfs/TB1_POLc3MPMeJjy1XcXXXpppXa-66-46.png'></image>
                                    </div>
                                </div>
                                <image class="community-main-item-content-moment-arrow"
                                       src="https://gw.alicdn.com/tfs/TB1F0OLc3oQMeJjy0FnXXb8gFXa-30-12.png"
                                       v-if="topic.topicLikeList.length > 0 || topic.topicCommentList.length > 0"></image>
                                <div class="community-main-item-content-moment-likes"
                                     :class="[topic.topicCommentList.length > 0 ? 'community-main-item-content-moment-likes-bottom-line' : '']"
                                     v-if="topic.topicLikeList.length > 0">
                                     <text class="community-main-item-content-moment-likes-good">♡</text>
                                     <text class="community-main-item-content-moment-likes-list link-text"
                                          v-for="(like, index) in topic.topicLikeList"
                                          :key="like.memberId"
                                           @click="handleOrterPage(like.memberId)">{{like.memberNickName}} <text class="community-main-item-content-moment-likes-list-line"
                                                                                                                 v-if="index != topic.topicLikeList.length-1">，</text></text>
                                </div>
                                <text class="community-main-item-content-comment-list"
                                      v-if="topic.topicCommentList.length > 0"
                                      v-for="(comment, index) in topic.topicCommentList"
                                      :key="index"
                                      :class="[index == '0' ? 'community-main-item-content-comment-list-one' : '']"
                                      @click="handleReply(comment.memberId, comment.topicCommentId, topic.topicId, comment.memberNickName)">{{comment.memberNickName}}{{comment.replyMemberNickName ? ' 回复 ' + comment.replyMemberNickName : ''}}：{{comment.topicCommentContent}}</text>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="input-bar"
                     v-if="showInputBar">
                    <input class="input"
                           type="text"
                           :autofocus="true"
                           @blur="handeleInputBarBlur"
                           v-model="topicCommentContent"
                           :placeholder="replyMemberName ? '回复：' + replyMemberName : '输入你想说的...'" />
                    <div class="btn-send" @click="handleUserInput">
                        <text class="btn-send-text">发送</text>
                    </div>
                </div>
            </div>
        </div>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
        <text class="the-end"
              v-if="theEnd">-- 没有更多了 --</text>

        <wxc-dialog title="确定删除"
                    content="本操作不可恢复，您确定删除本条动态吗？"
                    :show="wxcDialogConfirmShow"
                    main-btn-color="#e994a9"
                    @wxcDialogCancelBtnClicked="dialogConfirmBtnNo"
                    @wxcDialogConfirmBtnClicked="dialogConfirmBtnClick">
        </wxc-dialog>
    </scroller>

</template>

<script>
    import {WxcStepper, WxcDialog, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcStepper,
            WxcDialog,
            WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            isLoad: false,
            loadSuccess: false,
            wxcDialogConfirmShow: false,
            showImageList: [],
            showTopicEvaluate: '',
            showInputBar: false,
            topicList: [],
            topicTotal: [],
            pageIndex: 1,
            pageSize: 10,
            topicId: '',
            getMemberId: '',
            replyCommentId: '',
            replyMemberId: '',
            topicCommentContent: '',
            replyMemberName: '',
            delTopicId: '',
            theEnd: false
        }),
        props: {
            activeIndex: {
                type: String,
                required: true
            }
        },
        mounted() {
            this.storage.getItem(this.setMemberId, (res) => {
                if (res.result === 'success') {
                    this.getMemberId = res.data
                }
            });

            this.globalEvent.addEventListener('homeDeleteSuccess', (data) => {
                this.pageIndex = 1;
                this.pageSize = 10;
                this.topicList = [];
                this.topicId = '';
                this.showImageList = [];
                this.haneleLoad();
            });

            this.globalEvent.addEventListener('publishSuccess', (data) => {    //事件监听
                this.pageIndex = 1;
                this.pageSize = 10;
                this.topicList = [];
                this.topicId = '';
                this.showImageList = [];
                this.haneleLoad();
            });

            this.haneleLoad();
        },
        methods: {
            handleToCircleDetail(id) {
                this.push('/circle/detail?topicId=' + id);
            },
            handleOpenImageLigh(imagePath, index) {
                this.showImageList = [];
                for (var a = 0; a < imagePath.length; a++){
                    var showImageList = {};
                    showImageList = this.imageHost + imagePath[a].imagePath
                    this.showImageList.push(showImageList);
                }

                if (this.platform != 'web') {
                    this.chuangshi.openImageBrowser({
                        list: this.showImageList,
                        pageIndex: index
                    });
                }

            },
            windowScrool(event) {
                this.showInputBar = false;
                this.showTopicEvaluate = '';
                return;
            },
            handleLoadMore() {
                if (this.topicList.length + 1 >= this.topicTotal) {
                    this.theEnd = true;
                    return;
                }
                this.pageIndex = this.pageIndex + 1;
                this.topicId = this.topicList[0].systemCreateTime;
                this.haneleLoad();
            },
            handleOrterPage(id) {
                if(id == this.getMemberId) {
                    this.push('/circle/homePage');
                } else{
                    this.push('/circle/otherPage?memberId=' + id);
                }
                // this.toast(id);
            },
            handleDotDotDot(id) {
                this.replyMemberName = '';

                if(this.showTopicEvaluate == ''){
                    this.showTopicEvaluate = id;
                    return;
                } else {
                    this.showTopicEvaluate = '';
                    return;
                }
            },
            handleDelGood(id) {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/like/mobile/v1/delete',
                    data: {
                        topicId: id
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.toast('取消点赞');
                        this.handleGoddList(id);
                        this.showTopicEvaluate = '';
                        for(var i = 0; i <= this.topicList.length; i++){
                            if(this.topicList[i].topicId == id) {
                                this.topicList[i].memberIsLike = false;
                            }
                        }
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleGood(id) {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/like/mobile/v1/save',
                    data: {
                        topicId: id
                    },
                    success: (data) => {
                        this.isLoad = false;
                        this.toast('点赞成功');
                        this.handleGoddList(id);
                        this.showTopicEvaluate = '';
                        for(var i = 0; i <= this.topicList.length; i++){
                            if(this.topicList[i].topicId == id) {
                                this.topicList[i].memberIsLike = true;
                            }
                        }
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleGoddList(id) {
                this.request({
                    url: '/xingxiao/topic/like/mobile/v1/list',
                    data: {
                        topicId: id
                    },
                    success: (data) => {
                        for(var i = 0; i <= this.topicList.length; i++){
                            if(this.topicList[i].topicId == id) {
                                this.topicList[i].topicLikeList = data;
                            }
                        }

                        this.isLoad = false;
                        this.showTopicEvaluate = ''
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handeleInputBarBlur() {
                this.showTopicEvaluate = false;
                this.showInputBar = false;
                this.topicCommentContent = ''
            },
            handleReply(memberId, topicCommentId, topicId, memberNickName) {
                this.showTopicEvaluate = true;
                this.showInputBar = true;
                this.topicCommentContent = '';

                this.topicId = topicId;
                this.replyMemberId = memberId;
                this.replyCommentId = topicCommentId;
                this.replyMemberName = memberNickName;
                // console.log(this.replyCommentId, this.replyMemberId, this.topicId);
            },
            handleUserInput() {
                if(this.topicCommentContent == '' || this.topicCommentContent.trim() == ''){
                    this.toast("评价内容不能为空");
                    this.topicCommentContent = '';
                    this.showTopicEvaluate = false;
                    this.showInputBar = false;
                    return;
                }
                this.isLoad = true;
                this.showTopicEvaluate = false;
                this.showInputBar = false;
                this.request({
                    url: '/xingxiao/topic/comment/mobile/v1/save',
                    data: {
                        topicId: this.topicId,
                        replyCommentId: this.replyCommentId,
                        replyMemberId: this.replyMemberId,
                        topicCommentContent: this.topicCommentContent
                    },
                    success: (data) => {
                        this.topicCommentContent = '';
                        this.handleGetCommentList();
                    }
                })
            },
            handleGetCommentList() {
                this.request({
                    url: '/xingxiao/topic/comment/mobile/v1/list',
                    data: {
                        topicId: this.topicId
                    },
                    success: (data) => {
                        this.toast("评论成功");
                        this.isLoad = false;
                        for (var i = 0 ; i <= this.topicList.length; i++) {
                            if (this.topicList[i].topicId == this.topicId) {
                                this.topicList[i].topicCommentList = data;
                            }
                        }
                        this.topicCommentContent = '';
                    }
                })
            },
            handleEvaluate(id) {
                this.topicId = id;
                this.showTopicEvaluate = '';
                this.showTopicEvaluate = '',
                this.showInputBar = !this.showInputBar
            },
            dialogConfirmBtnNo () {
                this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
            },
            dialogConfirmBtnClick () {
                this.isLoad = true;
                this.request({
                    url: '/xingxiao/topic/mobile/v1/delete',
                    data: {
                        topicId: this.delTopicId,
                    },
                    success: (data) => {
                        this.wxcDialogConfirmShow = !this.wxcDialogConfirmShow;
                        this.isLoad = false;

                        this.chuangshi.sendEventListener({
                            name: 'circleDeleteSuccess',
                            data: {    }
                        });

                        for (var a = 0; a <= this.topicList.length; a++) {
                            if(this.delTopicId == this.topicList[a].topicId){
                                this.topicList.splice(a, 1);
                            }
                        }
                    },
                    error: (data) => {
                        this.isLoad = false;
                    }
                });
            },
            haneleDeleteTopic(topicId) {
                this.delTopicId = topicId;
                this.wxcDialogConfirmShow = true;
            },
            haneleLoad() {
                this.request({
                    url: '/xingxiao/topic/mobile/v1/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize,
                        topicId: this.topicId
                    },
                    success: (data) => {
                        for (var i in data.list) {
                            data.list[i].systemCreateTime = this.timeToDateStr(data.list[i].systemCreateTime)
                        }
                        this.topicList = this.topicList.concat(data.list);
                        this.topicTotal = data.total;
                        this.loadSuccess = true
                    },
                    error: (data) => {
                        this.isLoad = false;
                        this.toast(data.message);
                    }
                });
            },
            handleToHomePage(memberId, topicId) {
                if(memberId == this.getMemberId) {
                    this.push('/circle/homePage');
                } else{
                    this.push('/circle/otherPage?memberId=' + memberId + '&topicId=' + topicId);
                }
            },
            timeToDateStr(time) {
                var differTime = parseInt((new Date().getTime() - time) / 1000);
                if (differTime <= 0) {
                    return "刚刚";
                } else if (differTime < 60) {
                    return differTime + "秒前";
                } else if (differTime < 3600) {
                    return parseInt(differTime / 60) + "分钟前";
                } else if (differTime < 86400) {
                    return parseInt(differTime / 3600) + "小时前";
                } else if (differTime < 2592000) {
                    return parseInt(differTime / 86400) + "天前";
                } else if (differTime < 31104000) {
                    return parseInt(differTime / 2592000) + "月前";
                } else {
                    return parseInt(differTime / 31104000) + "年前";
                }
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
    }

    .the-end{
        width: 750px;
        text-align: center;
        color: #999999;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

    .community-box {
        background-color: #ffffff;
        margin-bottom: 100px;
    }

    .community-header {
        width: 750px;
        height: 600px;
        position: relative;
    }

    .community-header-background {
        width: 750px;
        height: 520px;
        display: block;
        position: absolute;
        top: 0px;
    }

    .community-header-name {
        position: absolute;
        right: 250px;
        bottom: 105px;
        font-size: 36px;
        color: #FFF;
    }

    .community-header-author {
        position: absolute;
        width: 185px;
        height: 185px;
        right: 40px;
        bottom: 0px;
        border-left-color: #ffffff;
        border-left-width: 4px;
        border-bottom-width: 4px;
        border-bottom-color: #ffffff;
        border-right-width: 4px;
        border-right-color: #ffffff;
        border-top-color: #ffffff;
        border-top-width: 4px;
    }

    .community-main {
        margin-top: 40px;
    }

    .community-main-item {
        display: flex;
        border-bottom-width: 1px;
        border-bottom-color: #dddddd;
        padding: 20px;
        flex-direction: row;
    }

    .community-main-item-author {
        width: 95px;
        height: 95px;
        margin-right: 20px;
    }

    .community-main-item-content {
        width: 635px;
        padding-bottom: 15px;
    }

    .community-main-item-content-author-name {
        font-size: 30px;
        padding-top: -4px;
        padding-bottom: 8px;
        color: #5E7EC2;
        font-weight: bold;
    }

    .community-main-item-content-moment-content {
        lines: 3;
        width: 600px;
        font-size: 26px;
        line-height: 40px;
        padding-top: 5px;
        margin-bottom: 18px;
        color: #353535;
        user-select: text;
    }

    .community-main-item-content-card-picture {
        width: 450px;
        height: 300px;
    }

    .community-main-item-content-moment-many-pictures {
        width: 600px;
        flex-direction: row;
        flex-wrap: wrap;
        margin-bottom: -10px;
    }

    .community-main-item-content-moment-many-pictures-image {
        width: 190px;
        height: 190px;
        margin-right: 10px;
        margin-bottom: 10px;
    }

    .community-main-item-content-card-moment-info {
        display: flex;
        position: relative;
        padding-top: 20px;
        height: 50px;
        width: 600px;
        flex-direction: row;
    }

    .community-main-item-content-card-moment-info-time {
        margin-right: 20px;
        color: #999999;
        font-size: 24px;
    }

    .community-main-item-content-card-moment-info-delete{
        color: #576B95;
        font-size: 24px;
    }

    .community-main-item-content-card-moment-info-feedbac {
        flex: 1;
    }

    .community-main-item-content-card-moment-info-feedbac-item {
        position: absolute;
        right: 54px;
        top: 10px;
        width: 240px;
        height: 58px;
        border-radius: 6px;
        background-color: #313131;
        box-sizing: border-box;
        flex-direction: row;
    }
    
    .community-main-item-content-card-moment-info-feedbac-item-box{
        width: 99px;
        position: relative;
    }

    .community-main-item-content-card-moment-info-feedbac-item-xin{
        width: 28px;
        height: 28px;
        position: absolute;
        top: 14px;
        left: 14px;
    }

    .community-main-item-content-card-moment-info-feedbac-item-pinjia{
        width: 32px;
        height: 32px;
        position: absolute;
        top: 12px;
        left: 16px;
    }

    .community-main-item-content-card-moment-info-feedbac-item-fabulous {
        width: 69px;
        font-size: 24px;
        text-align: center;
        color: #ffffff;
        position: absolute;
        top: 10px;
        left: 40px;
    }

    .community-main-item-content-card-moment-info-feedbac-item-line {
        width: 14px;
        height: 54px;
        color: #ffffff;
        padding-top: 8px;
        padding-left: 9px;
    }

    .community-main-item-content-card-moment-info-feedbac-item-evaluate {
        width: 69px;
        font-size: 24px;
        line-height: 52px;
        color: #ffffff;
        position: absolute;
        top: 3px;
        left: 56px;
    }

    .community-main-item-content-card-moment-info-feedbac-image {
        position: absolute;
        right: 0px;
        top: 20px;
        width: 45px;
        height: 32px;
    }

    .community-main-item-content-moment-arrow {
        width: 30px;
        height: 12px;
        margin-top: 28px;
        margin-left: 30px;
        display: block;
    }

    .community-main-item-content-moment-likes {
        width: 600px;
        background-color: #F2F2F2;
        padding-left: 56px;
        padding-right: 10px;
        padding-top: 10px;
        padding-bottom: 10px;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap-reverse;
        justify-content: end
    }

    .community-main-item-content-moment-likes-bottom-line {
        border-bottom-width: 1px;
        border-bottom-color: #dddddd;
    }


    .community-main-item-content-moment-likes-good{
        width: 36px;
        color: #576B95;
        font-size: 26px;
        position: absolute;
        top: 10px;
        left: 20px;
    }

    .community-main-item-content-moment-likes-list {
        color: #576B95;
        font-size: 24px;
        line-height: 28px;
        position: relative;
        padding-right: 14px;
    }
    .community-main-item-content-moment-likes-list-line{
        width: 20px;
        height: 22px;
        right: 0px;
        line-height: 6px;
        position: absolute;
        top: 6px;
        color: #576B95;
    }

    .community-main-item-content-comment-list {
        width: 600px;
        font-size: 24px;
        color: #454545;
        border-top-width: 1px;
        border-top-color: #dddddd;
        background-color: #F2F2F2;
        padding-left: 20px;
        padding-right: 10px;
        padding-top: 10px;
        padding-bottom: 15px;
    }
    .community-main-item-content-comment-list-one{
        border-top-width: 1px;
        border-top-color: #F2F2F2;
    }

    .input-bar {
        position: fixed;
        left: 0px;
        bottom: 0px;
        right: 0px;
        height: 90px;
        border-top-width: 2px;
        border-top-color: #DDD;
        background-color: #FFFFFF;
        flex-direction: row;
        justify-content: space-between;
    }
    .input {
        width: 610px;
        height: 90px;
        padding-left: 30px;
        color: #606060;
        background-color: #FFFFFF;
        font-size: 28px;
    }
    .btn-send {
        width: 140px;
        justify-content: center;
        border-left-width: 2px;
        border-left-color: #DDD;
        background-color: #e994a9;
    }
    .btn-send:active {
        background-color: #E0E0E0;
    }
    .btn-send-text {
        text-align: center;
        color: #ffffff;
        font-size: 28px;
    }
    .location {
        font-size: 24px;
        color: #576B95;
    }
    .margin-top-10 {
        margin-top: 20px;
    }

</style>