<template>
    <scroller class="container"
              @loadmore="handleLoadMore"
              loadmoreoffset="240"
              :style="{height: pageHeight + 'px'}">
        <div class="container">
            <div class="no-data"
                 v-if="topicList.length == 0 && loadSuccess">
                <image class="no-data-img"
                       src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
                <text class="no-data-text">当前没有数据</text>
            </div>
            <div class="community-box">
                <!--<div class="community-member-header">-->
                    <!--<image class="community-member-header-background"-->
                           <!--resize="cover"-->
                           <!--src="http://pic.fayi.com.cn/Upload/origin/123/62123.jpg"></image>-->
                    <!--<text class="community-member-header-name">{{userName}}</text>-->
                    <!--<image class="community-member-header-author"-->
                           <!--:src="imageHost + userAvatar"></image>-->
                    <!--&lt;!&ndash;<text class="community-member-header-user-explain">因为走得太久，忘记了我们为什么出发。</text>&ndash;&gt;-->
                <!--</div>-->
                <div class="community-member-body">
                    <div class="community-member-body-item">
                        <text class="community-member-body-item-time">
                            今天
                        </text>
                        <div class="community-member-body-item-content" @click="handlePublish">
                            <div class="community-member-body-item-content-image">
                                <text class="community-member-body-add">+</text>
                            </div>
                            <div class="community-member-body-item-content-text"></div>
                        </div>
                    </div>
                    <!--<div class="community-member-body-item">-->
                        <!--<text class="community-member-body-item-time">-->
                            <!--<text class="community-member-body-item-time-month">2月</text>-->
                            <!--<text class="community-member-body-item-time-day">22日</text>-->
                        <!--</text>-->
                        <!--<div class="community-member-body-item-content">-->
                            <!--<image class="community-member-body-item-content-image"-->
                                   <!--resize="cover"-->
                                   <!--src="http://pic.fayi.com.cn/Upload/origin/123/62123.jpg"></image>-->
                            <!--<div class="community-member-body-item-content-text">-->
                                <!--<text class="community-member-body-item-content-text-titme"-->
                                      <!--lines="3">在只针对 PC 端开发的年代，可以通过后端控制输出文字的长度来实现固定行数的效果。但在响应式页面，这可能不再适用，只能输出足够多的文字，然后通过前端截取需要的行数。</text>-->
                                <!--<text class="community-member-body-item-content-text-number">共5张</text>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->
                </div>
                <div v-for="item in topicList"
                     :key="item.topicId">
                    <div class="community-member-body-item"
                         @click="handleToDetail(item.topicId)"
                         v-if="item.topicImageList.length != 0">
                        <text class="community-member-body-item-time">
                            <div>
                                <text class="community-member-body-item-time-month">{{item.systemCreateDate}}日</text>
                            </div>
                            <text class="community-member-body-item-time-day">{{item.systemCreateTime}}</text>
                        </text>
                        <div class="community-member-body-item-content">
                            <image class="community-member-body-item-content-image"
                                   resize="cover"
                                   :src="imageHost + item.topicImageList[0].imagePath"></image>
                            <div class="community-member-body-item-content-text">
                                <text class="community-member-body-item-content-text-titme"
                                      lines="3">{{item.topicContent}}</text>
                                <text class="community-member-body-item-content-text-number">共{{item.topicImageList.length}}张</text>
                            </div>
                        </div>
                    </div>

                    <div class="community-member-body-item"
                         @click="handleToDetail(item.topicId)"
                         v-if="item.topicImageList.length == 0">
                        <text class="community-member-body-item-time">
                            <text class="community-member-body-item-time-month">{{item.systemCreateDate}}日</text>
                            <text class="community-member-body-item-time-day">{{item.systemCreateTime}}</text>
                        </text>
                        <div class="community-member-body-item-content">
                            <div class="community-member-body-item-content-title">
                                <text class="community-member-body-item-content-title-text"
                                      lines="4">{{item.topicContent}}</text>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <text class="the-end"
                  v-if="theEnd">-- 没有更多了 --</text>
        </div>
    </scroller>

</template>

<script>
    import {WxcStepper, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcStepper,
            WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            pageIndex: 1,
            pageSize: 10,
            topicList: [],
            topicTotal: 0,
            loadSuccess: false,
            theEnd: false

        }),
        mounted() {
            this.changeTitle('圈子主页');
            this.haneleLoad();

            this.globalEvent.addEventListener('publishSuccess', (data) => {    //事件监听
                this.pageIndex = 1;
                this.pageSize = 10;
                this.topicList = [];
                this.topicTotal = 0;
                this.haneleOnLoad();
            });
        },
        methods: {
            handleToDetail(id) {
                this.push('/circle/detail?topicId=' + id);
            },
            haneleLoad() {
                this.request({
                    url: '/xingxiao/topic/mobile/v1/my/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize
                    },
                    success: (data) => {
                        for(var a = 0; a < data.list.length; a++) {
                            data.list[a].systemCreateDate = this.getCreateDate(data.list[a].systemCreateTime)
                            data.list[a].systemCreateTime = this.getYearMonth(data.list[a].systemCreateTime)
                        }
                        this.topicList = this.topicList.concat(data.list);
                        this.topicTotal = data.total;
                        this.loadSuccess = true;
                    }
                });
            },
            haneleOnLoad() {
                this.request({
                    url: '/xingxiao/topic/mobile/v1/my/list',
                    data: {
                        pageIndex: this.pageIndex,
                        pageSize: this.pageSize
                    },
                    success: (data) => {
                        for(var a = 0; a < data.list.length; a++) {
                            // this.toast(data.list[a].systemCreateTime);
                            data.list[a].systemCreateDate = this.getCreateDate(data.list[a].systemCreateTime)
                            data.list[a].systemCreateTime = this.getYearMonth(data.list[a].systemCreateTime)
                        }
                        this.topicList = data.list;
                        this.topicTotal = data.total;
                    }
                });
            },
            handleLoadMore() {
                if (this.topicList.length + 1 >= this.topicTotal) {
                    this.theEnd = true;
                    return;
                }
                this.pageIndex = this.pageIndex + 1;
                this.haneleLoad();
            },
            handlePublish() {
                this.push('/circle/publish');
            },
            getYearMonth(timestamp) {
                var date = new Date(timestamp);
                var Y = date.getFullYear() + '年';
                var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
                return Y + M;
            },
            getCreateDate(timestamp) {
                var date = new Date(timestamp);
                var Y = date.getFullYear() + '年';
                var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
                var D = date.getDate();
                return D;
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        padding-bottom: 40px;
    }

    .the-end {
        width: 750px;
        text-align: center;
        color: #999999;
        padding-top: 80px;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

    .community-box {
        background-color: #ffffff;
    }

    .community-member-header {
        width: 750px;
        height: 640px;
        position: relative;
    }
    .community-member-header-background {
        width: 750px;
        height: 520px;
        display: block;
        position: absolute;
        top: 0px;
    }
    .community-member-header-name {
        position: absolute;
        right: 250px;
        bottom: 145px;
        font-size: 36px;
        color: #FFF;
    }
    .community-member-header-author {
        position: absolute;
        width: 185px;
        height: 185px;
        right: 40px;
        bottom: 40px;
        border-left-color: #ffffff;
        border-left-width: 4px;
        border-bottom-width: 4px;
        border-bottom-color: #ffffff;
        border-right-width: 4px;
        border-right-color: #ffffff;
        border-top-color: #ffffff;
        border-top-width: 4px;
    }
    .community-member-header-user-explain{
        position: absolute;
        bottom: 4px;
        right: 0px;
        font-size: 24px;
        color: #999999;
    }
    .community-member-body{
        padding: 20px 0px;
    }
    .community-member-body-item{
        display: flex;
        margin-top: 40px;
        flex-direction: row;
        flex-wrap: wrap;
    }
    .community-member-body-item-time{
        width: 180px;
        height: 180px;
        line-height: 12px;
        padding-left: 20px;
        margin-right: 20px;
        font-size: 56px;
        font-weight: bold;
    }
    .community-member-body-item-content{
        width: 550px;
        height: 180px;
        padding-right: 10px;
    }
    .community-member-body-item-content-image{
        width: 180px;
        height: 180px;
        position: absolute;
    }
    .community-member-body-item-content-text-titme{
        width: 540px;
        height: 140px;
        line-height: 36px;
        padding-left: 200px;
        lines: 3;
    }
    .community-member-body-item-time-month{
        font-size: 56px;
        font-weight: bold;
    }
    .community-member-body-item-time-day{
        font-size: 28px;
    }
    .community-member-body-item-content-text-number{
        width: 540px;
        color: #cccccc;
        font-size: 28px;
        padding-left: 200px;
    }
    .community-member-body-item-content-title{
        position: absolute;
        top: 0px;
        left: 0px;
        right: 20px;
        bottom: 0px;
        padding: 10px;
        box-sizing: border-box;
        background-color: #f1f1f1;
    }
    .community-member-body-item-content-title-text{
        font-size: 30px;
        line-height: 40px;
        lines: 4;
    }
    .community-member-body-add{
        width: 180px;
        height: 180px;
        color: #cccccc;
        justify-content: center;
        box-sizing: border-box;
        padding-top: 40px;
        padding-left: 64px;
        font-size: 68px;
        border-left-color: #cccccc;
        border-left-width: 2px;
        border-bottom-width: 2px;
        border-bottom-color: #cccccc;
        border-right-width: 2px;
        border-right-color: #cccccc;
        border-top-color: #cccccc;
        border-top-width: 2px;
    }
    .location {
        font-size: 24px;
        color: #576B95;
        margin-top: 12px;
        margin-left: 200px;
    }
</style>