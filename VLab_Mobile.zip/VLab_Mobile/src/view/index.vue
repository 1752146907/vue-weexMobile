<template>
	<div class="wrapper"
		 :style="{height: pageHeight + 'px'}">
		<div class="tab-item" :style="{left: parseInt(activeIndex) * -750 + 'px'}">
			<!--首页-->
			<AgentIndex :activeIndex="activeIndex"></AgentIndex>
			<!--圈子-->
			<CircleIndex :activeIndex="activeIndex"></CircleIndex>
			<!--动态-->
			<DynamicIndex :activeIndex="activeIndex" :isNoLogin="isNoLogin"></DynamicIndex>
			<!--渠道-->
			<ChannelIndex :activeIndex="activeIndex" :isNoLogin="isNoLogin"></ChannelIndex>
			<!--我的-->
			<BrandIndex></BrandIndex>
		</div>
		<div class="bar">
			<div class="bar-item" @click="handleClickBarItm('0')">
				<image :src="activeIndex == '0' ? 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-0-active.png' : 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-0.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == '0' ? 'bar-item-text-active' : 'bar-item-text']">首页</text>
			</div>
			<div class="bar-item" @click="handleClickBarItm('1')">
				<image :src="activeIndex == '1' ? 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-1-active.png' : 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-1.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == '1' ? 'bar-item-text-active' : 'bar-item-text']">圈子</text>
			</div>
			<div class="bar-item" @click="handleClickBarItm('2')">
				<image :src="activeIndex == '2' ? 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-2-active.png' : 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-2.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == '2' ? 'bar-item-text-active' : 'bar-item-text']">动态</text>
			</div>
			<div class="bar-item" @click="handleClickBarItm('3')">
				<image :src="activeIndex == '3' ? 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-3-active.png' : 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/png/icon-3.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == '3' ? 'bar-item-text-active' : 'bar-item-text']">渠道</text>
			</div>
			<div class="bar-item" @click="handleClickBarItm('4')">
				<image :src="activeIndex == '4' ? 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/my_active.png' : 'http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/my.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == '4' ? 'bar-item-text-active' : 'bar-item-text']">我的</text>
			</div>
		</div>
	</div>
</template>

<script>
	import mixin from '../common/mixin';

	import AgentIndex from "./home/index";
	import CircleIndex from "./circle/index";
    import DynamicIndex from "./dynamic/index";
    import ChannelIndex from "./channel/index";
    import BrandIndex from "./my/index";


	export default {
		components: {BrandIndex, CircleIndex, DynamicIndex, ChannelIndex, AgentIndex},
		mixins: [mixin],
		data () {
			return {
				activeIndex: '0',
                riderName: '',
                siteName: '',
                riderAccountBalance: 0,
                onlineTime: '',
                riderIsWork: false,
				isNoLogin: false
			}
		},
		mounted () {
            // this.storage.setItem(this.token, '131d47c6810f45053a63241b8955d02ff698536bdc02572a39e1704007d076b5e5bb3f5f3919ac7af788eccb709a8e969d81b8c27ccd76d9c2ffb118f63da824f8b0aafbd83089ac67e2053a49df0205e5e1926df01294614c3251dfe3405464')

            if (this.platform === 'web') {
				this.storage.getItem('index-active-index', (res) => {
					if (res.result === 'success') {
						this.activeIndex = res.data;
					} else {
						this.activeIndex = 0;
					}
				});
			} else {
				this.handleChangeTitle(this.activeIndex);
			}

            this.storage.getItem(this.token, (res) => {
                if (res.result === 'success') {
                    this.isNoLogin  = true
                } else{
                    this.isNoLogin  = false
                }
            })
		},
		methods: {
			handleClickBarItm (activeIndex) {
				this.storage.setItem('index-active-index', activeIndex, event => {
					this.activeIndex = activeIndex;

					this.handleChangeTitle(activeIndex);
				});
			},
			handleChangeTitle (index) {
			    if(index == 0) {
                    this.changeTitle('首页');
				}
                if(index == 1) {
                    this.changeTitle('圈子');
                }
                if(index == 2) {
                    this.changeTitle('动态');
                }
                if(index == 3) {
                    this.changeTitle('渠道');
                    this.chuangshi.sendEventListener({  // 触发渠道页面刷新
                        name: 'handleChanner',
                        data: {    }
                    });
                }
                if(index == 4) {
                    this.changeTitle('我的');
                }
			}
		}
	}
</script>

<style scoped>
	.wrapper {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}

	.tab-item {
		position: relative;
		width: 1500px;
		flex: 1;
		flex-direction: row;
		align-items: stretch;
	}

	.bar {
		position: fixed;
		left: 0px;
		bottom: 0px;
		width: 750px;
		height: 100px;
		flex-wrap: nowrap;
		flex-direction: row;
		justify-content: space-around;
		border-top-width: 1px;
		border-top-color: #d9d9d9;
		background-color: #ffffff;
		z-index: 99;
	}

	.bar-item {
		flex: 1;
		align-items: center;
		justify-content: center;
	}

	.bar-item-icon {
		width: 42px;
		height: 42px;
		margin-top: 5px;
	}

	.bar-item-text {
		font-size: 24px;
		margin-top: 2px;
		color: #666666;
	}

	.bar-item-text-active {
		font-size: 24px;
		margin-top: 2px;
		color: #e994a9;
	}
</style>
