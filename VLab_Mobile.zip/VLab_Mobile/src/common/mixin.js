

export default {
	data () {
		return {
			pageHeight: 0,
            host: 'https://api.vpluslab.com',
			// host: 'http://localhost:8080',
			// host: 'http://192.168.3.86:8088',
			imageHost: 'https://api.vpluslab.com',
			appId: '999557245638234113',
			version: '1.0.0',
			platform: weex.config.env.platform.toLowerCase(),
			loginValidateSuccessAction: '',
			loginValidateSuccessData: '',
			token: '',
            setMemberId: 'memberId',
            wechatAppId: 'wxe423115f9bdcd344',
            wechatAppSecret: 'f6bbb5b706e16ce45aafd9eec967465e'
		}
	},
	created () {
		const dom = weex.requireModule('dom');
		const modal = weex.requireModule('modal');
		const stream = weex.requireModule('stream');
		const storage = weex.requireModule('storage');
		const navigator = weex.requireModule('navigator');
		const globalEvent = weex.requireModule('globalEvent');
		const chuangshi = weex.requireModule('chuangshi');

		this.dom = dom;
		this.modal = modal;
		this.stream = stream;
		this.storage = storage;
		this.navigator = navigator;
		this.globalEvent = globalEvent;
		this.chuangshi = chuangshi;
		this.token = 'token_' + this.version;

		if (this.platform == 'web') {
			this.pageHeight = weex.config.env.deviceHeight / weex.config.env.deviceWidth * 750;
		} else if (this.platform == 'ios') {
			this.pageHeight = weex.config.env.deviceHeight / weex.config.env.deviceWidth * 750 - 116;
		} else {
			this.pageHeight = weex.config.env.deviceHeight / weex.config.env.deviceWidth * 750;
		}
	},
	mounted () {

	},
	methods: {
		changeTitle (title) {
			if (this.platform == 'web') {
				return;
			}

			this.chuangshi.changeTitle(title);

			this.chuangshi.addRefreshButton();
		},
		isPhone(phone) {
			if (!(/^1(3|4|5|7|8)\d{9}$/.test(phone))) {
				return false;
			}
			return true;
		},
		handleIsLogin(config) {
            this.storage.getItem(this.token, (res) => {
                if (res.result != 'success') {
                    if (this.platform != 'web') {
                        this.globalEvent.removeEventListener('getWeiXinAuth');
                        this.globalEvent.addEventListener('getWeiXinAuth', (data) => {
                        	if (data.code) {
                                this.handleGetUserInfo(data.code, config);
                            } else {
                        		if (config.fail) {
                        			config.fail();
								}
							}
                            this.globalEvent.removeEventListener('getWeiXinAuth');
                        });
                        this.chuangshi.getWeiXinAuth();
                    }
                } else{
                	if (config.success) {
                		config.success();
					}
				}
            })
		},
        handleGetUserInfo (code, config) {
            this.isLoad = true;
            this.request({
                url: '/xingxiao/member/mobile/v1/oauth2/get/user/info',
                data: {
                    code: code
                },
                success: (data) => {
                	if (data.openId) {
                        this.handleLogin(config, data.openId, data.unionId, data.nickName, data.sex, data.province, data.city, data.country, data.headImgUrl);
                    } else {
                        if (config.fail) {
                            config.fail();
                        }
					}
                },
                error: (data) => {
                    this.isLoad = false;
                    if (config.fail) {
                        config.fail();
					}
                }
            });
        },
        handleLogin (config, openId, unionId, nickName, sex, province, city, country, headImgUrl) {
            this.request({
                url: '/xingxiao/member/mobile/v1/login',
                data: {
                    openId: openId,
                    unionId: unionId,
                    nickName: nickName,
                    gender: sex,
                    avatarId: '',
                    avatarPath: headImgUrl,
                    area: city
                },
                success: (data) => {
                    // this.toast("登录成功");
                    this.isLoad = false;

                    if (config.success) {
                        config.success();
                    }

                    this.storage.setItem(this.token, data.token, (res) => {   //存储token
                        if (res.result === 'success') {
                            // 数据缓存成功
                        }
                    });
                    this.storage.setItem(this.setMemberId, data.memberId, (res) => {   //存储token
                        if (res.result === 'success') {
                            // 数据缓存成功
                            // this.toast(data.memberId);
                        }
                    });

                },
                error: (data) => {
                    this.isLoad = false
                    if (config.fail) {
                        config.fail();
                    }
                }
            });
        },
		toast (text, callback) {
			this.modal.toast({
				message: text,
				duration: 1.0
			});

			if (callback) {
				setTimeout(() => {
					callback();
				}, 1000);
			}
		},
		login (userId) {
			this.chuangshi.login(userId);
		},
		logout () {
			this.chuangshi.logout();
		},

		push (url) {
			if (this.platform == 'web') {
				this.$router.push({path: url})
			} else {
				var bundleUrl = weex.config.bundleUrl;
				var baseUrl =  bundleUrl.split('/dist/')[0] + '/dist/view';

				if (url.indexOf('?') == -1) {
					url += '.js';
				} else {
					url = url.split('?')[0] + '.js?' + url.split('?')[1];
				}

				// this.toast(baseUrl + url)

				// this.navigator.push({
				// 	url: baseUrl + url,
				// 	animated: "true"
				// });
				this.chuangshi.openURL(baseUrl + url);
			}
		},
		pushRoot (url) {
			if (this.platform == 'web') {
				this.$router.push({path: url})
			} else {
				var bundleUrl = weex.config.bundleUrl;
				var baseUrl =  bundleUrl.split('/dist/')[0] + '/dist/view';

				if (url.indexOf('?') == -1) {
					url += '.js';
				} else {
					url = url.split('?')[0] + '.js?' + url.split('?')[1];
				}

				this.chuangshi.openRootURL(baseUrl + url);
			}
		},
		pop () {
			if (this.platform === 'web') {
				this.$router.back();
			} else {
				this.navigator.pop({
					animated: 'true'
				});
			}
		},
		getParameter (key) {
			var bundleUrl = weex.config.bundleUrl;

			if (this.platform === 'web') {
				bundleUrl = this.$router.history.current.fullPath;
			}

			if (bundleUrl.indexOf('?') == -1) {
				return;
			}

			var parameterList = bundleUrl.split('?')[1].split(('&'));
			for (var parameter of parameterList) {
				var parameterKey = parameter.split('=')[0];
				var parameterValue = parameter.split('=')[1];

				if (key == parameterKey) {
					return parameterValue;
				}
			}

			return '';
		},
		request (config) {
            this.storage.getItem(this.token, (res) => {
                var token = '';

                if (res.result === 'success') {
                    var token = res.data;
                }

                config.data.appId = this.appId;
                config.data.token = token;
                config.data.platform = this.platform;
                config.data.version = this.version;
                config.data.timestamp = Math.round(new Date().getTime() / 1000);

                config.data.systemRequestUserId = '14463951d1d94d39a9216dbd818fc984';

                let url = this.host + config.url;
                if (config.url.startsWith('http')) {
                    url = config.url;
                }

                this.stream.fetch({
                    method: 'POST',
                    url: url,
                    type: 'json',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(config.data)
                }, function (response) {
                    if (!response.ok) {
                        this.toast('网络出现问题!');

                        if (config.error) {
                            config.error(config.data);
                        }
                    } else {
                        if (response.data.code == 200) {
                            if (response.data.result) {
                                config.success(response.data.data);
                            } else {
                                this.toast(response.data.message);

                                // config.error();
                            }
                        } else {
                            this.toast(response.data.message);
                            this.isLoad = false;

                            // config.error();
                        }
                    }
                }.bind(this), function (response) {

                });
            });
		},
		refresh () {
			this.chuangshi.pageRefresh();
		}
	}
}