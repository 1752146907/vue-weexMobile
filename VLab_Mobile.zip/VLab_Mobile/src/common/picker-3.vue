<template>
    <div>
        <wxc-cell class="balance"
                  :has-top-border="true"
                  :has-bottom-border="true"
                  :has-arrow="true"
                  @wxcCellClicked="handleReviseCity">
            <div class="balance-cell"
                 slot="label">
                <div class="balance-cell-title">省/市/区：</div>
                <text class="balance-cell-address">{{memberAddressProvince}}{{memberAddressCity}}{{memberAddressArea}}</text>
            </div>
        </wxc-cell>

        <wx-popup
                :visible="visible"
                position="bottom"
                :hasOverley="true"
                height="488px"
                ref="wxPopup"
                @wxChange="handleBottom">
            <div>
                <div class="btn-wrap">
                    <text class="btn" @click="handleCancel">取消</text>
                    <text class="btn" @click="handleFinish">完成</text>
                </div>
                <div class="flex">
                    <wx-picker class="flex-1" :data="provins" :visible="visible" @wxChange="handleChangeProvin"></wx-picker>
                    <wx-picker class="flex-1" :data="citys" :visible="visible" @wxChange="handleChangeCity"></wx-picker>
                    <wx-picker class="flex-1" :data="areas" :visible="visible" @wxChange="handleChangeArea"></wx-picker>
                </div>
            </div>
        </wx-popup>
    </div>
</template>

<style scoped>
    .wx-demo {
    }
    .flex {
        flex-direction: row;
    }
    .flex-1 {
        flex: 1;
    }
    .btn-wrap {
        background-color: #ccc;
        height: 88px;
        font-size: 38px;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }
    .btn {
        line-height: 88px;
        height: 88px;
        width: 100px;
        text-align: center;
        color: #007aff;
        font-size: 32px;
    }
    .balance{
        width: 750px;
        flex-direction: row;
        flex-wrap: wrap;
        background-color: #ffffff;
        padding: 24px;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
        border-bottom-style: solid;
    }
    .balance-label{
        width: 190px;
    }
    .balance-title{
        flex: 1;
    }
    .balance-title-input{
        flex: 1;
    }
    .balance-cell {
        flex-direction: row;
    }
    .balance-cell-title {
        width: 190px;
    }
</style>


<script>
    import { WxcCell } from 'weex-ui';
    import { WxPicker, WxButton, WxPopup } from 'weex-droplet-ui';
    import { provins, citys, areas } from './china';
    // import { provins, citys, areas } from 'weex-droplet-ui/example/picker/address';

    import mixin from './mixin';

    export default {
        components: {
            WxPicker,
            WxButton,
            WxPopup,
            WxcCell,
            provins,
            citys,
            areas
        },
        props: ['memberAddressProvince', 'memberAddressCity', 'memberAddressArea'],
        data: () => ({
            provins: {},
            citys: {},
            areas: {},
            address: [],
            visible: false
        }),
        created () {
            this.address = ['北京市', '北京市', '西城区'];
            this.initDefaultData();
        },
        mixins: [mixin],
        methods: {
            initDefaultData () {
                this.provins = {
                    list: provins,
                    defaultValue: this.address[0],
                    displayValue (name) {
                        return name;
                    }
                };
                this.citys = {
                    list: citys[this.address[0]],
                    defaultValue: this.address[1],
                    displayValue (name) {
                        return name;
                    }
                };
                this.areas = {
                    list: areas[this.address[1]],
                    defaultValue: this.address[2],
                    displayValue (name) {
                        return name;
                    }
                }
            },
            handleReviseCity() {
                this.visible = !this.visible;
            },
            handleBottom() {
                this.visible = !this.visible;
            },
            handleIsDefault() {
                this.memberAddressIsDefault = !this.memberAddressIsDefault
            },
            handleChangeProvin (provin) {
                this.provins = {
                    list: provins,
                    defaultValue: provin,
                    displayValue (name) {
                        return name;
                    }
                };
                this.citys = {
                    list: citys[provin],
                    defaultValue: citys[provin][0],
                    displayValue (name) {
                        return name;
                    }
                };
                this.areas = {
                    list: areas[citys[provin][0]],
                    defaultValue: areas[citys[provin][0]][0],
                    displayValue (name) {
                        return name;
                    }
                };
                this.address = [];
                this.address.push(provin);
                this.address.push(citys[provin][0]);
                this.address.push(areas[citys[provin][0]][0]);
            },
            handleChangeCity(city) {
                this.address[1] = city;
                this.address[2] = areas[city][0];
                this.areas = {
                    list: areas[city],
                    defaultValue: areas[city][0],
                    displayValue (name) {
                        return name;
                    }
                };
            },
            handleChangeArea(area) {
                this.address[2] = area;
            },
            handleReviseCity() {
                this.visible = true;
            },
            handleFinish () {
                this.$refs.wxPopup.hide(() => {
                    if (this.platform != 'web') {
                        this.chuangshi.sendEventListener({
                            name: 'handleSelectAddress',
                            data: {
                                memberAddressProvince: this.address[0],
                                memberAddressCity: this.address[1],
                                memberAddressArea: this.address[2]
                            }
                        });
                    }
                    this.initDefaultData();
                });
            },
            handleCancel () {
                this.$refs.wxPopup.hide(() => {
                    // this.visible = false;
                    this.initDefaultData();
                });
            }
        }
    }
</script>