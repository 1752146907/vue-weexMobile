const expressCode = [
  {
    label: '顺丰速运',
    value: 'shunfeng'
  },
  {
    label: '天天快递',
    value: 'tiantian'
  },
  {
    label: '申通快递',
    value: 'shentong'
  },
  {
    label: '韵达快递',
    value: 'yunda'
  },
  {
    label: '圆通速递',
    value: 'yuantong'
  },
  {
    label: '中通快递',
    value: 'zhongtong'
  },
  {
    label: '德邦快递',
    value: 'debangwuliu'
  },
  {
    label: '优速物流',
    value: 'youshuwuliu'
  },
  {
    label: '百世快递',
    value: 'huitongkuaidi'
  },
  {
    label: 'EMS',
    value: 'ems'
  },
  {
    label: '京东物流',
    value: 'jd'
  },
  {
    label: '宅急送',
    value: 'zhaijisong'
  },
  {
    label: 'TNT快递',
    value: 'tnt'
  }
];

module.exports = expressCode;