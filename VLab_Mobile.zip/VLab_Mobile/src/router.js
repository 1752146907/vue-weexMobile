/* global Vue */
import Vue from 'vue';
import Router from 'vue-router';

import Index from './view/index';
import HomeIndex from './view/home/index';
import OrderCheck from './view/order/purchaseCheck';
import BalanceIndex from './view/my/balance';
import Bill from './view/my/bill/index';
import OrderWarehouseReplace from './view/order/warehouseReplace';
import OrderSlefReplace from './view/order/slefReplace';
import OrderDeliveryIndex from './view/order/deliveryIndex';
import OrderDeliveryDetail from './view/order/deliveryDetail';
import OrderIndex from './view/order/purchaseIndex';
import OrderDateil from './view/order/purchaseDetail';
import OrderRetailCheck from './view/order/retailCheck';
import OrderRetailDetail from './view/order/retailDetail';
import OrderRetailIndex from './view/order/retailIndex';
import BankCardIndex from './view/my/bankCard/index';
import BankCardAddCard from './view/my/bankCard/addCard';
import BankCardDetail from './view/my/bankCard/detail';
import DeliveryIndex from './view/my/delivery/index';
import DeliveryDetail from './view/my/delivery/detail';
import addDelivery from './view/my/delivery/addDelivery';
import TeamDetail from './view/my/team/detail';
import QrcodeIndex from './view/my/qrcode/index';
import OtherPage from './view/circle/otherPage';
import HomePage from './view/circle/homePage';
import Publish from './view/circle/publish';
import CircleDetail from './view/circle/detail';
import DynamicDetail from './view/dynamic/detail';
import Dynamic from './view/dynamic/index';
import ChannelProduct from './view/channel/product';
import ChannelRetailProduct from './view/channel/retailProduct';
import MyEvaluate from './view/my/evaluate';





Vue.use(Router);

module.exports = new Router({
  routes: [{
	  path: '/',
	  component: Index
  }, {
	  path: '/home/index',
	  component: HomeIndex
  }, {
      path: '/order/purchaseCheck',
      component: OrderCheck
  }, {
      path: '/my/balance',
      component: BalanceIndex
  }, {
      path: '/my/bill/index',
      component: Bill
  }, {
      path: '/order/warehouseReplace',
      component: OrderWarehouseReplace
  },  {
      path: '/order/slefReplace',
      component: OrderSlefReplace
  },  {
      path: '/order/deliveryIndex',
      component: OrderDeliveryIndex
  },  {
      path: '/order/deliveryDetail',
      component: OrderDeliveryDetail
  }, {
      path: '/order/purchaseIndex',
      component: OrderIndex
  }, {
      path: '/order/purchaseDetail',
      component: OrderDateil
  }, {
      path: '/order/retailCheck',
      component: OrderRetailCheck
  }, {
      path: '/order/retailDetail',
      component: OrderRetailDetail
  }, {
      path: '/order/retailIndex',
      component: OrderRetailIndex
  }, {
      name: BankCardIndex,
      path: '/my/bankCard/index',
      component: BankCardIndex
  }, {
      path: '/my/bankCard/addCard',
      component: BankCardAddCard
  }, {
      path: '/my/bankCard/detail',
      component: BankCardDetail
  }, {
      path: '/my/delivery/index',
      component: DeliveryIndex
  }, {
      path: '/my/delivery/detail',
      component: DeliveryDetail
  }, {
      path: '/my/delivery/addDelivery',
      component: addDelivery
  }, {
      path: '/my/team/detail',
      component: TeamDetail
  }, {
      path: '/my/qrcode/index',
      component: QrcodeIndex
  }, {
      path: '/circle/homePage',
      component: HomePage
  }, {
      path: '/circle/otherPage',
      component: OtherPage
  }, {
      path: '/circle/publish',
      component: Publish
  }, {
      path: '/circle/detail',
      component: CircleDetail
  }, {
      path: '/dynamic/detail',
      component: DynamicDetail
  }, {
      path: '/dynamic/index',
      component: Dynamic
  }, {
      path: '/channel/product',
      component: ChannelProduct
  }, {
      path: '/channel/retailProduct',
      component: ChannelRetailProduct
  }, {
      path: '/my/evaluate',
      component: MyEvaluate
  }
  ]
});

