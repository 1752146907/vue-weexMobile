<template>
	<div v-if="platform == 'web'"
		 v-html="inner"></div>
	<div v-else
		 :style="{width: '750px'}">
		<text :style="item.style" v-for="item in templateArr" v-if="!item.img">
			{{item.content}}
		</text>
		<image resize="cover" v-else :style="{width: item.img.width + 'px', height: item.img.height + 'px'}"
			   :src="item.img.src"></image>
	</div>
</template>

<script>
	export default {
		props: {
			inner: {
				default: ""
			},
			globalEvent: {},
			chuangshi: {},
			platform: {}
		},
		data: () => ({
			templateArr: []
		}),
		mounted () {
			if (this.platform != 'web') {
				this.templateArr = this.transform(this.inner);

				this.globalEvent.addEventListener('getImageInfo', (data) => {
					var templateArr = this.templateArr;
					for (var i = 0; i < templateArr.length; i++) {
						if (templateArr[i].img.src == data.url) {
							templateArr[i].img.height = data.height / data.width * 750;
						}
					}
					// this.templateArr = templateArr;
				});
			}
		},
		methods: {
			transform: function (html) {
				var arr = html.match(/<div.*?>(.*?)<.*?\/div>/g);
				if (!arr || !arr.length) return;
				var templateArr = [];
				for (var i = 0; i < arr.length; i++) {
					var obj = {
						content: '',
						style: {},
						img: false
					};
					//处理外层p的align
					if (/<div.*align="(\w+)".*>/.test(arr[i])) {
						obj.style.textAlign = /<div.*?align="(\w+)".*?>/.exec(arr[i])[1];
					}
					var inner = /<div.*?>(.*)<\/div>/.exec(arr[i])[1];
					if (!inner.length) continue;
					if (/<img.*?\/>/.test(inner)) {
						//处理图
						var url = /src="(.+?)"/.exec(inner)[1];
						obj.img = true;
						obj.img = {
							src: url,
							width: 750,
							height: 0
						};

						this.chuangshi.getImageInfo(url);
					}
					else {
						// if (/<strong.*?>(.*)<\/strong>/.test(inner)) {
						// 	obj.style.fontWeight = 'bold';
						// 	obj.content = contentHandler(/<strong.*?>(.*)<\/strong>/.exec(inner)[1]);
						// } else {
						// 	obj.content = contentHandler(inner);
						// }
					}
					templateArr.push(obj);
				}
				return templateArr;

				function contentHandler (str) {
					var str2 = str.replace(/&nbsp;/g, '');
					return str2.replace(/<.*?>/g, '');
				}
			}
		}
	}
</script>