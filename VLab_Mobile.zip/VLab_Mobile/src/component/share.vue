<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">

        <div class="no-data"
             v-if="teamList.length == 0 && notData">
            <image class="no-data-img"
                   src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/empty.png"></image>
            <text class="no-data-text">当前没有数据</text>
        </div>

        <div v-for="(item, index) in teamList"
             :key="index"
             v-if="teamList.length > 0">
            <wxc-cell class="team-cell"
                      :has-top-border="true">
                <div class="team-cell-content"
                     slot="label">
                    <image class="team-cell-content-avatar"
                           :src="imageHost + item.memberAvatarPath"></image>
                    <div class="team-cell-content-label">
                        <div class="team-cell-content-title">{{item.memberNickName}}</div>
                        <div class="team-cell-content-desc">{{item.systemCreateTime}}</div>
                    </div>
                </div>
                <div class="addChildren" @click="handleClickOpen(item.memberId, index)">
                    <image class="addChildren-img"
                           v-if="item.memberIsShowChildren"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>
                    <image class="addChildren-img"
                           v-if="!item.memberIsShowChildren"
                           src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>
                    <text class="addChildren-img-badge">{{item.countOfChildren}}</text>
                </div>
            </wxc-cell>
            <div class="children-cell"
                 v-if="!item.memberIsShowChildren">
                <wxc-cell class="team-children-cell"
                          :has-top-border="false"
                          :has-bottom-border="true"
                          v-for="itemChildren in item.children"
                          :key="itemChildren.systemCreateTime">
                    <div class="team-cell-content"
                         slot="label">
                        <image class="team-cell-content-avatar"
                               :src="imageHost + itemChildren.memberAvatarPath"></image>
                        <div class="team-cell-content-label">
                            <div class="team-cell-content-title">{{itemChildren.memberNickName}}</div>
                            <div class="team-cell-content-desc">{{itemChildren.systemCreateTime}}</div>
                        </div>
                    </div>
                    <!--<div class="addChildren">-->
                    <!--<image class="addChildren-img" src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/push.png"></image>-->
                    <!--<image class="addChildren-img" src="http://h5.chuangshi.nowui.com/rongzhi/xingxiao/webMobile/pull.png"></image>-->
                    <!--<div class="addChildren-img-badge">1</div>-->
                    <!--</div>-->
                </wxc-cell>
            </div>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell} from 'weex-ui';

    import mixin from '../common/mixin';

    export default {
        components: {
            WxcCell
        },
        mixins: [mixin],
        props: {

        },
        data: () => ({
            isSelectMemberId: '',
            teamList: [],
            notData: false,
            memberIsShowChildren: '',
            isShowChildren: true
        }),
        created () {

        },
        mounted () {
            this.changeTitle('我的分享');
            this.storage.getItem(this.token, (res) => {
                if (res.result === 'success') {
                    this.handleLoad();
                }
            })
        },
        methods: {
            handleLoad() {
                this.request({
                    url: '/xingxiao/member/mobile/v1/my/subordinates',
                    data: {},
                    success: (data) => {
                        if(data.length > 0){
                            for(var i = 0; i < data.length; i++){
                                data[i].memberIsShowChildren = false;
                                data[i].systemCreateTime = this.timestampToTime(data[i].systemCreateTime)
                                if(data[i].children.length > 0){
                                    for(var j = 0; j < data[i].children.length; j++){
                                        data[i].children[j].systemCreateTime = this.timestampToTime(data[i].children[j].systemCreateTime)
                                    }
                                }
                            }
                        }
                        this.teamList = data;
                        this.notData = true;
                    }
                });
            },
            handleClickOpen(memberId, index) {
                this.teamList[index].memberIsShowChildren = !this.teamList[index].memberIsShowChildren;
            },
            timestampToTime(timestamp) {
                var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                var Y = date.getFullYear() + '-';
                var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
                var D = date.getDate() + ' ';
                return Y + M + D;
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        position: relative;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .no-data {
        position: absolute;
        top: 400px;
        left: 315px;
        width: 200px;
        height: 200px;
    }
    .no-data-img {
        width: 120px;
        height: 120px;
    }
    .no-data-text {
        margin-top: 20px;
        margin-left: -32px;
        width: 220px;
        height: 40px;
        color: #888;
        font-size: 32px;
    }

    .team-cell {
        width: 750px;
        margin-top: 20px;
    }
    .team-cell-content {
        flex-direction: row;
    }
    .team-cell-content-avatar {
        width: 100px;
        height: 100px;
    }
    .team-cell-content-label {
        margin-left: 20px;
        padding-top: 10px;
    }
    .team-cell-content-desc {
        color: #999999;
        font-size: 30px;
        margin-top: 8px;
    }
    .addChildren {
        position: relative;
    }
    .addChildren-img {
        width: 80px;
        height: 80px;
    }
    .addChildren-img-badge {
        display:inline-block;
        padding: 4px 10px;
        min-width: 16px;
        border-radius: 28px;
        background-color: #E64340;
        color: #FFFFFF;
        line-height: 20px;
        text-align: center;
        font-size: 24px;
        position: absolute;
        top: 0px;
        right: 0px;
    }
    .children-cell {
        border: none;
    }
    .team-children-cell {
        width: 750px;
        padding: 20px 20px 20px 60px !important;
    }

</style>
