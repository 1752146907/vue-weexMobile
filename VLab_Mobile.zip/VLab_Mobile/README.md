# weex + vue 框架搭建的移动端平台

# 项目名称：星销---薇佳实验室APP

# 创建时间：2017年5月28日

# 注意：克隆文件时src/entry.js、src/router.js两个文件缺省，要重新拷贝