<template>
  <router-view/>
</template>

<script>
  export default {
    components: {},
    data () {
      return {}
    }
  }
</script>

<style scoped>

</style>
