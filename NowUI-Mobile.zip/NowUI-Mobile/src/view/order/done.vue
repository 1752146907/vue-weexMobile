<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--已完成-->
        <!--<wxc-minibar title="已完成订单"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <div class="order-item" v-for="item in orderList">
            <wxc-cell class="order-item-title"
                      :has-arrow="false"
                      :has-margin="false">
                <text class="order-identifier"
                      slot="label">订单编号</text>
                <text class="order-number"
                      slot="title">{{item.customerProviderCode}}</text>
            </wxc-cell>
            <!--<div class="order-commodity-item">-->
                <!--<wxc-cell :has-arrow="false"-->
                          <!--:has-top-border="false"-->
                          <!--:has-margin="false"-->
                          <!--:has-bottom-border="false"-->
                          <!--:style="{backgroundColor:'#ffffff'}">-->
                    <!--<text class="order-commodity-item-name"-->
                          <!--slot="label">拿铁</text>-->
                    <!--<text class="order-commodity-item-number"-->
                          <!--slot="title">1</text>-->
                <!--</wxc-cell>-->
                <!--<wxc-cell :has-arrow="false"-->
                          <!--:has-top-border="false"-->
                          <!--:has-margin="false"-->
                          <!--:has-bottom-border="false"-->
                          <!--:style="{backgroundColor:'#ffffff'}">-->
                    <!--<text class="order-commodity-item-name"-->
                          <!--slot="label">蛋糕</text>-->
                    <!--<text class="order-commodity-item-number"-->
                          <!--slot="title">2</text>-->
                <!--</wxc-cell>-->
            <!--</div>-->
            <wxc-cell
                    class="order-item-title"
                    :has-arrow="false"
                    :has-top-border="true"
                    :has-margin="false">
                <text class="order-label"
                      slot="label">门店名称</text>
                <text class="order-content"
                      slot="title">{{item.distributionOrderProviderName}}</text>
            </wxc-cell>
            <wxc-cell
                    class="order-item-title"
                    :has-arrow="false"
                    :has-margin="false">
                <text class="order-label"
                      slot="label">门店地址</text>
                <text class="order-content"
                      slot="title">{{item.distributionOrderProviderAddress}}</text>
            </wxc-cell>
            <wxc-cell
                    class="order-item-title"
                    :has-arrow="false"
                    :has-margin="false">
                <text class="order-label"
                      slot="label">门店联系人电话</text>
                <text class="order-content"
                      slot="title">{{item.distributionOrderProviderPhone}}</text>
            </wxc-cell>
            <wxc-cell
                    class="order-item-title"
                    :has-arrow="false"
                    :has-margin="false">
                <text class="order-label"
                      slot="label">收件人</text>
                <text class="order-content"
                      slot="title">{{item.distributionOrderCustomerName}}</text>
            </wxc-cell>
            <wxc-cell
                    class="order-item-title"
                    :has-arrow="false"
                    :has-margin="false">
                <text class="order-label"
                      slot="label">收货人地址</text>
                <text class="order-content"
                      slot="title">{{item.distributionOrderDeliveryAddress}}</text>
            </wxc-cell>
            <wxc-cell
                    class="order-item-title"
                    :has-arrow="false"
                    :has-margin="false">
                <text class="order-label"
                      slot="label">联系电话</text>
                <text class="order-content"
                      slot="title">{{item.distributionOrderCustomerPhone}}</text>
            </wxc-cell>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell, WxcMinibar} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcMinibar
        },
        mixins: [mixin],
        data: () => ({
            orderList:[]
        }),
        created() {
            this.request({
                url: '/distribution/order/mobile/v1/list',
                data: {
                    riderId: this.getRiderId(),
                    distributionOrderStatus: "FINISHED",
                    pageIndex: 1,
                    pageSize: 10
                },
                success: (data) => {
                    this.orderList = data.list;
                },
                error: () => {
                    // this.isLoad = false;
                }
            });
        },
        mounted() {
			this.changeTitle('已完成订单');
        },
        methods: {
            getRiderId() {
                let riderId = '';
                this.storage.getItem('riderId', res => {
                    if(res.result === 'success'){
                        riderId = res.data;
                    }
                });

                return riderId;
            },
            handleClickBack () {
                this.pop();
            },
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

    .order-item{
        width: 750px;
        margin-top: 10px;
        padding-bottom: 50px;
        background-color: #f5f5f9;
    }

    .order-item-title{
        display: flex;
        font-size: 26px;
    }

    .order-identifier{
        width: 180px;
        font-size: 26px;
    }

    .order-number{
        width: 570px;
        font-size: 22px;
    }


    .order-commodity-item{
        background-color: #f2f2f2;
    }

    .order-commodity-item-name{
        width: 100px;
        font-size: 28px;
        font-weight: bold;
    }

    .order-commodity-item-number{
        width: 600px;
        font-size: 28px;
        color: #999999;
        text-align: left;
        font-weight: bold;
    }

    .order-label{
        width: 200px;
        font-size: 26px;
    }

    .order-content{
        width: 500px;
        font-size: 26px;
    }

</style>
