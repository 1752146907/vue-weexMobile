<template>
	<scroller class="wrapper"
			  :style="{height: pageHeight + 'px'}">
		<!--<wxc-minibar title="首页"-->
		<!--background-color="#fecd39"-->
		<!--text-color="#ffffff"-->
		<!--:use-default-return="false"-->
		<!--right-text="刷新"-->
		<!--@wxcMinibarRightButtonClicked="handleClickRefresh">-->
		<!--<div slot="left"></div>-->
		<!--</wxc-minibar>-->
		<div class="order">
			<div class="order-item order-item-bottom-solid order-item-right-solid"
				 @click="handleClickWait">
				<image class="order-item-icon-0"
					   src="http://h5.chuangshi.nowui.com/jibai/wait.png"
					   resize="cover"></image>
				<text class="order-item-text">待取餐（112）</text>
			</div>
			<div class="order-item order-item-bottom-solid"
				 @click="handleClickDistribution">
				<image class="order-item-icon-1"
					   src="http://h5.chuangshi.nowui.com/jibai/distribution.png"
					   resize="cover"></image>
				<text class="order-item-text">配送中（9）</text>
			</div>
		</div>
		<div class="order"
			 @click="handleClickDone">
			<div class="order-item order-item-bottom-solid order-item-right-solid">
				<image class="order-item-icon-2"
					   src="http://h5.chuangshi.nowui.com/jibai/done.png"
					   resize="cover"></image>
				<text class="order-item-text">已完成（21）</text>
			</div>
			<div class="order-item order-item-bottom-solid"
				 @click="handleClickCancal">
				<image class="order-item-icon-3"
					   src="http://h5.chuangshi.nowui.com/jibai/cancel.png"
					   resize="cover"></image>
				<text class="order-item-text">已取消（3）</text>
			</div>
		</div>

		<div class="button">
			<!--<wxc-button :textStyle="{color: '#000000', fontSize: '32px'}"-->
						<!--text="上班"-->
						<!--@wxcButtonClicked="handleClickWork"-->
						<!--type="yellow"-->
						<!--v-if="inWork"></wxc-button>-->
			<!--<wxc-button :textStyle="{color: '#000000', fontSize: '32px'}"-->
						<!--text="下班"-->
						<!--@wxcButtonClicked="handleClickOffWork"-->
						<!--type="yellow"-->
						<!--v-if="!inWork"></wxc-button>-->
			<wxc-cell :has-arrow="false"
					  :has-top-border="true"
					  :auto-accessible="false">
				<text slot="title">是否上班</text>
				<switch slot="value"
						@change="color= color==='#000' ? '#FFC900' : '#000'"></switch>
			</wxc-cell>
		</div>
	</scroller>
</template>

<script>
	import {WxcCell, WxcButton, WxcMinibar, WxcLoading} from 'weex-ui';

	import mixin from '../../common/mixin';

	export default {
		components: {
			WxcMinibar,
			WxcCell,
			WxcButton,
			WxcLoading
		},
		mixins: [mixin],
		data: () => ({
			inWork: true,
			isLoad: false,
			isRefresh: true
		}),
		mounted () {

		},
		methods: {
			getRiderId () {
				let riderId = '';
				this.storage.getItem('riderId', res => {
					if (res.result === 'success') {
						riderId = res.data;
					}
				});
				return riderId;
			},
			handleClickWork () {
				this.isLoad = true;
				this.request({
					url: '/rider/mobile/v1/inWork',
					data: {
						riderId: this.getRiderId(),
						systemRequestUserId: this.getRiderId()
					},
					success: (data) => {
						this.isLoad = false;
						this.inWork = false
					},
					error: (data) => {
						this.isLoad = false;
					}
				});
			},
			handleClickOffWork () {
				this.isLoad = true;
				this.request({
					url: '/rider/mobile/v1/outWork',
					data: {
						riderId: this.getRiderId(),
						systemRequestUserId: this.getRiderId()
					},
					success: (data) => {
						this.isLoad = false;
						this.inWork = true
					},
					error: (data) => {
						this.isLoad = false;
					}
				});
			},
			handleClickWait () {
				this.push('/order/wait');
			},
			handleClickDistribution () {
				this.push('/order/distribution');
			},
			handleClickCancal () {
				this.push('/order/cancal');
			},
			handleClickDone () {
				this.push('/order/done');
			},
			handleClickRefresh () {
				this.refresh();
			}
		}
	}
</script>

<style scoped>
	.wrapper {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}

	.order {
		flex-direction: row;
		flex-wrap: wrap;
		background-color: #ffffff;
	}

	.order-item {
		width: 375px;
		height: 220px;
		align-items: center;
		justify-content: center;
	}

	.order-item-bottom-solid {
		border-bottom-width: 1px;
		border-bottom-color: #d9d9d9;
	}

	.order-item-right-solid {
		border-right-width: 1px;
		border-right-color: #d9d9d9;
	}

	.order-item-icon-0 {
		width: 65px;
		height: 65px;
		margin-bottom: 30px;
	}

	.order-item-icon-1 {
		width: 82px;
		height: 82px;
		margin-bottom: 30px;
	}

	.order-item-icon-2 {
		width: 65px;
		height: 65px;
		margin-bottom: 30px;
	}

	.order-item-icon-3 {
		width: 65px;
		height: 65px;
		margin-bottom: 30px;
	}

	.order-item-text {
		color: #000000;
		font-size: 32px;
	}

	.button {
		width: 750px;
		margin-top: 40px;
	}

	.button-in-work {
		color: #000000;
	}

	.button-out-work {
		color: #000000;
	}
</style>
