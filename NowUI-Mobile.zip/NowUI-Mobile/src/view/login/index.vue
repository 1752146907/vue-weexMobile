<template>
    <scroller class="wrapper"
              :style="{height: pageHeight + 'px'}">
        <!--<wxc-minibar title="登录"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <image class="banner"
               src="http://h5.chuangshi.nowui.com/rongzhi/images/meigou.png"></image>
        <div class="main">
            <wxc-cell :has-arrow="false"
                      class="label-box"
                      :has-margin="false">
                <text class="login-label"
                      slot="label">账号</text>
                <input type="number"
                       placeholder="请输入账号"
                       class="login-input"
                       slot="title"
                       v-model="author"
                       value="" />
            </wxc-cell>
            <wxc-cell :has-arrow="false"
                      class="label-box"
                      :has-margin="false">
                <text class="login-label"
                      slot="label">密码</text>
                <input type="password"
                       placeholder="请输入密码"
                       class="login-input"
                       v-model="userPassword"
                       slot="title"
                       value="" />
            </wxc-cell>
            <wxc-button text="登录"
                        class="login-submit"
                        :btnStyle="{backgroundColor: '#fecd39',width: '670px'}"
                        :textStyle="{fontSize: '28px', color: '#000000'}"
                        @wxcButtonClicked="handleSubmit"></wxc-button>
            <div class="other-link">
                <text class="register"
                      @click="handleRegister">注册</text>
                <text class="back-password"
                      @click="handlePassword">找回密码</text>
            </div>
        </div>

        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcButton, WxcMinibar, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcMinibar,
            WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            author: '',
            userPassword: '',
            isLoad: false
        }),
        mounted() {
			this.changeTitle('用户登录');
        },
        methods: {
            handleClickBack () {
                this.pop();
            },
            handleRegister () {
                this.push('/login/register');
            },
            handlePassword () {
                this.push('/login/password');
            },

            handleSubmit() {
                if (this.author == '') {
                    this.toast('手机号码不能为空');

                    return;
                }
                if (this.userPassword == '') {
                    this.toast('密码不能为空');

                    return;
                }

                this.isLoad = true;

                this.request({
                    url: '/rider/mobile/v1/login',
                    data: {
                        riderPhone: this.author,
                        riderPassword: this.userPassword
                    },
                    success: (data) => {
						this.storage.setItem('riderId', data.riderId, res => {
							if(res.result === 'success'){
								this.isLoad = false;

								this.login();

								this.toast('登录成功', () => {
									this.pushRoot('/index');
								});
							}
						});
                    },
                    error: () => {
                        this.isLoad = false;
                    }
                });
            }
        }
    }
</script>

<style scoped>
    .wrapper {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

    .banner{
        width:360px;
        height:120px;
        margin-top: 80px;
        margin-bottom: 60px;
        margin-left: 210px;
        opacity: 0.9;
    }

    .main{
        padding-left: 40px;
        padding-right: 40px;
    }

    .label-box{
        width: 670px;
    }

    .login-label{
        width: 130px;
        font-size: 29px;
    }

    .login-input{
        width: 510px;
        height: 60px;
        font-size: 28px;
    }

    .login-submit{
        width: 670px;
        margin-top: 100px;
        color: #ffffff;
        font-size: 30px;
        text-align: center;
        padding-top: 20px;
        padding-bottom: 20px;
        border-radius: 6px;
    }

    .other-link{
        width: 670px;
        margin-top: 20px;
        display: flex;
        align-content: space-around;
        flex-direction: row
    }

    .register{
        width: 335px;
        height: 60px;
        font-size: 28px;
        color: #666666;
    }

    .back-password{
        width: 335px;
        height: 60px;
        font-size: 28px;
        color: #666666;
        text-align: right;
        padding-right: 0px;
    }
</style>
