<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <wxc-cell class="cell"
                  :has-arrow="false"
                  :has-margin="false">
            <text class="password-label"
                  slot="label">账号
            </text>
            <input type="number"
                   slot="title"
                   v-model="phone"
                   placeholder="请输入账号"
                   class="password-input"
                   value=""/>
        </wxc-cell>
        <wxc-cell class="cell"
                  :has-arrow="false"
                  :has-margin="false">
            <text class="password-label"
                  slot="label">验证码
            </text>
            <input type="number"
                   slot="title"
                   v-model="captchaCode"
                   placeholder="请输入验证码"
                   class="code-input"
                   value=""/>
            <text v-if="countDown < 120"
                  class="obtain-code">{{"获取验证码(" + countDown + "s)"}}
            </text>
            <!--<wxc-button text="获取验证码"-->
                        <!--v-else-if="countDown == 120"-->
                        <!--class="obtain-code"-->
                        <!--:btnStyle="{backgroundColor: '#fecd39'}"-->
                        <!--:textStyle="{fontSize: '26px'}"-->
                        <!--@wxcButtonClicked="handleGetCode"></wxc-button>-->
            <text class="obtain-code"
                    @click="handleGetCode"
                    v-else-if="countDown == 120"
                    slot="value">获取验证码</text>
        </wxc-cell>
        <wxc-cell class="cell"
                  :has-arrow="false"
                  :has-margin="false">
            <text class="password-label"
                  slot="label">新密码
            </text>
            <input type="password"
                   v-model="newPassword"
                   placeholder="请输入密码"
                   class="password-input"
                   slot="title"
                   value=""/>
        </wxc-cell>
        <wxc-cell class="cell"
                  :has-arrow="false"
                  :has-margin="false">
            <text class="password-label"
                  slot="label">确认密码
            </text>
            <input type="password"
                   v-model="confirmPassword"
                   placeholder="请输入密码"
                   class="password-input"
                   slot="title"
                   value=""/>
        </wxc-cell>
        <wxc-button text="提交"
                    class="password-submit"
                    :btnStyle="{backgroundColor: '#fecd39'}"
                    :textStyle="{fontSize: '28px', color: '#000000'}"
                    @wxcButtonClicked="handleSubmit"></wxc-button>
        <wxc-loading :show="isLoad" type="default"></wxc-loading>
    </scroller>
</template>

<script>
    import {WxcCell, WxcButton, WxcLoading} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcButton,
			WxcLoading
        },
        mixins: [mixin],
        data: () => ({
            phone: '',
            captchaCode: '',
            newPassword: '',
            confirmPassword: '',
            countDown: 120,
			isLoad: false
        }),
        mounted() {
			this.changeTitle('忘记密码');
        },
        methods: {
            handleClickBack () {
                this.pop();
            },
            setTime() {
                var time = setInterval(function () {
                    if (this.countDown > 0) {
                        this.countDown--;
                    } else {
                        clearInterval(time);
                        this.countDown = 120;
                    }
                }.bind(this), 1000);
            },
            handleGetCode() {
                var myPhone = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
                if (!myPhone.test(this.phone)) {
                    this.toast('输入的手机号不合法');
                    return;
                }

                this.isLoad = true;

                this.request({
                    url: '/rider/mobile/v1/getCaptcha',
                    data: {
                        phone: this.phone
                    },
                    success: (data) => {
						this.isLoad = false;

                        this.toast('发送成功');

                        this.setTime();

                    },
                    error: (data) => {
                        this.isLoad = false;

                        this.toast('发送失败')
                    }
                });
            },
            handleSubmit() {
                if (this.phone == '') {
                    this.toast('手机号不能为空');
                    return;
                }
                if (this.captchaCode == '') {
                    this.toast('验证码不能为空');
                    return;
                }
                if (this.newPassword == '') {
                    this.toast('新密码不能为空');
                    return;
                }
                if (this.newPassword != this.confirmPassword) {
                    this.toast('密码不一致');
                    return;
                }

				this.isLoad = true;

                this.request({
                    url: '/rider/mobile/v1/updatePassword',
                    data: {
                        phone: this.phone,
                        captchaCode: this.captchaCode,
                        password: this.newPassword
                    },
                    success: (data) => {
						this.isLoad = false;

                    	console.log(data);
                        this.toast('修改成功', () => {
                        	this.pop();
                        });
                    },
                    error: () => {
                        this.isLoad = false;

                        this.toast('修改发送失败')
                    }
                });
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .cell {
        width: 750px;
        height: 120px;
    }

    .password-label {
        width: 160px;
        height: 40px;
        font-size: 28px;
    }

    .password-input {
        width: 540px;
        height: 60px;
        font-size: 28px;
    }

    .code-input {
        width: 340px;
        height: 60px;
        font-size: 28px;
    }

    .obtain-code {
        width: 200px;
        height: 80px;
        border-radius: 4px;
        line-height: 80px;
        background-color: #fecd39;
        color: #000000;
        font-size: 22px;
        text-align: center;
    }

    .password-submit {
        width: 710px;
        margin-left: 20px;
        margin-top: 100px;
        background-color: #fecd39;
        color: #ffffff;
        font-size: 30px;
        text-align: center;
        padding-top: 20px;
        padding-bottom: 20px;
        border-radius: 6px;
    }
</style>
