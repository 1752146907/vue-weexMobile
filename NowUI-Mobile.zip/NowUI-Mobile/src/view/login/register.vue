<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<wxc-cell class="title"
				  title="基础信息"
				  :has-arrow="false"
				  :has-top-border="true"></wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">姓名
			</text>
			<input type="text"
				   slot="title"
				   v-model="riderName"
				   placeholder="请输入姓名"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickSex">
			<text class="register-label"
				  slot="label">性别
			</text>
			<text class="register-label"
				  slot="title"></text>
			<text class="desc"
				  slot="value"
				  v-if="riderGender==''">请选择性别
			</text>
			<text class="desc"
				  slot="value"
				  v-if="riderGender!=''">{{riderGender}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">年龄
			</text>
			<input type="number"
				   placeholder="请输入年龄"
				   class="register-input"
				   slot="title"
				   v-model="riderAge"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">手机号
			</text>
			<input type="number"
				   slot="title"
				   v-model="riderPhone"
				   placeholder="请输入手机号"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">密码
			</text>
			<input type="number"
				   slot="title"
				   v-model="riderPassword"
				   placeholder="请输入登录密码"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">身份证
			</text>
			<input type="number"
				   slot="title"
				   v-model="riderIdCard"
				   placeholder="请输入身份证"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickRiderLeve">
			<text class="register-label"
				  slot="label">骑手等级
			</text>
			<text class="desc"
				  slot="value"
				  v-if="riderLevelName==''">请选骑手等级
			</text>
			<text class="value"
				  slot="value"
				  v-if="riderLevelName!=''">{{riderLevelName}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickCompany">
			<text class="register-label"
				  slot="label">所属公司
			</text>
			<text class="desc"
				  slot="value"
				  v-if="companyName==''">请选所属公司
			</text>
			<text class="value"
				  slot="value"
				  v-if="companyName!=''">{{companyName}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickBranchCompany">
			<text class="register-label"
				  slot="label">所属分公司
			</text>
			<text class="desc"
				  slot="value"
				  v-if="branchCompanyName==''">请选所属分公司
			</text>
			<text class="value"
				  slot="value"
				  v-if="branchCompanyName!=''">{{branchCompanyName}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickSite">
			<text class="register-label"
				  slot="label">所属站点
			</text>
			<text class="desc"
				  slot="value"
				  v-if="siteName==''">请选所属站点
			</text>
			<text class="value"
				  slot="value"
				  v-if="siteName!=''">{{siteName}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">紧急联系人
			</text>
			<input type="text"
				   placeholder="请输入紧急联系人"
				   class="register-input"
				   slot="title"
				   v-model="riderEmergencyContact"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">紧急联系人电话
			</text>
			<input type="number"
				   slot="title"
				   v-model="riderEmergencyContactPhone"
				   placeholder="请输入紧急联系人电话"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">是否有保险
			</text>
			<switch @change="handleClickIsInsurance"
					slot="value"></switch>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">是否有健康证
			</text>
			<switch @change="handleClickIsHealthCertificate"
					slot="value"></switch>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">骑行速度
			</text>
			<input type="number"
				   slot="title"
				   v-model="riderSpeed"
				   placeholder="请输入骑行速度"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">是否全职
			</text>
			<switch @change="handleClickIsFullTime"
					slot="value"></switch>
		</wxc-cell>
		<wxc-cell class="title"
				  title="银行卡信息"
				  :has-arrow="false"
				  :has-top-border="false">
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">开户银行
			</text>
			<input type="text"
				   slot="title"
				   v-model="bankName"
				   placeholder="请输入开户银行"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">银行卡号
			</text>
			<input type="text"
				   slot="title"
				   v-model="bankCardNo"
				   placeholder="请输入银行卡号"
				   class="register-input"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">持卡人姓名
			</text>
			<input type="text"
				   v-model="bankCardHolder"
				   placeholder="请输入持卡人姓名"
				   class="register-input"
				   slot="title"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  title="开户行省份"
				  @wxcCellClicked="handleClickbankCardProvince">
			<text class="desc"
				  slot="value"
				  v-if="bankCardProvince==''">请选开户行省份
			</text>
			<text class="value"
				  slot="value"
				  v-if="bankCardProvince!=''">{{bankCardProvince}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  title="开户行城市"
				  @wxcCellClicked="handleClickCity">
			<text class="desc"
				  slot="value"
				  v-if="bankCardCity==''">请选开户行城市
			</text>
			<text class="value"
				  slot="value"
				  v-if="bankCardCity!=''">{{bankCardCity}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  title="开户行地区"
				  @wxcCellClicked="handleClickArea">
			<text class="desc"
				  slot="value"
				  v-if="bankCardArea==''">请选开户行地区
			</text>
			<text class="value"
				  slot="value"
				  v-if="bankCardArea!=''">{{bankCardArea}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-margin="false">
			<text class="register-label"
				  slot="label">开户行具体地址
			</text>
			<input type="text"
				   v-model="bankCardAddress"
				   placeholder="请输入开户行具体地址"
				   class="register-input"
				   slot="title"
				   value=""/>
		</wxc-cell>
		<wxc-cell class="title"
				  title="上传图片"
				  :has-arrow="false"
				  :has-top-border="false">
		</wxc-cell>
		<wxc-cell class="cell-image"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickIdCardFrontImage">
			<text class="register-label"
				  slot="label">身份证正面
			</text>
			<div class="register-image-desc"
				 slot="value"
				 v-if="siteName==''">
				<text class="desc">请上传身份证正面</text>
			</div>
			<image class="register-image"
				   slot="value"
				   v-if="siteName!=''"
				   :src="riderIdCardFrontImageFilePath"></image>
		</wxc-cell>
		<wxc-cell class="cell-image"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickIdCardFrontImage">
			<text class="register-label"
				  slot="label">身份证反面
			</text>
			<div class="register-image-desc"
				 slot="value"
				 v-if="siteName==''">
				<text class="desc">请上传身份证反面</text>
			</div>
			<image class="register-image"
				   slot="value"
				   v-if="siteName!=''"
				   :src="riderIdCardBackImageFilePath"></image>
		</wxc-cell>
		<wxc-cell class="cell-image"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickHoldIdCardImage">
			<text class="register-label"
				  slot="label">手持身份证照片
			</text>
			<div class="register-image-desc"
				 slot="value"
				 v-if="siteName==''">
				<text class="desc">请上传手持身份证照片</text>
			</div>
			<image class="register-image"
				   slot="value"
				   v-if="siteName!=''"
				   :src="riderHoldIdCardImageFilePath"></image>
		</wxc-cell>
		<wxc-cell class="cell-image"
				  :has-arrow="true"
				  :has-margin="false"
				  @wxcCellClicked="handleClickCertificateImage">
			<text class="register-label"
				  slot="label">健康证照片
			</text>
			<div class="register-image-desc"
				 slot="value"
				 v-if="siteName==''">
				<text class="desc">请上传健康证照片</text>
			</div>
			<image class="register-image"
				   slot="value"
				   v-if="siteName!=''"
				   :src="riderHealthCertificateImageFilePath"></image>
		</wxc-cell>
		<!--<wxc-cell :has-arrow="false"-->
		<!--:has-margin="false">-->
		<!--<text class="register-label"-->
		<!--slot="label">验证码-->
		<!--</text>-->
		<!--<input type="number"-->
		<!--slot="title"-->
		<!--placeholder="请输入验证码"-->
		<!--class="code-input"-->
		<!--value=""/>-->
		<!--<text class="obtain-code"-->
		<!--slot="value">获取验证码-->
		<!--</text>-->
		<!--</wxc-cell>-->
		<wxc-cell class="cell"
				  :has-arrow="false"
				  :has-bottom-border="false"
				  :has-margin="false"
				  @wxcCellClicked="handleClickAgreement">
			<wxc-checkbox slot="label"
						  :has-bottom-border="false"
						  :checked="isAgreement"></wxc-checkbox>
			<text class="agreement"
				  slot="title">已阅读并同意《骑手配送协议》
			</text>
		</wxc-cell>
		<wxc-button text="提交"
					class="from-submit"
					type="yellow"
					@wxcButtonClicked="handleSubmit"></wxc-button>
		<wxc-loading :show="isLoad" type="default"></wxc-loading>
	</scroller>
</template>

<script>
	import {WxcCell, WxcCheckbox, WxcButton, WxcLoading} from 'weex-ui';

	import mixin from '../../common/mixin';
	import china from '../../common/china';

	const picker = weex.requireModule('picker');

	export default {
		components: {
			WxcCell,
			WxcCheckbox,
			WxcButton,
			WxcLoading
		},
		mixins: [mixin],
		data: () => ({
			riderName: '',
			riderPhone: '',
			riderPassword: '',
			riderIdCard: '',
			riderGender: '',
			riderGenderList: ['男', '女'],
			riderAge: '',
			riderEmergencyContact: '',
			riderEmergencyContactPhone: '',
			riderIsInsurance: false,
			riderIsHealthCertificate: false,
			riderSpeed: '',
			riderIsFullTime: false,
			riderIdCardFrontImageFileId: '',
			riderIdCardFrontImageFilePath: '',
			riderIdCardBackImageFileId: '',
			riderIdCardBackImageFilePath: '',
			riderHoldIdCardImageFileId: '',
			riderHoldIdCardImageFilePath: '',
			riderHealthCertificateImageFileId: '',
			riderHealthCertificateImageFilePath: '',
			riderLevelId: '',
			riderLevelName: '',
			riderLevelList: [],
			riderLevelPickIndex: -1,
			riderLevelPickList: [],
			companyId: '',
			companyName: '',
			companyList: [],
			companyPickIndex: -1,
			companyPickList: [],
			branchCompanyId: '',
			branchCompanyName: '',
			branchCompanyList: [],
			branchCompanyPickIndex: -1,
			branchCompanyPickList: [],
			siteId: '',
			siteName: '',
			siteList: [],
			sitePickIndex: -1,
			sitePickList: [],
			bankName: '',
			bankCardNo: '',
			bankCardHolder: '',
			bankCardAddress: '',
			bankCardProvince: '',
			bankCardProvinceList: [],
			bankCardProvinceIndex: -1,
			bankCardCity: '',
			bankCardCityList: [],
			bankCardCityIndex: -1,
			bankCardArea: '',
			bankCardAreaList: [],
			bankCardAreaIndex: -1,
			isAgreement: false,
			isLoad: false
		}),
		mounted () {
			this.changeTitle('用户注册');

			var bankCardProvinceList = [];
			for (let i = 0; i < china.length; i++) {
				bankCardProvinceList.push(china[i].label);
			}
			this.bankCardProvinceList = bankCardProvinceList;

			this.handleListenerPickImageEvent();

			this.handleLoadCompany();

			this.handleLoadRiderLeve();
		},
		methods: {
			handleClickBack () {
				this.pop();
			},
			handleClickRefresh () {
				this.refresh();
			},
			handleListenerPickImageEvent () {
				this.globalEvent.addEventListener('pickImage', function (data) {
					let action = data.action;
					let base64Data = encodeURI(data.base64);

					this.request({
						url: this.imageHost + '/file/admin/v1/image/base64/upload',
						data: {
							base64Data: base64Data
						},
						success: (data) => {
							switch (action) {
								case 'rider-id-card-front-image':
									this.riderIdCardFrontImageFileId = data.fileId;
									this.riderIdCardFrontImageFilePath = this.imageHost + data.filePath;

									break;
								case 'rider-id-card-back-image':
									this.riderIdCardBackImageFileId = data.fileId;
									this.riderIdCardBackImageFilePath = this.imageHost + data.filePath;

									break;
								case 'rider-hold-id-card-image':
									this.riderHoldIdCardImageFileId = data.fileId;
									this.riderHoldIdCardImageFilePath = this.imageHost + data.filePath;

									break;
								case 'rider-health-certificate-image':
									this.riderHealthCertificateImageFileId = data.fileId;
									this.riderHealthCertificateImageFilePath = this.imageHost + data.filePath;

									break;
								default :
									break;
							}
							this.toast('上传成功')
						},
						error: () => {

						},
						complete: () => {

						}
					});
				}.bind(this));
			},
			handleLoadCompany () {
				this.request({
					url: '/company/mobile/v1/select',
					data: {},
					success: (data) => {
						this.companyList = data;

						let companyPickList = [];
						for (let item of data) {
							companyPickList.push(item.companyName);
						}
						this.companyPickList = companyPickList;
					},
					error: () => {

					},
					complete: () => {

					}
				});
			},
			handleClickCompany () {
				if (this.platform == 'web') {
					return;
				}

				picker.pick({
					index: this.companyPickIndex,
					items: this.companyPickList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.companyPickIndex == index) {
							return;
						}

						this.companyPickIndex = index;
						this.companyId = this.companyList[index].companyId;
						this.companyName = this.companyList[index].companyName;

						this.handleLoadBranchCompany(this.companyId);
					}
				});
			},
			handleLoadBranchCompany (companyId) {
				this.branchCompanyId = '';
				this.branchCompanyName = '';
				this.branchCompanyList = [];
				this.branchCompanyPickIndex = -1;
				this.branchCompanyPickList = [];

				this.siteId = '';
				this.siteName = '';
				this.siteList = [];
				this.sitePickIndex = -1;
				this.sitePickList = [];

				this.request({
					url: '/branch/company/mobile/v1/select',
					data: {
						companyId: companyId
					},
					success: (data) => {
						this.branchCompanyList = data;

						let branchCompanyPickList = [];
						for (let item of data) {
							branchCompanyPickList.push(item.branchCompanyName);
						}
						this.branchCompanyPickList = branchCompanyPickList;
					},
					error: () => {

					},
					complete: () => {

					}
				});
			},
			handleClickBranchCompany () {
				if (this.platform == 'web') {
					return;
				}

				picker.pick({
					index: this.branchCompanyPickIndex,
					items: this.branchCompanyPickList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.branchCompanyPickIndex == index) {
							return;
						}

						this.branchCompanyPickIndex = index;
						this.branchCompanyId = this.branchCompanyList[index].branchCompanyId;
						this.branchCompanyName = this.branchCompanyList[index].branchCompanyName;

						this.handleLoadSite(this.branchCompanyId);
					}
				});
			},
			handleLoadSite (branchCompanyId) {
				this.siteId = '';
				this.siteName = '';
				this.siteList = [];
				this.sitePickIndex = -1;
				this.sitePickList = [];

				this.request({
					url: '/site/mobile/v1/select',
					data: {
						branchCompanyId: branchCompanyId
					},
					success: (data) => {
						this.siteList = data;

						let sitePickList = [];
						for (let item of data) {
							sitePickList.push(item.siteName);
						}
						this.sitePickList = sitePickList;
					},
					error: () => {

					},
					complete: () => {

					}
				});
			},
			handleClickSite () {
				if (this.platform == 'web') {
					return;
				}

				picker.pick({
					index: this.sitePickIndex,
					items: this.sitePickList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.sitePickIndex == index) {
							return;
						}

						this.sitePickIndex = index;
						this.siteId = this.siteList[index].siteId;
						this.siteName = this.siteList[index].siteName;
					}
				});
			},
			handleLoadRiderLeve () {
				this.riderLevelId = '';
				this.riderLevelName = '';
				this.riderLevelList = [];
				this.riderLevelPickIndex = -1;
				this.riderLevelPickList = [];

				this.request({
					url: '/rider/level/mobile/v1/select',
					data: {},
					success: (data) => {
						this.riderLevelList = data;

						let riderLevelPickList = [];
						for (let item of data) {
							riderLevelPickList.push(item.riderLevelName);
						}
						this.riderLevelPickList = riderLevelPickList;
					},
					error: () => {

					},
					complete: () => {

					}
				});
			},
			handleClickRiderLeve () {
				if (this.platform == 'web') {
					return;
				}

				picker.pick({
					index: this.riderLevelPickIndex,
					items: this.riderLevelPickList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.riderLevelPickIndex == index) {
							return;
						}

						this.riderLevelPickIndex = index;
						this.riderLevelId = this.riderLevelList[index].riderLevelId;
						this.riderLevelName = this.riderLevelList[index].riderLevelName;
					}
				});
			},
			handleClickIdCardFrontImage () {
				weex.requireModule("event").openPhoto("rider-id-card-front-image");
			},
			handleClickIdCardFrontImage () {
				weex.requireModule("event").openPhoto("rider-id-card-back-image");
			},
			handleClickHoldIdCardImage () {
				weex.requireModule("event").openPhoto("rider-hold-id-card-image");
			},
			handleClickCertificateImage () {
				weex.requireModule("event").openPhoto("rider-health-certificate-image");
			},
			handleClickbankCardProvince () {
				if (this.platform == 'web') {
					return;
				}

				picker.pick({
					index: this.bankCardProvinceIndex,
					items: this.bankCardProvinceList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.bankCardProvinceIndex == index) {
							return;
						}

						this.bankCardCityIndex = -1;
						this.bankCardCity = '';
						this.bankCardAreaIndex = -1;
						this.bankCardArea = '';

						this.bankCardProvinceIndex = index;
						this.bankCardProvince = this.bankCardProvinceList[index];

						var bankCardCityList = [];
						for (var i = 0; i < china[index].children.length; i++) {
							bankCardCityList.push(china[index].children[i].label);
						}
						this.bankCardCityList = bankCardCityList;
					}
				});
			},
			handleClickCity () {
				if (this.bankCardCityList.length == 0) {
					return;
				}

				picker.pick({
					index: this.bankCardCityIndex,
					items: this.bankCardCityList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.bankCardCityIndex == index) {
							return;
						}

						this.bankCardAreaIndex = -1;
						this.bankCardArea = '';

						this.bankCardCityIndex = event.data;
						this.bankCardCity = this.bankCardCityList[index];

						var bankCardAreaList = [];
						for (var i = 0; i < china[this.bankCardProvinceIndex].children[index].children.length; i++) {
							bankCardAreaList.push(china[this.bankCardProvinceIndex].children[index].children[i].label);
						}
						this.bankCardAreaList = bankCardAreaList;
					}
				});
			},
			handleClickArea () {
				if (this.bankCardAreaList.length == 0) {
					return;
				}

				picker.pick({
					index: this.bankCardAreaIndex,
					items: this.bankCardAreaList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.bankCardAreaIndex == index) {
							return;
						}

						this.bankCardAreaIndex = index;
						this.bankCardArea = this.bankCardAreaList[index];
					}
				});
			},

			handleClickSex () {
				picker.pick({
					items: this.riderGenderList,
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, event => {
					var result = event.result;
					if (result == 'success') {
						this.riderGender = this.riderGenderList[event.data];
					}
				})
			},
			handleClickIsInsurance () {
				this.riderIsInsurance = !this.riderIsInsurance;
			},
			handleClickIsHealthCertificate () {
				this.riderIsHealthCertificate = !this.riderIsHealthCertificate;
			},
			handleClickIsFullTime () {
				this.riderIsFullTime = !this.riderIsFullTime;
			},
			handleClickAgreement () {
				this.isAgreement = !this.isAgreement;
			},
			handleSubmit () {
				if (this.riderName == '') {
					this.toast('用户名不能为空');
					return;
				}
				if (this.riderPhone == '') {
					this.toast('用户手机不能为空');
					return;
				}
				if (this.riderIdCard == '') {
					this.toast('身份证号不能为空');
					return;
				}
				if (this.riderAge == '') {
					this.toast('年龄不能为空');
					return;
				}
				if (this.riderEmergencyContact == '') {
					this.toast('紧急联系人不能为空');
					return;
				}
				if (this.riderEmergencyContactPhone == '') {
					this.toast('紧急联系电话不能为空');
					return;
				}
				if (this.riderLevelId == '') {
					this.toast('骑手等级不能为空');
					return;
				}
				if (this.companyId == '') {
					this.toast('所属公司不能为空');
					return;
				}
				if (this.branchCompanyId == '') {
					this.toast('所属分公司不能为空');
					return;
				}
				if (this.siteId == '') {
					this.toast('所属站点不能为空');
					return;
				}
				if (this.bankName == '') {
					this.toast('开户银行不能为空');
					return;
				}
				if (this.bankCardNo == '') {
					this.toast('银行卡卡号不能为空');
					return;
				}
				if (this.bankCardHolder == '') {
					this.toast('开户人姓名不能为空');
					return;
				}
				if (this.bankCardProvince == '') {
					this.toast('开户行省份不能为空');
					return;
				}
				if (this.bankCardCity == '') {
					this.toast('开户行城市不能为空');
					return;
				}
				if (this.bankCardArea == '') {
					this.toast('开户行区域不能为空');
					return;
				}
				if (this.bankCardAddress == '') {
					this.toast('开户行具体地址不能为空');
					return;
				}
				if (this.riderIdCardFrontImageFileId == '') {
					this.toast('身份证正面不能为空');
					return;
				}
				if (this.riderIdCardBackImageFileId == '') {
					this.toast('身份证反面不能为空');
					return;
				}
				if (this.riderHoldIdCardImageFileId == '') {
					this.toast('手持身份证照片不能为空');
					return;
				}
				if (this.riderHealthCertificateImageFileId == '') {
					this.toast('健康证照片不能为空');
					return;
				}

				if (!isAgreement) {
					this.toast('必须要同意《骑手配送协议》');
					return;
				}

				this.isLoad = true;

				this.request({
					url: '/rider/mobile/v1/register',
					data: {
						riderName: this.riderName,
						riderPhone: this.riderPhone,
						riderIdCard: this.riderIdCard,
						riderGender: this.riderGender,
						riderAge: this.riderAge,
						riderEmergencyContact: this.riderEmergencyContact,
						riderEmergencyContactPhone: this.riderEmergencyContactPhone,
						riderIsInsurance: this.riderIsInsurance,
						riderIsHealthCertificate: this.riderIsHealthCertificate,
						riderSpeed: this.riderSpeed,
						riderIsFullTime: this.riderIsFullTime,
						riderIdCardFrontImageFileId: this.riderIdCardFrontImageFileId,
						riderIdCardBackImageFileId: this.riderIdCardBackImageFileId,
						riderHoldIdCardImageFileId: this.riderHoldIdCardImageFileId,
						riderHealthCertificateImageFileId: this.riderHealthCertificateImageFileId,
						riderLevelId: this.riderLevelId,
						companyId: this.companyId,
						branchCompanyId: this.branchCompanyId,
						siteId: this.siteId,
						bankName: this.bankName,
						bankCardNo: this.bankCardNo,
						bankCardHolder: this.bankCardHolder,
						bankCardProvince: this.bankCardProvince,
						bankCardCity: this.bankCardCity,
						bankCardArea: this.bankCardArea,
						bankCardAddress: this.bankCardAddress,
						riderPassword: this.riderPassword
					},
					success: (data) => {
						this.storage.setItem('riderId', data.riderId, res => {
							if (res.result === 'success') {
								this.isLoad = false;

								this.login();

								this.toast('注册成功', () => {
									this.pushRoot('/index');
								});
							}
						});
					},
					error: () => {
						this.isLoad = false;

						this.toast('注册失败')
					}
				});
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		margin-bottom: 40px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}

	.title {
		width: 750px;
		background-color: #f5f5f9;
	}

	.register-label {
		width: 210px;
		height: 40px;
		font-size: 28px;
	}

	.register-image {
		width: 160px;
		height: 160px;
	}

	.register-input {
		width: 500px;
		height: 60px;
		font-size: 28px;
	}

	.cell {
		width: 750px;
		height: 120px;
	}

	.cell-image {
		width: 750px;
	}

	.value {
		font-size: 28px;
	}

	.desc {
		color: #989998;
		font-size: 28px;
		height: 40px;
	}

	.register-image-desc {
		color: #989998;
		font-size: 28px;
		height: 160px;
		justify-content: center;
	}

	.from-submit {
		width: 710px;
		margin-left: 20px;
		margin-top: 20px;
		margin-bottom: 40px;
		background-color: #fecd39;
		color: #ffffff;
		font-size: 30px;
		text-align: center;
		padding-top: 20px;
		padding-bottom: 20px;
		border-radius: 6px;
	}

	.agreement {
		font-size: 28px;
		height: 40px;
		padding-left: 20px;
	}
</style>
