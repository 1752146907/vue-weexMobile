<template>
	<div class="wrapper">
		<div class="tab-item" :style="{left: activeIndex * -750 + 'px'}">
			<!--首页-->
			<Home></Home>

			<!--我的-->
			<Member></Member>
		</div>
		<div class="bar">
			<div class="bar-item" @click="handleClickBarItm(0)">
				<image :src="activeIndex == 0 ? 'http://h5.chuangshi.nowui.com/wawipet/image/home-active.png' : 'http://h5.chuangshi.nowui.com/wawipet/image/home.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == 0 ? 'bar-item-text-active' : 'bar-item-text']">首页</text>
			</div>
			<div class="bar-item" @click="handleClickBarItm(1)">
				<image :src="activeIndex == 1 ? 'http://h5.chuangshi.nowui.com/wawipet/image/my-active.png' : 'http://h5.chuangshi.nowui.com/wawipet/image/my.png'"
					   resize="cover"
					   class="bar-item-icon"></image>
				<text :class="[activeIndex == 1 ? 'bar-item-text-active' : 'bar-item-text']">我的</text>
			</div>
		</div>
	</div>
</template>

<script>
	import mixin from '../common/mixin';

	import Home from "./home/index";
	import Member from "./member/index";

	export default {
		components: {Member, Home},
		mixins: [mixin],
		data () {
			return {
				activeIndex: 0
			}
		},
		mounted () {
			if (this.platform === 'web') {
				this.storage.getItem('index-active-index', (res) => {
					if (res.result === 'success') {
						this.activeIndex = res.data;
					} else {
						this.activeIndex = 0;
					}
				});
			} else {
				this.handleChangeTitle(this.activeIndex);
			}
		},
		methods: {
			handleClickBarItm (activeIndex) {
				this.storage.setItem('index-active-index', activeIndex, event => {
					this.activeIndex = activeIndex;

					this.handleChangeTitle(activeIndex);
				});
			},
			handleChangeTitle (index) {
				this.changeTitle(index == 0 ? '首页' : '我的');
			}
		}
	}
</script>

<style scoped>
	.wrapper {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		overflow: hidden;
	}

	.tab-item {
		position: relative;
		width: 1500px;
		flex: 1;
		flex-direction: row;
		align-items: stretch;
	}

	.bar {
		position: fixed;
		left: 0px;
		bottom: 0px;
		width: 750px;
		height: 100px;
		flex-wrap: nowrap;
		flex-direction: row;
		justify-content: space-around;
		border-top-width: 1px;
		border-top-color: #d9d9d9;
		background-color: #ffffff;
	}

	.bar-item {
		flex: 1;
		align-items: center;
		justify-content: center;
	}

	.bar-item-icon {
		width: 42px;
		height: 42px;
		margin-top: 5px;
	}

	.bar-item-text {
		font-size: 24px;
		margin-top: 2px;
		color: #666666;
	}

	.bar-item-text-active {
		font-size: 24px;
		margin-top: 2px;
		color: #ffc900;
	}
</style>
