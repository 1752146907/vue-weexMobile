<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<!--<wxc-minibar title="添加银行卡"-->
		<!--background-color="#fecd39"-->
		<!--text-color="#ffffff"-->
		<!--:use-default-return="false">-->
		<!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
		<!--slot="left"-->
		<!--class="back"-->
		<!--@click="handleClickBack"></image>-->
		<!--</wxc-minibar>-->
		<div class="container-box">
			<wxc-cell :has-arrow="false"
					  class="cell"
					  :has-margin="false">
				<text class="cart-label"
					  slot="label">持卡人*
				</text>
				<input type="text"
					   slot="title"
					   v-model="backCardHolder"
					   placeholder="请输入姓名"
					   class="cart-input"
					   value=""/>
			</wxc-cell>
			<wxc-cell :has-arrow="false"
					  class="cell"
					  :has-margin="false">
				<text class="cart-label"
					  slot="label">银行卡号*
				</text>
				<input type="number"
					   slot="title"
					   v-model="bankCardNo"
					   placeholder="请输入您的银行卡号"
					   class="cart-input"
					   value=""/>
			</wxc-cell>
			<wxc-cell :has-arrow="true"
					  class="cell"
					  :has-margin="false"
					  @wxcCellClicked="handleClickBankName">
				<text class="cart-label"
					  slot="label">开户银行*
				</text>
				<text slot="title"
					  class="cart-text">{{bankName}}
				</text>
			</wxc-cell>
			<wxc-cell :has-arrow="true"
					  class="cell"
					  :has-margin="false"
					  @wxcCellClicked="handleClickProvince">
				<text class="cart-label"
					  slot="label">开户行省份*
				</text>
				<text slot="title"
					  class="cart-text">{{provinceName}}
				</text>
			</wxc-cell>
			<wxc-cell :has-arrow="true"
					  class="cell"
					  :has-margin="false"
					  @wxcCellClicked="handleClickCity">
				<text class="cart-label"
					  slot="label">开户行城市*
				</text>
				<text slot="title"
					  class="cart-text">{{cityName}}
				</text>
			</wxc-cell>
			<wxc-cell :has-arrow="true"
					  class="cell"
					  :has-margin="false"
					  @wxcCellClicked="handleClickArea">
				<text class="cart-label"
					  slot="label">开户行区域*
				</text>
				<text slot="title"
					  class="cart-text">{{areaName}}
				</text>
			</wxc-cell>
			<wxc-cell :has-arrow="false"
					  class="cell"
					  :has-margin="false">
				<text class="cart-label"
					  slot="label">开户行具体地址*
				</text>
				<input type="text"
					   slot="title"
					   v-model="backCardAddress"
					   placeholder="请输入开户行具体地址"
					   class="cart-input"
					   value=""/>
			</wxc-cell>
			<wxc-button text="保持并使用"
						:btnStyle="{backgroundColor: '#fecd39'}"
						:textStyle="{fontSize: '28px', color: '#000000'}"
						class="add-bank-card"
						@wxcButtonClicked="handleSubmit"></wxc-button>
		</div>

		<wxc-loading :show="isLoad" type="default"></wxc-loading>
	</scroller>
</template>

<script>
	import {WxcCell, WxcButton, WxcMinibar, WxcLoading} from 'weex-ui';

	import mixin from '../../common/mixin';
	import china from '../../common/china';

	const picker = weex.requireModule('picker');

	export default {
		components: {
			WxcCell,
			WxcButton,
			WxcMinibar,
			WxcLoading
		},
		mixins: [mixin],
		data: () => ({
			isLoad: false,
			bankName: '',
			bankCardNo: '',
			backCardHolder: '',
			backCardProvince: '',
			backCardCity: '',
			backCardArea: '',
			backCardAddress: '',
			bankNameItem: ['中国工商银行', '中国建设银行', '中国银行', '中国农业银行', '交通银行', '中国邮政储蓄银行', '信用社'],
			provinceList: [],
			provinceIndex: -1,
			provinceName: '',
			cityList: [],
			cityIndex: -1,
			cityName: '',
			areaList: [],
			areaIndex: -1,
			areaName: '',  //城市选择
		}),
		mounted () {
			this.changeTitle('添加银行卡');

			var provinceList = [];
			for (let i = 0; i < china.length; i++) {
				provinceList.push(china[i].label);
			}
			this.provinceList = provinceList;
		},
		methods: {
			getRiderId () {
				let riderId = '';
				this.storage.getItem('riderId', res => {
					if (res.result === 'success') {
						riderId = res.data;
					}
				});

				return riderId;
			},
			handleClickBack () {
				this.pop();
			},
			handleClickProvince () {
				if (this.platform == 'web') {
					return;
				}

				picker.pick({
					index: this.provinceIndex,
					items: this.provinceList,
					height: "500px",
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.provinceIndex == index) {
							return;
						}

						this.cityIndex = -1;
						this.cityName = '';
						this.areaIndex = -1;
						this.areaName = '';

						this.provinceIndex = index;
						this.provinceName = this.provinceList[index];

						var cityList = [];
						for (var i = 0; i < china[index].children.length; i++) {
							cityList.push(china[index].children[i].label);
						}
						this.cityList = cityList;
						this.toast(this.provinceName)
					}
				});
			},
			handleClickCity () {
				if (this.cityList.length == 0) {
					return;
				}

				picker.pick({
					index: this.cityIndex,
					items: this.cityList,
					height: "500px",
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.cityIndex == index) {
							return;
						}

						this.areaIndex = -1;
						this.areaName = '';

						this.cityIndex = event.data;
						this.cityName = this.cityList[index];

						var areaList = [];
						for (var i = 0; i < china[this.provinceIndex].children[index].children.length; i++) {
							areaList.push(china[this.provinceIndex].children[index].children[i].label);
						}
						this.areaList = areaList;
						this.toast(this.cityName)
					}
				});
			},
			handleClickArea () {
				if (this.areaList.length == 0) {
					return;
				}

				picker.pick({
					index: this.areaIndex,
					items: this.areaList,
					height: "500px",
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, (event) => {
					if (event.result === 'success') {
						var index = event.data == -1 ? 0 : event.data;

						if (this.areaIndex == index) {
							return;
						}

						this.areaIndex = index;
						this.areaName = this.areaList[index];
						this.toast(this.areaName)
					}
				});
			},
			handleClickBankName () {
				const picker = weex.requireModule('picker');
				picker.pick({
					items: this.bankNameItem,
					height: "500px",
					confirmTitle: '确定',
					cancelTitle: '取消'
				}, event => {
					var result = event.result;
					if (result == 'success') {
						this.bankName = this.bankNameItem[event.data];
						this.toast(this.bankName)
					}
				})
			},
			handleSubmit () {
				if (this.backCardHolder == '') {
					this.toast('开户人姓名不能为空');
					return;
				}
				if (this.bankName == '') {
					this.toast('开户银行不能为空');
					return;
				}
				if (this.bankCardNo == '') {
					this.toast('银行卡卡号不能为空');
					return;
				}
				if (this.provinceName == '') {
					this.toast('开户行省份不能为空');
					return;
				}
				if (this.cityName == '') {
					this.toast('开户行城市不能为空');
					return;
				}
				if (this.areaName == '') {
					this.toast('开户行区域不能为空');
					return;
				}
				if (this.backCardAddress == '') {
					this.toast('开户行具体地址不能为空');
					return;
				}
				this.isLoad = true;
				this.request({
					url: '/rider/bank/card/mobild/v1/save',
					data: {
						riderId: this.getRiderId(),
						systemRequestUserId: this.getRiderId(),
						bankName: this.bankName,
						bankCardNo: this.bankCardNo,
						backCardHolder: this.backCardHolder,
						backCardProvince: this.provinceName,
						backCardCity: this.cityName,
						backCardArea: this.areaName,
						backCardAddress: this.backCardAddress
					},
					success: (data) => {
						this.isLoad = false;
						this.toast('添加成功', () => {
							this.push('/bankCard/index');
						});
					},
					error: () => {
						this.isLoad = false;
					}
				});
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}

	.back {
		width: 42px;
		height: 42px;
	}

	.container-box {
		width: 750px;
	}

	.cell {
		width: 750px;
		height: 120px;
		box-sizing: border-box;
	}

	.cart-label {
		width: 220px;
		height: 40px;
		font-size: 28px;
		margin-right: 10px;
	}

	.cart-text {
        height: 40px;
		color: #888888;
		font-size: 28px;
	}

	.cart-input {
		font-size: 28px;
	}

	.is-default {
		color: #d7d7d7;
	}

	.add-bank-card {
		width: 700px;
		margin-left: 25px;
		color: #ffffff;
		background-color: #fecd39;
		margin-top: 30px;
	}

</style>
