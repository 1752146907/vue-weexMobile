<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--<wxc-minibar title="我的银行卡"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <div class="container-box">
            <div class="not-card" v-if="cardListLength <= 0">
                <wxc-icon name="wrong">
                    size="medium"></wxc-icon>
                <text class="not-card-text"
                      @wxcButtonClicked="handleAddCard">点击按钮立即添加</text>
            </div>
            <div class="bank-card-item"
                 v-else-if="cardListLength > 0"
                 @click="handleCard(item)"
                 v-for="item in cardList">
                <div class="bank-card-information">
                    <text class="bank-card-images-box">
                        <image resize="cover"
                               class="bank-card-images"
                               src="http://h5.chuangshi.nowui.com/jibai/cart.png" ></image>
                    </text>
                    <text class="bank-card-name">{{item.bankName}}</text>
                    <!--<text class="is-default">默认银行卡</text>-->
                </div>
                <text class="bank-card-number">{{item.bankCardNo}}</text>
            </div>
            <!--<div class="bank-card-item"-->
            <!--@click="handleCard">-->
            <!--<div class="bank-card-information">-->
            <!--<text class="bank-card-images-box">-->
            <!--<image resize="cover"-->
            <!--class="bank-card-images"-->
            <!--src="https://vuejs.org/images/logo.png" ></image>-->
            <!--</text>-->
            <!--<text class="bank-card-name">***银行存储卡</text>-->
            <!--<text class="is-default"></text>-->
            <!--</div>-->
            <!--<text class="bank-card-number">**** **** **** **** **** 9999</text>-->
            <!--</div>-->
            <wxc-button text="+添加银行卡"
                        :btnStyle="{backgroundColor: '#fecd39'}"
                        :textStyle="{fontSize: '28px', color: '#000000'}"
                        @click="handleAddCard"
                        class="add-bank-card"
                        @wxcButtonClicked="handleAddCard"></wxc-button>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell, WxcButton, WxcIcon, WxcMinibar} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcIcon,
            WxcMinibar
        },
        mixins: [mixin],
        data: () => ({
            cardList:{},
            cardListLength:''
        }),
        created() {
            this.request({
                url: '/rider/bank/card/mobile/v1/list',
                data: {
                    riderId: this.getRiderId(),
                    systemRequestUserId: this.getRiderId(),
                    pageIndex: 1,
                    pageSize: 8
                },
                success: (data) => {
                    if(data.list.length > 0){
                        this.cardList = data.list;
                        this.cardListLength = data.list.length;
                    }else{
                        this.cardListLength = 0;
                    }
                },
                error: () => {

                }
            });
        },
        mounted() {
			this.changeTitle('我的银行卡');
        },
        methods: {
            getRiderId() {
                let riderId = '';
                this.storage.getItem('riderId', res => {
                    if(res.result === 'success'){
                        riderId = res.data;
                    }
                });

                return riderId;
            },
            handleClickBack () {
                this.pop();
            },
            handleCard(item) {
                this.push('/bankCard/detail?forumId=' + item.riderBankCardId + '&forumName=' + item.bankName + '&forumCardNo=' + item.bankCardNo);
            },
            handleAddCard() {
                this.push('/bankCard/add');
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

    .container-box{
        padding-top: 20px;
        padding-left: 20px;
        padding-right: 20px;
    }

    .not-card{
        align-items: center;
        padding-top: 180px;
        padding-bottom: 150px;
    }

    .not-card-text{
        color: #cccccc;
        padding-top: 20px;
    }

    .bank-card-item{
        width: 710px;
        height: 210px;
        padding-left: 22px;
        padding-right: 22px;
        padding-top: 22px;
        padding-bottom: 22px;
        margin-bottom: 24px;
        -webkit-border-radius: 6px;
        -moz-border-radius: 6px;
        border-radius: 6px;
        background-color: #fecd39;
    }

    .bank-card-information{
        align-content: space-around;
        flex-direction: row
    }

    .bank-card-images-box{
        width: 100px;
        height: 100px;
        border-radius: 50px;
        margin-right: 32px;
        background-color: #ffffff;
    }

    .bank-card-images{
        width: 100px;
        height: 100px;
        border-radius: 50px;
        margin-right: 32px;
    }

    .bank-card-name{
        width: 378px;
        padding-top: 20px;
        font-size: 28px;
        color: #ffffff;
    }

    .is-default{
        width: 180px;
        color: #999999;
        padding-top: 20px;
        font-size: 28px;
    }

    .add-bank-card{
        color: #ffffff;
        background-color: #fecd39;
        margin-top: 30px;
        font-size: 28px;
    }

    .bank-card-number{
        margin-top: 20px;
        font-size: 28px;
        color: #ffffff;
    }
</style>
