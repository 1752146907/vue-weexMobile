<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--<wxc-minibar title="我的银行卡"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <div class="container-box">
            <div class="bank-card-item">
                <div class="bank-card-information">
                    <text class="bank-card-images-box">
                        <image resize="cover"
                               class="bank-card-images"
                               src="http://h5.chuangshi.nowui.com/jibai/cart.png" ></image>
                    </text>
                    <text class="bank-card-name">{{forumName}}</text>
                    <!--<text class="is-default">默认银行卡</text>-->
                </div>
                <text class="bank-card-number">{{forumCardNo}}</text>
            </div>
            <wxc-button text="删除银行卡"
                        :btnStyle="{backgroundColor: '#fecd39'}"
                        :textStyle="{fontSize: '28px', color: '#000000'}"
                        @wxcButtonClicked="handleRemoveCard"
                        class="del-bank-card"></wxc-button>
        </div>
    </scroller>
</template>

<script>
    import {WxcCell, WxcIcon, WxcButton, WxcMinibar} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcIcon,
            WxcButton,
            WxcMinibar,
        },
        mixins: [mixin],
        data: () => ({
            forumId:'',
            forumName: '',
            forumCardNo:''
        }),
        created() {
            this.forumId = decodeURI(decodeURI(this.getParameter('forumId')));
            this.forumName = decodeURI(decodeURI(this.getParameter('forumName')));
            this.forumCardNo = decodeURI(decodeURI(this.getParameter('forumCardNo')));
        },
        mounted() {
			this.changeTitle('我的银行卡');
        },
        methods: {
            getRiderId() {
                let riderId = '';
                this.storage.getItem('riderId', res => {
                    if(res.result === 'success'){
                        riderId = res.data;
                    }
                });

                return riderId;
            },
            handleClickBack () {
                this.pop();
            },
            handleRemoveCard() {
                this.request({
                    url: '/rider/bank/card/mobild/v1/delete',
                    data: {
                        systemRequestUserId: this.getRiderId(),
                        riderBankCardId: this.forumId
                    },
                    success: (data) => {
                        this.toast('删除成功', () => {
                            this.push('/bankCard/index');
                        });
                    },
                    error: () => {
                        this.toast('操作失败')
                    }
                });
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

    .container-box{
        padding-top: 20px;
        padding-left: 20px;
        padding-right: 20px;
    }

    .not-card{
        align-items: center;
        padding-top: 180px;
        padding-bottom: 150px;
    }

    .not-card-text{
        color: #cccccc;
        padding-top: 20px;
    }

    .bank-card-item{
        width: 710px;
        height: 210px;
        padding-left: 22px;
        padding-right: 22px;
        padding-top: 22px;
        padding-bottom: 22px;
        margin-bottom: 24px;
        -webkit-border-radius: 6px;
        -moz-border-radius: 6px;
        border-radius: 6px;
        background-color: #fecd39;
    }

    .bank-card-information{
        align-content: space-around;
        flex-direction: row
    }

    .bank-card-images-box{
        width: 100px;
        height: 100px;
        border-radius: 50px;
        margin-right: 32px;
        background-color: #ffffff;
    }

    .bank-card-images{
        width: 100px;
        height: 100px;
        border-radius: 50px;
        margin-right: 32px;
    }

    .bank-card-name{
        width: 378px;
        padding-top: 20px;
        font-size: 28px;
        color: #ffffff;
    }

    .is-default{
        width: 180px;
        color: #999999;
        padding-top: 20px;
        font-size: 28px;
    }

    .add-bank-card{
        color: #ffffff;
        background-color: #fecd39;
        margin-top: 30px;
        font-size: 28px;
    }

    .del-bank-card{
        color: #ffffff;
        background-color: #cccccc;
        margin-top: 30px;
        font-size: 28px;
    }

    .bank-card-number{
        margin-top: 20px;
        font-size: 28px;
        color: #ffffff;
    }

    .cart-label{
        width: 200px;
        font-size: 28px;
        margin-right: 10px;
    }

    .cart-input{
        font-size: 28px;
    }
</style>
