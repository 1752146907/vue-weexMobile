<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--投诉-->
        <!--<wxc-minibar title="客服投诉"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->

        <wxc-cell :has-arrow="false"
                  :has-margin="false">
            <text class="complaint-label"
                  slot="label">投诉人</text>
            <input type="number"
                   slot="title"
                   placeholder="请输入投诉人"
                   class="complaint-input"
                   value="" />
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  :has-margin="false">
            <text class="complaint-label"
                  slot="label">投诉人联系电话</text>
            <input type="number"
                   slot="title"
                   placeholder="请输入投诉人联系电话"
                   class="complaint-input"
                   value="" />
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  :has-margin="false">
            <text class="complaint-label"
                  slot="label">投诉订单编号</text>
            <input type="number"
                   slot="title"
                   placeholder="请输入投诉订单编号"
                   class="complaint-input"
                   value="" />
        </wxc-cell>
        <div class="order-content">
            <text class="content-title">投诉订单编号</text>
            <textarea type="number"
                      placeholder="请输入投诉订单编号"
                      class="content-textarea"
                      value="" ></textarea>
        </div>
        <text class="bar-sublime">提交</text>
    </scroller>
</template>

<script>
    import {WxcCell, WxcButton, WxcMinibar} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcMinibar
        },
        mixins: [mixin],
        data: () => ({

        }),
        mounted() {
			this.changeTitle('客服投诉');
        },
        methods: {
            handleClickBack () {
                this.pop();
            },
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

    .top-bar{
        height: 92px;
    }

    .complaint-label{
        width: 220px;
        font-size: 28px;
    }

    .complaint-input{
        width: 430px;
        font-size: 28px;
    }

    .order-number{
        width: 730px;
        font-size: 28px;
    }

    .order-content{
        padding-top: 10px;
        padding-right: 20px;
        padding-bottom: 10px;
        padding-left: 20px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #e2e2e2;
    }

    .content-title{
        width: 710px;
        font-size: 28px;
    }

    .content-textarea{
        width: 710px;
        height: 200px;
        font-size: 28px;
        margin-top: 10px;
    }

    .bar-sublime{
        width: 710px;
        height: 80px;
        margin-top: 80px;
        margin-left: 20px;
        font-size: 29px;
        background-color: #fecd39;
        color: #ffffff;
        text-align: center;
        padding-top: 20px;
        padding-bottom: 20px;
        border-radius: 6px;
    }
</style>
