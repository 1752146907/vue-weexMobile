<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--<wxc-minibar title="账户明细"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <list class="news-list">
            <cell>
                <text class="news-list-text">您有一个订单快超时了，如果来不及请联系客户，订单编号：123132123</text>
                <text class="news-list-text">您有一个订单快超时了，如果来不及请联系客户，订单编号：123132123</text>
            </cell>
        </list>
    </scroller>
</template>

<script>
    import {WxcCell, WxcMinibar} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcMinibar
        },
        mixins: [mixin],
        data: () => ({
            activeIndex: 0,
            incomeBacngroundClor: '#fecd39',
            incomeExpenditureClor: '#cccccc',
            incomeWidth: '339px',
            expenditureWidth: '339px'
        }),
        mounted() {
            this.changeTitle('消息中心');
        },
        methods: {
            handleClickBack () {
                this.pop();
            },
            handleTab(index){
                if(index == 0){
                    this.activeIndex = 0;
                    this.incomeBacngroundClor = '#fecd39',
                        this.incomeExpenditureClor = '#cccccc'
                }else{
                    this.activeIndex = 1;
                    this.incomeBacngroundClor = '#cccccc',
                        this.incomeExpenditureClor = '#fecd39'
                }
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }
    .back {
        width: 42px;
        height: 42px;
    }
    .news-list{
        padding-top: 10px;
        padding-bottom: 10px;
        padding-left: 10px;
        padding-right: 10px;
    }
    .news-list-text{
        width: 750px;
        padding-top: 26px;
        padding-bottom: 16px;
        padding-left: 10px;
        padding-right: 10px;
        font-size: 28px;
        border-bottom-style: solid;
        border-bottom-width: 1px;
        border-bottom-color: #e4e4e4;
    }
</style>
