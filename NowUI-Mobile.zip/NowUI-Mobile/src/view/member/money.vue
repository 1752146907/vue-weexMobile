<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<!--账户明细-->
		<!--<wxc-minibar title="账户明细"-->
		<!--background-color="#fecd39"-->
		<!--text-color="#ffffff"-->
		<!--:use-default-return="false">-->
		<!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
		<!--slot="left"-->
		<!--class="back"-->
		<!--@click="handleClickBack"></image>-->
		<!--</wxc-minibar>-->

		<div class="top-buttom">
			<wxc-button text="收入"
						class="income"
						@wxcButtonClicked="handleTab(0)"
						:textStyle="{fontSize: '28px', color: '#000000'}"
						:btnStyle="{backgroundColor: incomeBacngroundClor,
								width: incomeWidth}"></wxc-button>
			<wxc-button text="支出"
						class="expenditure"
						@wxcButtonClicked="handleTab(1)"
						:textStyle="{fontSize: '28px', color: '#000000'}"
						:btnStyle="{backgroundColor: incomeExpenditureClor,
								width: expenditureWidth}"></wxc-button>
		</div>

		<div class="tab-item"
			 :style="{left: activeIndex * -750 + 'px'}">
			<div class="income-box">
				<div class="detailed-item" v-for="item in incomeList" v-if="incomeList.length > 0">
					<div class="price-box">
						<text class="monetary-symbol">￥</text>
						<text class="price">{{item.riderAccount}}</text>
					</div>
					<text class="remarks">备注 {{item.riderRemark}}</text>
				</div>
				<div class="not-detailed" v-if="incomeList.length <= 0">
					暂无收入
				</div>
			</div>
			<div class="expenditure-box">
				<div class="detailed-item" v-for="item in expenditureList" v-if="expenditureList.length > 0">
					<div class="price-box">
						<text class="monetary-symbol">￥</text>
						<text class="price">{{item.riderAccount}}</text>
					</div>
					<text class="remarks">备注 {{item.riderRemark}}</text>
				</div>
				<div class="not-detailed" v-if="expenditureList.length <= 0">
					暂无支出
				</div>
			</div>
		</div>
		<wxc-loading :show="isLoad" type="default"></wxc-loading>
	</scroller>
</template>

<script>
	import {WxcCell, WxcButton, WxcMinibar, WxcLoading} from 'weex-ui';

	import mixin from '../../common/mixin';

	export default {
		components: {
			WxcCell,
			WxcButton,
			WxcMinibar,
			WxcLoading
		},
		mixins: [mixin],
		data: () => ({
			activeIndex: 0,
			incomeBacngroundClor: '#fecd39',
			incomeExpenditureClor: '#cccccc',
			incomeWidth: '339px',
			expenditureWidth: '339px',
			incomeList: [],
			expenditureList: [],
			isLoad: false
		}),
		mounted () {

		},
		created () {
			this.isLoad = true;
			this.request({
				url: '/rider/account/detail/mobile/v1/list',
				data: {
					riderId: this.getRiderId(),
					riderAccountType: 'SHOU',
					pageIndex: 1,
					pageSize: 10
				},
				success: (data) => {
					this.isLoad = false;
					this.incomeList = data.list
				},
				error: () => {
					this.isLoad = false;
				}
			});
			this.request({
				url: '/rider/account/detail/mobile/v1/list',
				data: {
					riderId: this.getRiderId(),
					riderAccountType: 'ZHI',
					pageIndex: 1,
					pageSize: 10
				},
				success: (data) => {
					this.isLoad = false;
					this.expenditureList = data.list
				},
				error: () => {
					this.isLoad = false;
				}
			});
		},
		mounted () {
			this.changeTitle('账户明细');
		},
		methods: {
			handleClickBack () {
				this.pop();
			},
			getRiderId () {
				let riderId = '';
				this.storage.getItem('riderId', res => {
					if (res.result === 'success') {
						riderId = res.data;
					}
				});

				return riderId;
			},
			handleTab (index) {
				if (index == 0) {
					this.activeIndex = 0;
					this.incomeBacngroundClor = '#fecd39',
						this.incomeExpenditureClor = '#cccccc'
				} else {
					this.activeIndex = 1;
					this.incomeBacngroundClor = '#cccccc',
						this.incomeExpenditureClor = '#fecd39'
				}
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}

	.not-detailed {
		width: 490px;
		margin-top: 100px;
		flex-direction: row;
		justify-content: center;
		color: #cccccc;
	}

	.back {
		width: 42px;
		height: 42px;
	}

	.tab-item {
		width: 1500px;
		flex: 1;
		flex-direction: row;
		align-items: stretch;
	}

	.income-box {
		width: 750px;
	}

	.expenditure-box {
		width: 750px;
	}

	.top-buttom {
		width: 750px;
		padding-top: 20px;
		padding-left: 20px;
		padding-right: 20px;
		padding-bottom: 20px;
		flex-direction: row;
		/*position: relative;*/
		margin-bottom: 10px;
	}

	.income {
		/*width: 339px;*/
		align-items: center;
		justify-content: center;
		margin-right: 16px;
	}

	.expenditure {
		/*width: 339px;*/
		align-items: center;
		justify-content: center;
		margin-left: 16px;
	}

	.detailed-item {
		padding-top: 28px;
		padding-left: 10px;
		padding-right: 10px;
		padding-bottom: 20px;
		border-top-style: solid;
		border-top-width: 1px;
		border-bottom-width: 1px;
		border-top-color: #f5f5f9;
		border-bottom-color: #f5f5f9;
		margin-bottom: 20px;
		background-color: #ffffff;
	}

	.price-box {
		width: 730px;
		flex-direction: row;
		flex-wrap: wrap
	}

	.monetary-symbol {
		width: 40px;
		font-size: 44px;
		color: #444444;
	}

	.price {
		width: 670px;
		font-size: 44px;
		padding-left: 10px;
		color: #000000;
	}

	.remarks {
		width: 600px;
		font-size: 28px;
		padding-top: 10px;
		padding-bottom: 30px;
	}
</style>
