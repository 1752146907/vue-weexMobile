<template>
	<scroller class="container"
			  :style="{height: pageHeight + 'px'}">
		<wxc-cell class="user"
				  :has-arrow="true"
				  :has-top-border="true"
				  @wxcCellClicked="handleUserInfo">
			<text slot="label"
				  class="user-image-box">
				<image resize="cover"
					   class="user-image"
					   src="http://h5.chuangshi.nowui.com/jibai/userinfo.png"></image>
			</text>
			<text class="cell-title"
				  slot="title">{{riderName}}
			</text>
			<text class="cell-title"
				  slot="value">{{siteName}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell margin-top-40"
				  :has-arrow="true"
				  :has-top-border="true"
				  title="账户信息"
				  @wxcCellClicked="handleMoney">
			<text class="label-act-value"
				  slot="value">
				余额￥{{riderAccountBalance}}
			</text>
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-top-border="false"
				  title="我的银行卡"
				  @wxcCellClicked="handleBankCard">
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-top-border="false"
				  title="修改密码"
				  @wxcCellClicked="handlePassword">
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-top-border="false"
				  title="保险赔款说明"
				  @wxcCellClicked="handleExplain">
		</wxc-cell>
		<wxc-cell class="cell"
				  :has-arrow="true"
				  :has-top-border="false"
				  title="今日上班时长">
			<text slot="value" class="label-act-value">
				{{onlineTime}}
			</text>
		</wxc-cell>
	</scroller>
</template>

<script>
	import {WxcCell} from 'weex-ui';

	import mixin from '../../common/mixin';

	export default {
		components: {
			WxcCell
		},
		mixins: [mixin],
		data: () => ({
			riderId: '',
			riderName: '',
			siteName: '',
			riderAccountBalance: '',
			onlineTime: ''
		}),
		mounted () {
			this.handleLoad();
		},
		methods: {
			getRiderId () {
				let riderId = '';
				this.storage.getItem('riderId', res => {
					if (res.result === 'success') {
						riderId = res.data;
					}
				});
				return riderId;
			},
			handleLoad () {
				this.storage.getItem('riderId', (res) => {
					if (res.result === 'success') {
						this.request({
							url: '/rider/mobile/v1/userInfo',
							data: {
								riderId: res.data
							},
							success: (data) => {
								this.riderId = data.riderId;
								this.riderName = data.riderName;
								this.siteName = data.siteName;
								this.riderAccountBalance = data.riderAccountBalance;
								this.onlineTime = Math.floor(data.riderAccountBalance / 60) + "小时" + (data.riderAccountBalance % 60) + "分钟";
							},
							error: () => {
								// this.isLoad = false;
							}
						});
					}
				});
			},
			handleUserInfo () {
				this.push('/member/detail');
			},
			handleMoney () {
				this.push('/member/money');
			},
			handleBankCard () {
				this.push('/bankCard/index');
			},
			handleExplain () {
				this.push('/member/explain');
			},
			handlePassword () {
				this.push('/login/password');
			}
		}
	}
</script>

<style scoped>
	.container {
		width: 750px;
		align-items: flex-start;
		justify-content: flex-start;
		background-color: #F5F5F5;
	}

	.user {
		width: 750px;
		height: 200px;
	}

	.user-image-box {
		width: 120px;
		height: 120px;
		margin-right: 18px;
		-webkit-border-radius: 60px;
		-moz-border-radius: 60px;
		border-radius: 60px;
		background-color: #cccccc;
	}

	.user-image {
		width: 120px;
		height: 120px;
		-webkit-border-radius: 60px;
		-moz-border-radius: 60px;
		border-radius: 60px;
	}

	.margin-top-40 {
		margin-top: 40px;
	}

	.cell {
		width: 750px;
		height: 120px;
	}

	.cell-title {
		height: 40px;
	}

	.cell-value {
		height: 40px;
	}

	.section-box {
		margin-top: 40px;
	}
</style>
