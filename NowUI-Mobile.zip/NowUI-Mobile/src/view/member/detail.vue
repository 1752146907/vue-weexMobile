<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--<wxc-minibar title="基础信息"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">姓名：</text>
            <text 	class="text-size"
                     slot="title">{{riderName}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">手机号：</text>
            <text slot="title">{{riderPhone}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">身份证：</text>
            <text slot="title">{{riderIdCard}}</text>
        </wxc-cell>
        <wxc-cell :has-margin="false"
                  class="cell-bar">
            <text class="text-size"
                  @change="handleClickIsHealthCertificate"
                  slot="label">是否有健康证：</text>
            <text 	class="text-size"
                     slot="title">{{riderIsHealthCertificate}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">是否有保险：</text>
            <text 	class="text-size"
                     slot="title">{{riderIsInsurance}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">性别：</text>
            <text 	class="text-size"
                     slot="title">{{riderGender}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">年龄：</text>
            <text 	class="text-size"
                     slot="title">{{riderAge}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">紧急联系人：</text>
            <text 	class="text-size"
                     slot="title"> {{riderEmergencyContact}}</text>
        </wxc-cell>
        <wxc-cell :has-arrow="false"
                  class="cell-bar"
                  :has-margin="false">
            <text 	class="text-size"
                     slot="label">紧急联系人电话：</text>
            <text 	class="text-size"
                     slot="title">{{riderEmergencyContactPhone}}</text>
        </wxc-cell>
        <wxc-button text="退出"
                    class="logout"
                    @wxcButtonClicked="handleExit"
                    :btnStyle="{backgroundColor: '#fecd39'}"
                    :textStyle="{fontSize: '28px', color: '#000000'}"></wxc-button>
    </scroller>
</template>

<script>
    import {WxcCell, WxcMinibar, WxcButton} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcMinibar
        },
        mixins: [mixin],
        data: () => ({
            riderName:'',
            riderPhone:'',
            riderIdCard:'',
            riderIsHealthCertificate:'',
            riderIsInsurance:'',
            riderGender:'',
            riderAge:'',
            riderEmergencyContact:'',
            riderEmergencyContactPhone:'',
        }),
        created() {
            this.request({
                url: '/rider/mobile/v1/userInfo',
                data: {
                    riderId: this.getRiderId()
                },
                success: (data) => {
                    this.riderName = data.riderName;
                    this.riderPhone = data.riderPhone;
                    this.riderIdCard =  data.riderIdCard;
                    this.riderIsHealthCertificate = data.riderIsHealthCertificate;
                    if(this.riderIsHealthCertificate){
                        this.riderIsHealthCertificate = '是'
                    } else{
                        this.riderIsHealthCertificate = '否'
                    }
                    this.riderIsInsurance = data.riderIsInsurance;
                    if(this.riderIsInsurance){
                        this.riderIsInsurance = '是'
                    } else{
                        this.riderIsInsurance = '否'
                    }
                    this.riderGender = data.riderGender;
                    if(this.riderGender === 'Female'){
                        this.riderGender = '女'
                    } else{
                        this.riderGender = '男'
                    }
                    this.riderAge = data.riderAge;
                    this.riderEmergencyContact = data.riderEmergencyContact;
                    this.riderEmergencyContactPhone = data.riderEmergencyContactPhone;
                },
                error: () => {
                    // this.isLoad = false;
                }
            });
        },
		mounted() {
			this.changeTitle('基础信息');
		},
        methods: {
            getRiderId() {
                let riderId = '';
                this.storage.getItem('riderId', res => {
                    if(res.result === 'success'){
                        riderId = res.data;
                    }
                });

                return riderId;
            },
            handleClickBack () {
                this.pop();
            },
            handleExit () {
                localStorage.clear(this.getToken());
                localStorage.clear(this.getRiderId());
                this.push('/login/index');
            }
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

    .cell-bar{
        width: 750px;
    }

    .text-size{
        font-size: 28px;
    }

    .logout{
        width: 710px;
        margin-top: 60px;
        margin-left: 20px;
        margin-bottom: 20px;
    }
</style>
