<template>
    <scroller class="container"
              :style="{height: pageHeight + 'px'}">
        <!--<wxc-minibar title="会员赔款说明"-->
                     <!--background-color="#fecd39"-->
                     <!--text-color="#ffffff"-->
                     <!--:use-default-return="false">-->
            <!--<image src="http://h5.chuangshi.nowui.com/jibai/back.png"-->
                   <!--slot="left"-->
                   <!--class="back"-->
                   <!--@click="handleClickBack"></image>-->
        <!--</wxc-minibar>-->
        <text>会员赔款说明</text>
    </scroller>
</template>

<script>
    import {WxcCell, WxcMinibar, WxcButton} from 'weex-ui';

    import mixin from '../../common/mixin';

    export default {
        components: {
            WxcCell,
            WxcButton,
            WxcMinibar
        },
        mixins: [mixin],
        data: () => ({

        }),
		mounted() {
			this.changeTitle('会员赔款说明');
		},
        methods: {
            handleClickBack () {
                this.pop();
            },
        }
    }
</script>

<style scoped>
    .container {
        width: 750px;
        align-items: flex-start;
        justify-content: flex-start;
        background-color: #F5F5F5;
    }

    .back {
        width: 42px;
        height: 42px;
    }

</style>
