import Vue from 'vue';
import Router from 'vue-router';
import weex from 'weex-vue-render';

const router = require('@/router');

weex.init(Vue);