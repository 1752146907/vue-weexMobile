module.exports = {
	webEntry: [
		'index',
		//'view/bankCard/add',
		'view/bankCard/detail',
		'view/bankCard/index',
        'view/order/cancal',
		// 'view/order/distribution',
		// 'view/order/done',
		// 'view/order/wait',
		// 'view/home/index',
		// 'view/index',
		// 'view/login/index',
		// 'view/login/password',
		// 'view/login/register',
		// 'view/member/complaint',
		// 'view/member/detail',
		// 'view/member/explain',
		// 'view/member/index',
		//'view/member/money',
		// 'view/member/news',
	]
};