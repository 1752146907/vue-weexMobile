import event from '../common/event';

const toParams = function (obj) {
	var param = ""
	for(const name in obj) {
		if(typeof obj[name] != 'function') {
			param += "&" + name + "=" + encodeURI(obj[name])
		}
	}
	return param.substring(1)
}

export default {
	data () {
		return {
			pageHeight: 0,
            host: 'http://192.168.3.119:10110',
			// host: 'http://localhost:8080',
			// host: 'http://118.31.229.16:80',
			imageHost: 'http://192.168.3.119:10040',
			// imageHost: 'http://localhost:8080',
			appId: 'df2078d6c9eb46babb0df957127273ab',
			version: '1.0.0',
			platform: weex.config.env.platform.toLowerCase(),
			loginValidateSuccessAction: '',
			loginValidateSuccessData: ''
		}
	},
	created () {
		const dom = weex.requireModule('dom');
		const modal = weex.requireModule('modal');
		const stream = weex.requireModule('stream');
		const storage = weex.requireModule('storage');
		const navigator = weex.requireModule('navigator');
		const globalEvent = weex.requireModule('globalEvent');

		this.dom = dom;
		this.modal = modal;
		this.stream = stream;
		this.storage = storage;
		this.navigator = navigator;
		this.globalEvent = globalEvent;
		this.event = event;
		this.mobile = weex.requireModule("event");

		if (this.platform == 'web') {
			this.pageHeight = weex.config.env.deviceHeight / weex.config.env.deviceWidth * 750;
		} else if (this.platform == 'ios') {
			this.pageHeight = weex.config.env.deviceHeight / weex.config.env.deviceWidth * 750 - 116;
		} else {
			this.pageHeight = weex.config.env.deviceHeight / weex.config.env.deviceWidth * 750;
		}
	},
	mounted () {

	},
	methods: {
		changeTitle (title) {
			if (this.platform == 'web') {
				return;
			}

			weex.requireModule("event").changeTitle(title);

			weex.requireModule("event").addRefreshButton();
		},
		toast (text, callback) {
			this.modal.toast({
				message: text,
				duration: 1.0
			});

			if (callback) {
				setTimeout(() => {
					callback();
				}, 1000);
			}
		},
		login () {
			weex.requireModule("event").login();
		},
		logout () {
			weex.requireModule("event").logout();
		},
		push (url) {
			if (this.platform == 'web') {
				this.$router.push({path: url})
			} else {
				var bundleUrl = weex.config.bundleUrl;
				var baseUrl =  bundleUrl.split('/dist/')[0] + '/dist/view';

				if (url.indexOf('?') == -1) {
					url += '.js';
				} else {
					url = url.split('?')[0] + '.js?' + url.split('?')[1];
				}

				// this.toast(baseUrl + url)

				// this.navigator.push({
				// 	url: baseUrl + url,
				// 	animated: "true"
				// });
				weex.requireModule("event").openURL(baseUrl + url);
			}
		},
		pushRoot (url) {
			if (this.platform == 'web') {
				this.$router.push({path: url})
			} else {
				var bundleUrl = weex.config.bundleUrl;
				var baseUrl =  bundleUrl.split('/dist/')[0] + '/dist/view';

				if (url.indexOf('?') == -1) {
					url += '.js';
				} else {
					url = url.split('?')[0] + '.js?' + url.split('?')[1];
				}

				weex.requireModule("event").openRootURL(baseUrl + url);
			}
		},
		pop () {
			if (this.platform === 'web') {
				this.$router.back();
			} else {
				this.navigator.pop({
					animated: 'true'
				});
			}
		},
		getParameter (key) {
			var bundleUrl = weex.config.bundleUrl;

			if (this.platform === 'web') {
				bundleUrl = this.$router.history.current.fullPath;
			}

			if (bundleUrl.indexOf('?') == -1) {
				return;
			}

			var parameterList = bundleUrl.split('?')[1].split(('&'));
			for (var parameter of parameterList) {
				var parameterKey = parameter.split('=')[0];
				var parameterValue = parameter.split('=')[1];

				if (key == parameterKey) {
					return parameterValue;
				}
			}

			return '';
		},
		request (config) {
			config.data.appId = this.appId;
			config.data.token = 'vjYUoyEmyZo2r7FW+iZ3sbtNCkYrKKLSzQJU7JLG2hH97BeP2+Gk72Hdd9e+qRgA4hePuuGPiTsn9q435nWD5D8+7e0Yosk/FE/M3r+W6GA=';
			config.data.platform = this.platform;
			config.data.version = this.version;
			config.data.timestamp = Math.round(new Date().getTime() / 1000);

			config.data.systemRequestUserId = '14463951d1d94d39a9216dbd818fc984';

			let url = this.host + config.url;
			if (config.url.startsWith('http')) {
				url = config.url;
			}

			this.stream.fetch({
				method: 'POST',
				url: url,
				type: 'json',
				headers: {'Content-Type':'application/x-www-form-urlencoded'},
				body: toParams(config.data)
			}, function (response) {
				if (!response.ok) {
					this.toast('网络出现问题!');

					config.error();
				} else {
					if (response.data.code == 200) {
						if (response.data.result) {
							config.success(response.data.data);
						} else {
							this.toast(response.data.message);

							config.error();
						}
					} else {
						this.toast(response.data.message);

						config.error();
					}
				}
			}.bind(this), function (response) {

			});
		},
		refresh () {
			weex.requireModule("event").pageRefresh();
		},
		setToken (token) {
			this.storage.setItem('token_' + this.version, token, res => {
				if (res.result === 'success') {
					// 数据缓存成功
				}
			});
		},
		getToken () {
			let token = '';
			this.storage.getItem('token_' + this.version, res => {
				if (res.result === 'success') {
					token = res.data;
				}
			});
			if (token === null || token === '' || typeof (token) === 'undefined') {
				return 'vjYUoyEmyZo2r7FW+iZ3sbtNCkYrKKLSzQJU7JLG2hH97BeP2+Gk72Hdd9e+qRgA4hePuuGPiTsn9q435nWD5D8+7e0Yosk/FE/M3r+W6GA=';
			}

			return token;
		}
	}
}