import Vue from 'vue';

const event = new Vue();

export default event;