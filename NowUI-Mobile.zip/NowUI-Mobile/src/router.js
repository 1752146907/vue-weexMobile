/* global Vue */
import Vue from 'vue';
import Router from 'vue-router';

import Index from './view/index';
import HomeIndex from './view/home/index';
import OrderWait from './view/order/wait';
import OrderCancal from './view/order/cancal';
import OrderDone from './view/order/done';
import OrderDistribution from './view/order/distribution';
import LoginRegister from './view/login/register';
import LoginPassword from './view/login/password';
import LoginIndex from './view/login/index';
import BankCardIndex from './view/bankCard/index';
import BankCardAdd from './view/bankCard/add';
import BankCardDetail from './view/bankCard/detail';
import MemberComplaint from './view/member/complaint';
import MemberDetail from './view/member/detail';
import MemberExplain from './view/member/explain';
import MemberIndex from './view/member/index';
import MemberMoney from './view/member/money';
import MemberNews from './view/member/news';


Vue.use(Router);

module.exports = new Router({
  routes: [{
	  path: '/',
	  component: Index
  }, {
      path: '/order/done',
      component: OrderDone
  }, {
      path: '/order/wait',
      component: OrderWait
  }, {
	  path: '/order/cancal',
	  component: OrderCancal
  }, {
      path: '/order/distribution',
      component: OrderDistribution
  }, {
	  path: '/order/distribution',
	  component: OrderDistribution
  }, {
	  path: '/home/index',
	  component: HomeIndex
  }, {
      path: '/login/register',
      component: LoginRegister
  }, {
      path: '/login/password',
      component: LoginPassword
  }, {
      path: '/login/index',
      component: LoginIndex
  }, {
      path: '/bankCard/index',
      component: BankCardIndex
  }, {
      path: '/bankCard/add',
      component: BankCardAdd
  }, {
      path: '/bankCard/detail',
      component: BankCardDetail
  }, {
      path: '/member/complaint',
      component: MemberComplaint
  }, {
      path: '/member/detail',
      component: MemberDetail
  }, {
      path: '/member/explain',
      component: MemberExplain
  }, {
      path: '/member/index',
      component: MemberIndex
  }, {
      path: '/member/money',
      component: MemberMoney
  }, {
      path: '/member/news',
      component: MemberNews
  }]
});
