import Vue from 'vue';
import weex from 'weex-vue-render';
import VueMoment from 'vue-moment';
import moment from 'moment-timezone';

Vue.use(VueMoment, {
    moment,
});

//接收参数
weex.config.parameter = {};
var parameterArray = window.location.search.slice(1).split('&');
for (var i = 0; i < parameterArray.length; i++) {
    var parameter = parameterArray[i].split("=");
    weex.config.parameter[parameter[0]] = encodeURIComponent(parameter[1]);
}

weex.init(Vue);

const App = require('../../../../src/view/pet/login/password.vue');
App.el = '#root';
new Vue(App);
