import Vue from 'vue';
import weex from 'weex-vue-render';

const router = require('@/router');

weex.init(Vue);
const App = require('../../../src/view/login/index.vue');
new Vue(Vue.util.extend({el: '#root', router}, App));
